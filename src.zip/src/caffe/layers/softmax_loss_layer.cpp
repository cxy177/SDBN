#include <algorithm>
#include <cfloat>
#include <vector>

#include "caffe/layers/softmax_loss_layer.hpp"
#include "caffe/util/math_functions.hpp"

namespace caffe {
template <typename Dtype>
void SoftmaxWithLossLayer<Dtype>::LayerSetUp(
    const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {

  LossLayer<Dtype>::LayerSetUp(bottom, top);
  LayerParameter softmax_param(this->layer_param_);
  //fpic=(ObjectType_NEW *)this->layer_param_.fnew2;
  //fpic=(ObjectType_NEW *)this->fnew;


  //this->scan_=(Scan_Pos *)this->layer_param_.scan_;
  //scan_=this->scan_;


  phase_ =softmax_param.phase();
  softmax_param.set_type("Softmax");
  softmax_layer_ = LayerRegistry<Dtype>::CreateLayer(softmax_param);
  softmax_bottom_vec_.clear();
  softmax_bottom_vec_.push_back(bottom[0]);
  softmax_top_vec_.clear();
  softmax_top_vec_.push_back(&prob_);
  softmax_layer_->SetUp(softmax_bottom_vec_, softmax_top_vec_);

  num_ = bottom[0]->num();

  //gamma_=2.5;
  has_ignore_label_ =
    this->layer_param_.loss_param().has_ignore_label();
  if (has_ignore_label_) {
    ignore_label_ = this->layer_param_.loss_param().ignore_label();
  }
  if (!this->layer_param_.loss_param().has_normalization() &&
      this->layer_param_.loss_param().has_normalize()) {
    normalization_ = this->layer_param_.loss_param().normalize() ?
                     LossParameter_NormalizationMode_VALID :
                     LossParameter_NormalizationMode_BATCH_SIZE;
  } else {
    normalization_ = this->layer_param_.loss_param().normalization();
  }



}

template <typename Dtype>
void SoftmaxWithLossLayer<Dtype>::Reshape(
    const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {
  LossLayer<Dtype>::Reshape(bottom, top);
  softmax_layer_->Reshape(softmax_bottom_vec_, softmax_top_vec_);
  softmax_axis_ = bottom[0]->CanonicalAxisIndex(this->layer_param_.softmax_param().axis());
  if (top.size() >= 2) {    
    top[1]->ReshapeLike(*bottom[0]);
  }
}

template <typename Dtype>
Dtype SoftmaxWithLossLayer<Dtype>::get_normalizer(
    LossParameter_NormalizationMode normalization_mode, int valid_count) {
  Dtype normalizer;
  switch (normalization_mode) {
    case LossParameter_NormalizationMode_FULL:
      normalizer = Dtype(outer_num_ * inner_num_);
      break;
    case LossParameter_NormalizationMode_VALID:
      if (valid_count == -1) {
        normalizer = Dtype(outer_num_ * inner_num_);
      } else {
        normalizer = Dtype(valid_count);
      }
      break;
    case LossParameter_NormalizationMode_BATCH_SIZE:
      normalizer = Dtype(outer_num_);
      break;
    case LossParameter_NormalizationMode_NONE:
      normalizer = Dtype(1);
      break;
    default:
      LOG(FATAL) << "Unknown normalization mode: "
          << LossParameter_NormalizationMode_Name(normalization_mode);
  }
  return std::max(Dtype(1.0), normalizer);
}

template <typename Dtype>
void SoftmaxWithLossLayer<Dtype>::Forward_cpu(
    const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {
    //The forward pass computes the softmax prob values.
    Dtype* bottom_diff = bottom[0]->mutable_cpu_diff();
    const Dtype* bottom_data = bottom[0]->cpu_data();
    const Dtype* label = bottom[1]->cpu_data();
    float t=0;
    float th,t1,tx,t2,x1,y1,scale,scale2,loss_data[10];
    loss_data[0]=0;
    loss_data[1]=0;
    loss_data[2]=0;
    loss_data[3]=0;
    loss_data[4]=0;
    loss_data[5]=0;
    loss_data[6]=0;
    loss_data[7]=0;

  th=0;
  //LOG(INFO)<<"SoftmaxWithLossLayer  phase_="<<phase_;
  top[0]->mutable_cpu_data()[0] =0;






}

template <typename Dtype>
void SoftmaxWithLossLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
    const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom) {

    const Dtype*  input_image = bottom[0]->cpu_data();
     const Dtype*  label_image = bottom[1]->cpu_data();
    const Dtype* label_data = bottom[2]->cpu_data();
    const Dtype* output_image = bottom[3]->cpu_data();
    //const Dtype* category_data = bottom[3]->cpu_data();

    Dtype* output_diff = bottom[3]->mutable_cpu_diff();
    //Dtype* category_diff = bottom[3]->mutable_cpu_diff();

     int dim = bottom[3]->count(0);
     memset(output_diff , 0, dim*sizeof(Dtype));


     int na=bottom[0]->shape(0);
      for(int i=0;i<na;i++) {
              int n1=bottom[3]->count(1);
              int h1=bottom[3]->shape(2);
              int w1=bottom[3]->shape(3);

              int s1=sc_;
              int sw=h1-2*sc_;
              int s2=s1+sw;

              int n1a=bottom[1]->count(1);
              int h1a=bottom[1]->shape(2);
              int w1a=bottom[1]->shape(3);
              int s1a=(h1a-sw)/2;


              for(int y=s1;y<s2;y++) {
                  for(int x=s1;x<s2;x++)  {
              int k1=n1*i+y*w1+x;
              int k2=n1a*i+(y-s1+s1a)*w1a+(x-s1+s1a);
              float t=2.0*(label_image[k2]-0.5);
              output_diff[k1]=(output_image[k1]-t);
                  } }
      }

      const Dtype* bottom_diff1 = bottom[3]->cpu_diff();
      Dtype* bottom_diff2 = bottom[3]->mutable_gpu_diff();
//LOG(INFO)<<"SoftmaxWithLossLayer  phase_="<<phase_;




}

#ifdef CPU_ONLY
STUB_GPU(SoftmaxWithLossLayer);
#endif

INSTANTIATE_CLASS(SoftmaxWithLossLayer);
REGISTER_LAYER_CLASS(SoftmaxWithLoss);

}  // namespace caffe
