#include <algorithm>
#include <vector>

#include "caffe/layers/relu_layer.hpp"

namespace caffe {
template <typename Dtype>
void ReLULayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom,
    const vector<Blob<Dtype>*>& top) {
  const Dtype* bottom_data = bottom[0]->cpu_data();
  Dtype* top_data = top[0]->mutable_cpu_data();

  const int num = bottom[0]->num();
  const int dim = bottom[0]->count(1);
 
  Dtype negative_slope =0;// this->layer_param_.relu_param().negative_slope();


  for(int n=0;n<num;++n) {
    for (int i = 0; i < dim; ++i) {             
            int j=i+n*dim;
            top_data[j]=std::max(bottom_data[j],  Dtype(0));
          // if( j<10) LOG(INFO)<<this->layer_param_.name()<<top_data[j];//this->layer_param_.name()=="tanh9"&&
      }//i
    }//n




}


template <typename Dtype>
void ReLULayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
    const vector<bool>& propagate_down,
    const vector<Blob<Dtype>*>& bottom) {
  if (propagate_down[0]) {
    const Dtype* bottom_data = bottom[0]->cpu_data();

    const Dtype* top_data = top[0]->cpu_data();
    Dtype* top_diff = top[0]->mutable_cpu_diff();

    Dtype* bottom_diff = bottom[0]->mutable_cpu_diff();
    const int num = bottom[0]->num();
    const int count = bottom[0]->count(1);
    Dtype negative_slope =0;// this->layer_param_.relu_param().negative_slope();




    const Dtype* top_diff2 = top[0]->cpu_diff();

    for(int n=0;n<num;++n){
      for (int i = 0; i < count; ++i) {
          int j=i+n*count;
      bottom_diff[j] = top_diff2[j] * ((bottom_data[j] > 0));
      }//i
  }//n


  const Dtype* bottom_diff2 = bottom[0]->cpu_diff();

//LOG(INFO)<<this->layer_param_.type() <<":"<<this->layer_param_.name() <<" Backward_gpu OK!!!";
}//propagate_down[0]

}

#ifdef CPU_ONLY
STUB_GPU(ReLULayer);
#endif

INSTANTIATE_CLASS(ReLULayer);

}  // namespace caffe
