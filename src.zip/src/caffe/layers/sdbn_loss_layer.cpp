#include <algorithm>
#include <cfloat>
#include <vector>

#include "caffe/layers/sdbn_loss_layer.hpp"
#include "caffe/util/math_functions.hpp"

namespace caffe {
template <typename Dtype>
void SdbnLossLayer<Dtype>::LayerSetUp(
    const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {


      this->layer_param_.add_loss_weight(Dtype(1));


    LayerParameter softmax_param(this->layer_param_);



  phase_ =softmax_param.phase();


}

template <typename Dtype>
void SdbnLossLayer<Dtype>::Reshape(
    const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {

    vector<int> loss_shape(0);  // Loss layers output a scalar; 0 axes.
    top[0]->Reshape(loss_shape);
}



template <typename Dtype>
void SdbnLossLayer<Dtype>::Forward_cpu(
    const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {


    const Dtype* label_image= bottom[0]->cpu_data();
    const Dtype* output_image = bottom[1]->cpu_data();

float t1,t2;

  top[0]->mutable_cpu_data()[0] =0;
  this->udl_data_->cy_=bottom[0]->shape(2);
  this->udl_data_->cx_=bottom[0]->shape(3);
this->udl_data_->cy2_=bottom[1]->shape(2);
this->udl_data_->cx2_=bottom[1]->shape(3);

  if(phase_ == caffe::TRAIN) {
  int n1b=bottom[0]->count(0);
  for(int j=0;j<n1b;j++) {
  this->udl_data_->sample_label_ [j]=label_image[j];
  }
   int n1c=bottom[1]->count(0);
    for(int j=0;j<n1c;j++) {
    this->udl_data_->sample_target_[j]=0.5*(output_image[j]+1.0);
    }
  }

  if(phase_ == caffe::TEST&&this->udl_data_->Net_Type==Net_Type_SDBN_1) {
      int off=0;//this->udl_data_->off_;
      int off_h=(this->udl_data_->cy_-this->udl_data_->cy2_)/2;
      int off_w=(this->udl_data_->cx_-this->udl_data_->cx2_)/2;

     int off2=off*2;


      int ir=this->udl_data_->m1_;
    Rect_CXY  rec=this->udl_data_->rec[ir];
    int imgsize=this->udl_data_->imgsize;

      for(int y=rec.y0+off_h+off;y<rec.y0+off_h+this->udl_data_->cy2_-off2;y++) {
          for(int x=rec.x0+off_w+off;x<rec.x0+off_w+this->udl_data_->cx2_-off2;x++)  {
      int k1=y*this->udl_data_->imgwidth_+x;
      int k2=(y-(rec.y0+off_h))*this->udl_data_->cx2_+x-(rec.x0+off_w);
      t1=this->udl_data_->image_target_[k1];
      t2=0.5*(output_image[k2]+1.0);//output_image[k2];
      if(t2>t1) this->udl_data_->image_target_[k1]=t2;
      } }


  }


  if(phase_ == caffe::TEST&&this->udl_data_->Net_Type==Net_Type_SDBN_2) {

      Rect_CXY  rec;

      int h1=bottom[1]->shape(2);
      int w1=bottom[1]->shape(3);

      float enlarge_scale=this->udl_data_->enlarge_scale;


    rec.x0=enlarge_scale*this->udl_data_->pos.x-w1/2;
    rec.x1= rec.x0+w1;
    rec.y0=enlarge_scale*this->udl_data_->pos.y-h1/2;
    rec.y1= rec.y0+h1;

      int off=0;
      for(int y=rec.y0+off;y<rec.y1-off;y++) {
          for(int x=rec.x0+off;x<rec.x1-off;x++)  {

     if(x>=0&&x<=enlarge_scale*(this->udl_data_->imgwidth_-1)&&y>=0&&y<=enlarge_scale*(this->udl_data_->imgheight_-1)) {
         int k1=y*enlarge_scale*this->udl_data_->imgwidth_+x;
        int k2=(y-rec.y0)*w1+(x-rec.x0);
      float t1=this->udl_data_->image_target_[k1];
      float t2=0.5*(output_image[k2]+1.0);
      if(t2>t1) this->udl_data_->image_target_[k1]=t2;
     }}}

  }

}

template <typename Dtype>
void SdbnLossLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
    const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom) {

    const Dtype*  label_image = bottom[0]->cpu_data();
        const Dtype*  output_image = bottom[1]->cpu_data();


        Dtype* output_diff = bottom[1]->mutable_cpu_diff();

         int dim = bottom[1]->count(0);
         memset(output_diff , 0, dim*sizeof(Dtype));

         this->udl_data_->cy_=bottom[0]->shape(2);
         this->udl_data_->cx_=bottom[0]->shape(3);
       this->udl_data_->cy2_=bottom[1]->shape(2);
       this->udl_data_->cx2_=bottom[1]->shape(3);

      int num_sample=bottom[0]->shape(0);

      int label_size=bottom[0]->count(1);
       int target_size=bottom[1]->count(1);
     //LOG(INFO) << "step_Output2";
          for(int i=0;i<num_sample;i++) {

              int off=this->udl_data_->off_;
              int off_h=(this->udl_data_->cy_-this->udl_data_->cy2_)/2;
              int off_w=(this->udl_data_->cx_-this->udl_data_->cx2_)/2;

             int off2=off*2;


              for(int y=off_h+off;y<off_h+this->udl_data_->cy2_-off2;y++) {
                  for(int x=off_w+off;x<off_w+this->udl_data_->cx2_-off2;x++)  {
              int k1=y*this->udl_data_->cx_+x+i*label_size;
              int k2=(y-off_h)*this->udl_data_->cy2_+x-off_w+i*target_size;

              //float t=0.5*(output_image[k2]+1.0);
              //output_diff[k1]=(t-1.0*label_image[k1]);
              float t=2.0*(label_image[k1]-0.5);
              output_diff[k2]=(output_image[k2]-t);
              }}}



        const Dtype* output_diff2 = bottom[1]->gpu_diff();




}

#ifdef CPU_ONLY
STUB_GPU(SdbnLossLayer);
#endif

INSTANTIATE_CLASS(SdbnLossLayer);
REGISTER_LAYER_CLASS(SdbnLoss);

}  // namespace caffe
