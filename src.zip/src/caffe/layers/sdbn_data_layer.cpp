#ifdef USE_OPENCV
#include <opencv2/core/core.hpp>
#endif  //USE_OPENCV
#include <stdint.h>
#include <vector>
#include "caffe/data_transformer.hpp"
#include "caffe/layers/sdbn_data_layer.hpp"
#include "caffe/util/benchmark.hpp"
#include "caffe/UDL_Data.hpp"

#include <opencv2/opencv.hpp>
#include <iostream>
using namespace cv;
using namespace std;


namespace caffe {

template <typename Dtype>
SDBN_DataLayer<Dtype>::SDBN_DataLayer(const LayerParameter& param, UDL_Data<Dtype>* udl)
  : BasePrefetchingDataLayer<Dtype>(param,udl),
    offset_() { 


cx_=this->udl_data_->cx_;
cy_=this->udl_data_->cy_;

sImg_.x=cx_; sImg_.y=cy_;

phase_ = param.phase();
channels_=3;


fpic=(ObjectType_NEW *)this->udl_data_->fnew;

scan_=(Scan_Pos *)this->udl_data_->scan;


}

template <typename Dtype>
SDBN_DataLayer<Dtype>::~SDBN_DataLayer() {

}



template <typename Dtype>
void SDBN_DataLayer<Dtype>::DataLayerSetUp(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top) {


  int batch_size;


  channels_=3;
  if(phase_ == caffe::TRAIN)  {
      pic_cur_=this->udl_data_->train.x;
      pic_full_=this->udl_data_->train.y;
      object_cur_=0;
      this->udl_data_->Change_Pic(pic_cur_);
       object_full_=fpic[pic_cur_].object_num;
      sImg_.x=cx_; sImg_.y=cy_;batch_size=2;
  }

  if(phase_ == caffe::TEST)  {
      pic_cur_=this->udl_data_->test.x;
      pic_full_=this->udl_data_->test.y;
      object_cur_=0;
      this->udl_data_->Change_Test_Pic(pic_cur_);
       object_full_=fpic[pic_cur_].object_num;
      sImg_.x=cx_; sImg_.y=cy_;batch_size=1;
  }

  top_shape_.clear();
  top_shape_.push_back(batch_size);
  top_shape_.push_back(channels_);

  top_shape_.push_back(sImg_.y);
  top_shape_.push_back(sImg_.x);


  top_shape2_.clear();
  top_shape2_.push_back(batch_size);
  top_shape2_.push_back(1);

  top_shape2_.push_back(sImg_.y);
  top_shape2_.push_back(sImg_.x);


  LOG(INFO)<<"this->prefetch_.size()="<<this->prefetch_.size();
  top[0]->Reshape(top_shape_);
  top[1]->Reshape(top_shape2_);

    this->prefetch_current_->data_.Reshape(top_shape_);
   this->prefetch_current_->data2_.Reshape(top_shape_);
    this->prefetch_current_->label_.Reshape(top_shape2_);

  LOG_IF(INFO, Caffe::root_solver())
      << "output data size: " << top[0]->num() << ","<< top[0]->channels() << "," << top[0]->height() << ","
      << top[0]->width();

}

// This function is called on prefetch thread
template<typename Dtype>
void SDBN_DataLayer<Dtype>::load_batch(Batch<Dtype>* batch) {
  CHECK(batch->data_.count());

  int batch_num = 1;
  int batch_size;

//LOG(INFO)<<"object_cur_, object_full_, pic_cur_="<<object_cur_<<","<<object_full_<<","<< pic_cur_;
 if(phase_ == caffe::TRAIN)  {
 batch_size =2;
 if(object_cur_==object_full_) {
 pic_cur_++;
 if(pic_cur_==this->udl_data_->train.y)   pic_cur_=this->udl_data_->train.x;
 object_cur_=0;
 this->udl_data_->Change_Pic(pic_cur_);
  object_full_=fpic[pic_cur_].object_num;
 }}

  if(phase_ == caffe::TEST&&this->udl_data_->Net_Type==Net_Type_SDBN_1)
  {
   batch_size =1;
   m1_=this->udl_data_->m1_;
   rec_=this->udl_data_->rec[m1_];
  }
  if(phase_ == caffe::TEST&&this->udl_data_->Net_Type==Net_Type_SDBN_2)
  {
   batch_size =1;
  }


      top_shape_.clear();
      top_shape_.push_back(batch_size);
      top_shape_.push_back(channels_);
      top_shape2_.clear();
      top_shape2_.push_back(batch_size);
      top_shape2_.push_back(1);

      if(phase_ == caffe::TRAIN)
      {
      sImg_.x=cx_; sImg_.y=cy_;
      top_shape_.push_back(sImg_.y);
      top_shape_.push_back(sImg_.x);
      top_shape2_.push_back(sImg_.y);
      top_shape2_.push_back(sImg_.x);
      }
      if(phase_ ==caffe::TEST&&this->udl_data_->Net_Type==Net_Type_SDBN_1) {
          top_shape_.push_back(rec_.y1-rec_.y0);
          top_shape_.push_back(rec_.x1-rec_.x0);
          top_shape2_.push_back(rec_.y1-rec_.y0);
          top_shape2_.push_back(rec_.x1-rec_.x0);
      }

      if(phase_ ==caffe::TEST&&this->udl_data_->Net_Type==Net_Type_SDBN_2) {
          sImg_.x=cx_; sImg_.y=cy_;
          top_shape_.push_back(sImg_.y);
          top_shape_.push_back(sImg_.x);
          top_shape2_.push_back(sImg_.y);
          top_shape2_.push_back(sImg_.x);
      }



 batch->data_.Reshape(top_shape_);
 batch->label_.Reshape(top_shape2_);


     if(phase_ == caffe::TRAIN)
     {               

      load_sample(batch,0);
      load_sample(batch,1);
     }
     if(phase_ == caffe::TEST)
     {
      load_sample(batch,0);          
     }

 return;
}





template<typename Dtype>
void SDBN_DataLayer<Dtype>::load_sample(Batch<Dtype>* batch,int item_id) {
    Dtype* top_data = batch->data_.mutable_cpu_data();    
    Dtype* top_label = batch->label_.mutable_cpu_data();
    float rot[10],avg2,sum,dev2,hx[10],ang[10],angle,t,t1,t2,t3,t4,tx,ty,tx1,ty1,len;
    float avg,dev,min,dist,xc,yc,scale,scale2, inv_ang,xc1,yc1;
    Point2 pos;
    int f1,f2,jb,w1,h1,w2,mx,my,imgsize,x,y,x0,y0,x1,y1,x2,y2;
    Dtype *buffer,*buffer2;




    int offset,offset2;
    offset= top_shape_[1]*top_shape_[2]*top_shape_[3]*item_id;
    offset2= top_shape2_[1]*top_shape2_[2]*top_shape2_[3]*item_id;
    buffer=&top_data[offset];
    buffer2=&top_label[offset2];

    //this->udl_data_->Img_=imread((const char *)fpic[0].filename,IMREAD_COLOR );

    w1=this->udl_data_->imgwidth_;
    h1=this->udl_data_->imgheight_;
    w2=3*w1;

     imgsize=sImg_.x*sImg_.y;


    U8 *p=(U8 *)this->udl_data_->Img_.data;
    float *p2=this->udl_data_->image_label_;

    if(phase_ == caffe::TRAIN) {

    if(item_id==0)
    {
    xc=0.5*(fpic[pic_cur_].p[2*object_cur_].x+fpic[pic_cur_].p[2*object_cur_+1].x);
    yc=0.5*(fpic[pic_cur_].p[2*object_cur_].y+fpic[pic_cur_].p[2*object_cur_+1].y);
    object_cur_++;
    }
    if(item_id==1)
    {
    xc=1.0*(w1-1)*(1.0*rand()/RAND_MAX);
    yc=1.0*(h1-1)*(1.0*rand()/RAND_MAX);
    }
    pos.x=-12+24.0*(1.0*rand()/RAND_MAX);
    pos.y=-12+24.0*(1.0*rand()/RAND_MAX);
    rot[0]=-PAI2+PAI*(1.0*rand()/RAND_MAX);
    float s1=2.0*(1.0*rand()/RAND_MAX-0.5);
    if(s1>=0) scale2=1.0+s1*(1.5-1);
    else scale2=1.0/(1.0-s1*(1.5-1));

     mx=sImg_.x/2;
     my=sImg_.y/2;
     tx1=scale2/this->udl_data_->enlarge_scale*cos(rot[0]);
     ty1=scale2/this->udl_data_->enlarge_scale*sin(rot[0]);

            int i2=0;


            for(int y=-my;y<my;y++)
                {
                for(int x=-mx;x<mx;x++)
                    {
                    float x1=xc+tx1*(pos.x+x)+ty1*(pos.y+y);
                    float y1=yc+tx1*(pos.y+y)-ty1*(pos.x+x);


                    int f1=0;
                    if(x1<0||x1>w1-1||y1<0||y1>h1-1) f1=1;

                    if(f1==0) {
                    int x0=x1;
                    int y0=y1;
                    int x2=x0+1;
                    int y2=y0+1;

                    if(x2<0) x2=0;
                    if(x2>w1-1) x2=w1-1;
                    if(y2<0) y2=0;
                    if(y2>h1-1) y2=h1-1;

                    float t1=x1-x0;float t2=y1-y0;

                    int  j1=0;
                     float t5=(1-t1)*(1-t2)*p2[y0*w1+x0]+(1-t1)*t2*p2[y2*w1+x0]+t1*(1-t2)*p2[y0*w1+x2]+t1*t2*p2[y2*w1+x0];
                     buffer2[i2]= (Dtype)(1.0*t5);//2.0*(t4-0.5));
                     //this->udl_data_->sample_label_[item_id*imgsize+i2]=t5;

                    int k=y0*w2+3*x0; int k1=y2*w2+3*x0; int k2=y0*w2+3*x2; int k3=y2*w2+3*x2;

                    float t4=0;
                    for(int j1=0;j1<3; j1++){
                    t4=(1-t1)*(1-t2)*p[k+j1]+(1-t1)*t2*p[k1+j1]+t1*(1-t2)*p[k2+j1]+t1*t2*p[k3+j1];
                    buffer[j1*imgsize+i2]=(Dtype)(1.0*t4/255.0);  //1.0*(t4-127.5)/127.5);
                    int h1=item_id*3*imgsize+3*i2+j1;
                    this->udl_data_->sample_data_[h1]=t4/255.0;

                    }

                    }
                    else {
                        for(int j1=0;j1<3; j1++){
                             buffer[j1*imgsize+i2]=0;
                        this->udl_data_->sample_data_[item_id*3*imgsize+j1*imgsize+i2]=0;
                        }
                        buffer2[i2]=0;
                    //this->udl_data_->sample_label_[item_id*imgsize+i2]=0;
                    }

                i2++;
                }}


}

if(phase_==caffe::TEST&&this->udl_data_->Net_Type==Net_Type_SDBN_1 ) {

    m1_=this->udl_data_->m1_;
    rec_=this->udl_data_->rec[m1_];

    w1=this->udl_data_->imgwidth_;
    h1=this->udl_data_->imgheight_;
    w2=3*w1;

            imgsize=(rec_.y1-rec_.y0)*(rec_.x1-rec_.x0);

            int i1=0;
            for(int y=rec_.y0;y<rec_.y1;y++)
                {
                for(int x=rec_.x0;x<rec_.x1;x++)
                    {
                    float t4=0;
                    for(int j1=0;j1<3; j1++) {
                    t4=p[y*w2+3*x+j1];
                    buffer[j1*imgsize+i1]=(Dtype)(1.0*t4/255.0);
                    this->udl_data_->image_data_[y*w2+3*x+j1]=t4/255;
                    }
                    t4=p2[y*w1+x];
                    buffer2[i1]= (Dtype)(1.0*t4);
                    i1++;
                    }
               }
           }



if(phase_==caffe::TEST&&this->udl_data_->Net_Type==Net_Type_SDBN_2 ) {

    int scan_cur=this->udl_data_->scan_cur_;
    this->udl_data_->pos.x=scan_[scan_cur].x[0];
    this->udl_data_->pos.y=scan_[scan_cur].y[0];
    xc=this->udl_data_->pos.x;
    yc=this->udl_data_->pos.y;

    w1=this->udl_data_->imgwidth_;
    h1=this->udl_data_->imgheight_;
    w2=3*w1;

    //LOG(INFO) << "sImg_.x,sImg_.y=:"<<sImg_.x<<" , "<<sImg_.y;

     pos.x=0;pos.y=0;
     imgsize=sImg_.x*sImg_.y;
     mx=sImg_.x/2;
     my=sImg_.y/2;
     tx1=1.0/this->udl_data_->enlarge_scale;
     ty1=0.0;
         int i2=0;
         for(int y=-my;y<my;y++)
             {
             for(int x=-mx;x<mx;x++)
                 {
                 float x1=xc+tx1*(pos.x+x)+ty1*(pos.y+y);
                 float y1=yc+tx1*(pos.y+y)-ty1*(pos.x+x);

                 int f1=0;
                 if(x1<0||x1>w1-1||y1<0||y1>h1-1) f1=1;

                 if(f1==0) {
                 int x0=x1;
                 int y0=y1;
                 int x2=x0+1;
                 int y2=y0+1;

                 if(x2<0) x2=0;
                 if(x2>w1-1) x2=w1-1;
                 if(y2<0) y2=0;
                 if(y2>h1-1) y2=h1-1;

                 float t1=x1-x0;float t2=y1-y0;
                 int k=y0*w2+3*x0; int k1=y2*w2+3*x0; int k2=y0*w2+3*x2; int k3=y2*w2+3*x2;
                 float t4=0;
                 for(int j1=0;j1<3; j1++){
                 t4=(1-t1)*(1-t2)*p[k+j1]+(1-t1)*t2*p[k1+j1]+t1*(1-t2)*p[k2+j1]+t1*t2*p[k3+j1];
                 buffer[j1*imgsize+i2]=(Dtype)(1.0*t4/255.0);
                 }

                 //k=y0*w1+x0; int k1=y2*w1+x0; int k2=y0*w2+3*x2; int k3=y2*w2+3*x2;
                 t4=(1-t1)*(1-t2)*p2[y0*w1+x0]+(1-t1)*t2*p2[y2*w1+x0]+t1*(1-t2)*p2[y0*w1+x2]+t1*t2*p2[y2*w1+x0];
                 buffer2[i2]= (Dtype)(1.0*t4/255.0);
                 }
                 else {
                     for(int j1=0;j1<3; j1++){
                          buffer[j1*imgsize+i2]=0;}
                     buffer2[i2]=0;}
             i2++;
             }}

         //  LOG(INFO) << "i2=:"<<i2;

}


 }



INSTANTIATE_CLASS(SDBN_DataLayer);
REGISTER_LAYER_CLASS(SDBN_Data);
}  //namespace caffe


