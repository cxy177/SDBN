#include <cstdio>
#include <string>
#include <vector>
#include <time.h>
#include "caffe/sdbn_solver.hpp"
#include "caffe/util/format.hpp"
#include "caffe/util/hdf5.hpp"
#include "caffe/util/io.hpp"
#include "caffe/util/upgrade_proto.hpp"
#include <opencv2/opencv.hpp>
#include <iostream>
using namespace cv;
using namespace std;

namespace caffe {
template <typename Dtype>
void Solver<Dtype>::Init(const SolverParameter& param) {
   LOG(INFO) << "Init 2a.";
   LOG_IF(INFO, Caffe::root_solver()) << "Initializing solver from parameters: "
    << std::endl << param.DebugString();
  param_ = param;
  CHECK_GE(param_.average_loss(), 1) << "average_loss should be non-negative.";
  CheckSnapshotWritePermissions();
  if (param_.random_seed() >= 0) {
    Caffe::set_random_seed(param_.random_seed() + Caffe::solver_rank());
  }

  float cx[10];
  int bx[10];



  LOG(INFO) << "Initialize Networks!!!!";

   srand((unsigned int)time(NULL));


  //udl_data.Database_File=Database_MUNICH;
 // udl_data.Database_File=Database_OVDS;
  //udl_data.Database_File=Database_OIRDS;
  udl_data.Database_File=Database_OAD;

  if(udl_data.Database_File==Database_OAD) {
    udl_data.Aircraft_TextFile_2_Database(0,"database/aircraft/","database/aircraft/total_oad.txt");
    udl_data.train.x=0;udl_data.train.y=110;
   udl_data.test.x=110;udl_data.test.y=164;
  }

  if(udl_data.Database_File==Database_OVDS) {
  udl_data.Vehicle_TextFile_2_Database(0,"database/ovds/","database/ovds/total_ovds.txt");
  udl_data.train.x=0;udl_data.train.y=55;
  udl_data.test.x=55;udl_data.test.y=111;      
  }

  if(udl_data.Database_File==Database_OIRDS) {
      udl_data.Vehicle_TextFile_2_Database(0,"database/oirds/","database/oirds/total_oirds.txt");
  udl_data.train.x=0;udl_data.train.y=52;
 udl_data.test.x=52;udl_data.test.y=67;
  }


  if(udl_data.Database_File==Database_MUNICH) {

      udl_data.Vehicle_TextFile_2_Database(0,"database/munich/","database/munich/total_munich.txt");
      udl_data.train.x=0;udl_data.train.y=10;
      udl_data.test.x=10;udl_data.test.y=20;
  }




  fpic=udl_data.fnew;

udl_data.side_factor=4;
udl_data.off_=0;
udl_data.kernel_size=1.0;

  iter_ = 0;
  current_step_ = 0;




  udl_data.Net_Type=Net_Type_SDBN_1;

  //udl_data.Net_Type=Net_Type_SDBN_2;

  udl_data.cx_=80;
  udl_data.cy_=udl_data.cx_;
  udl_data.enlarge_scale=1;


  InitTrainNet();

  /*udl_data.cx_= 320;//, etc.
  udl_data.cy_=udl_data.cx_;
   udl_data.enlarge_scale=1;
  InitTestNet_1();
*/
  int n1=0;
  for(int i=udl_data.train.x;i<udl_data.train.y;i++) {
      n1+=udl_data.fnew[i].object_num;
  }
  int n2=0;
  for(int i=udl_data.test.x;i<udl_data.test.y;i++){
      n2+=udl_data.fnew[i].object_num;
  }

   LOG(INFO) << "training, test and total object number=:"<<n1<<" , "<<n2<<" , "<<n1+n2;

 }



template <typename Dtype>
void Solver<Dtype>::Test_SDBN()
{

    udl_data.off_=8;
   udl_data.Net_Type=Net_Type_SDBN_1;
    udl_data.cx_= 320;//, etc.
      udl_data.cy_=udl_data.cx_;
       udl_data.enlarge_scale=1;
      InitTestNet_1();
     test_net_->CopyTrainedLayersFrom("models/sdbn_160x160.caffemodel");

    Test_SDBN_1();

     udl_data.Net_Type=Net_Type_SDBN_2;
     udl_data.cx_= 80;//160, etc.
     udl_data.cy_=udl_data.cx_;
      udl_data.enlarge_scale=1;//2,etc.

     InitTestNet_2();
     test_net_->CopyTrainedLayersFrom("models/sdbn_2.caffemodel");

     Test_SDBN_2();


}

template <typename Dtype>
void Solver<Dtype>::InitTrainNet() {

  NetParameter net_param;


  ReadNetParamsFromTextFileOrDie("models/sdbn/sdbn.prototxt", &net_param);

  NetState net_state;
  net_state.set_phase(TRAIN);
  net_state.MergeFrom(net_param.state());
  net_state.MergeFrom(param_.train_state());
  net_param.mutable_state()->CopyFrom(net_state);
  LOG(INFO)<<"training net="<<net_;
  net_.reset(new Net<Dtype>(net_param,&udl_data));

  net_->udl_data_=&udl_data;

}

template <typename Dtype>
void Solver<Dtype>::InitTestNet_1() {

  NetParameter net_param;

  ReadNetParamsFromTextFileOrDie("models/sdbn/sdbn.prototxt",&net_param);

  NetState net_state;
  net_state.set_phase(TEST);
  net_state.MergeFrom(net_param.state());
  if (param_.test_state_size()) {
    net_state.MergeFrom(param_.test_state(0));
  }
  net_param.mutable_state()->CopyFrom(net_state);

  test_net_.reset(new Net<Dtype>(net_param,&udl_data));
  test_net_->udl_data_=&udl_data;
  test_net_->set_debug_info(param_.debug_info());

}

template <typename Dtype>
void Solver<Dtype>::InitTestNet_2() {

  NetParameter net_param;

  ReadNetParamsFromTextFileOrDie("models/sdbn/sdbn.prototxt",&net_param);

  NetState net_state;
  net_state.set_phase(TEST);
  net_state.MergeFrom(net_param.state());
  if (param_.test_state_size()) {
    net_state.MergeFrom(param_.test_state(0));
  }
  net_param.mutable_state()->CopyFrom(net_state);


  test_net2_.reset(new Net<Dtype>(net_param,&udl_data));
  test_net2_->udl_data_=&udl_data;
  test_net2_->set_debug_info(param_.debug_info());



}



template <typename Dtype>
void Solver<Dtype>::Test_SDBN_1() {

    LOG(INFO) << "start SDBN_1 Testing ";

  float cx[20];
  int bx[10];
  char buf2[300];

  float  *image_label_=(float *)udl_data.image_label_;
  float  *image_target_=(float *)udl_data.image_target_;

  memset(image_label_,0,4*6000*6000);
  memset(image_target_,0,12*6000*6000);


    udl_data.n_scan_=0;

    double  start=clock(); //记录开始时间

   int ic=udl_data.test.x;
    udl_data.m1_=0;
   udl_data.Change_Test_Pic(ic);
int n_scan=0;
   while(ic<udl_data.test.y)
    {
      SolverAction::Enum request = GetRequestedAction();
      // Check to see if stoppage of testing/training has been requested.
      while (request != SolverAction::NONE) {
          if (SolverAction::SNAPSHOT == request) {
            Snapshot();
          } else if (SolverAction::STOP == request) {
            requested_early_exit_ = true;
          }
          request = GetRequestedAction();
      }
      if (requested_early_exit_) {
        // break out of test loop.
        break;
      }


      Dtype iter_loss;

      test_net_->Forward(&iter_loss);

    udl_data.m1_++;

      if(udl_data.m1_>=udl_data.m2_) {

          int w1=udl_data.imgwidth_;
          int h1=udl_data.imgheight_;
          int w2=3*w1;

          Mat  TestImg_;
          TestImg_.create(h1,w1, CV_8UC1);
          pTestImg_=(U8 *)TestImg_.data;
          hImg=TestImg_.rows;
          wImg1= TestImg_.cols;       
          memset(pTestImg_,0, hImg*wImg1);

            int imagesize=hImg*wImg1;


            Mat  InputImg_;
            InputImg_.create(h1,w1, CV_8UC3);
              U8 *pImg0_=(U8 *)InputImg_.data;


              for(int y=0;y< hImg;y++) {
                  for(int x=0;x< wImg1; x++)
                  {
                   int k2=y*3*wImg1+3*x;
                   for(int h=0;h<3;h++) {
                   pImg0_[k2+h]=255.0*(udl_data.image_data_[k2+h]);}}}

                  sprintf(buf2,"test_pic/a%1d.jpg", ic+1 );
                  imwrite((const char *)buf2,InputImg_);

     for(int y=0;y< hImg;y++) {
         for(int x=0;x< wImg1; x++)
         {
          int k1=y*wImg1+x;   
               pTestImg_[k1]=255.0*(image_label_[k1]);}}

             sprintf(buf2,"test_pic/a%1d_1.jpg",  ic+1 );
             imwrite((const char *)buf2,TestImg_);

              memset(pTestImg_,0, hImg*wImg1);

      for(int y=0;y< hImg;y++) {
          for(int x=0;x< wImg1; x++)
          {

           int k1=y*wImg1+x;

            pTestImg_[k1]=255.0*(image_target_[k1]);}}

           sprintf(buf2,"test_pic/a%1d_2.jpg",  ic+1 );
           imwrite((const char *)buf2,TestImg_);

   udl_data.connect_threshold=0.2;
   udl_data.area_threshold=0.2;

           udl_data.Scan_Pos_1();

           for(int y=0;y< hImg;y++) {
               for(int x=0;x< wImg1; x++)
               {
                int k2=y*3*wImg1+3*x;
                int k1=y*wImg1+x;
                for(int h=0;h<3;h++) {
                pImg0_[k2+h]=255.0*image_target_[k1];}}}

              for(int i1=n_scan;i1< udl_data.n_scan_;i1++) {
           for(int y=udl_data.scan[i1].y[0]-3;y< udl_data.scan[i1].y[0]+3;y++) {
               for(int  x=udl_data.scan[i1].x[0]-3;x< udl_data.scan[i1].x[0]+3;x++)
               {
                if(x<0) x=0; if(x>wImg1-1) x=wImg1-1;
                if(y<0) y=0; if(y>hImg-1) y=hImg-1;
                int k2=y*3*wImg1+3*x;
                int k1=y*wImg1+x;
                for(int h=0;h<2;h++) {
                pImg0_[k2+h]=0;}
                pImg0_[k2+2]=255;
               }}}

                n_scan=udl_data.n_scan_;
               sprintf(buf2,"test_pic/a%1d_3.jpg", ic+1 );
               imwrite((const char *)buf2,InputImg_);


           memset(udl_data.image_data_,0,4*6000*6000);
           memset(image_label_,0,4*6000*6000);
           memset(image_target_,0,12*6000*6000);


           ic++;
         if(ic<udl_data.test.y) udl_data.Change_Test_Pic(ic);
          udl_data.m1_=0;
  }
}





  LOG(INFO) << "end Testing ";


    if (requested_early_exit_) {
      LOG(INFO)     << "Test interrupted.";
      return;
    }

     double  finish=clock();
     double totaltime=(float)(finish-start)/CLOCKS_PER_SEC;

     LOG(INFO) << "total Testing time: ="<<totaltime;


}




template <typename Dtype>
void Solver<Dtype>::Test_SDBN_2() {
    //CHECK(Caffe::root_solver());


    LOG(INFO) << "start SDBN_2 Testing ";

    //for(int j=0;j<20;j++){
   // loss_data_[j]=0;
    //}

  float cx[20];
  int bx[10];
  char buf2[300];



float  *image_label_=(float *)udl_data.image_label_;
float  *image_target_=(float *)udl_data.image_target_;

memset(image_label_,0,4*6000*4000);
  memset(image_target_,0,4*12000*8000);


   // const shared_ptr<Net<Dtype> >& test_net = test_net_[0];

    double  start=clock(); //记录开始时间

 int n_scan_=udl_data.n_scan_;
 Scan_Pos * scan_=(Scan_Pos *)udl_data.scan;

int enlarge_scale=udl_data.enlarge_scale;
int iter=0;
int k1=scan_[0].pic;
udl_data.Change_Test_Pic(k1);
udl_data.pic_cur_=udl_data.test.x;
//udl_data.pic_full_=udl_data.test.y;
iter=0;
while(iter<n_scan_)
{

   udl_data.scan_cur_=iter;

   int k1=scan_[iter].pic;

 //  LOG(INFO) << "k1= "<<k1;
   if(k1!=udl_data.pic_cur_)   {
      udl_data.Change_Test_Pic(k1); }

   SolverAction::Enum request = GetRequestedAction();
   // Check to see if stoppage of testing/training has been requested.
   while (request != SolverAction::NONE) {
       if (SolverAction::SNAPSHOT == request) {
         Snapshot();
       } else if (SolverAction::STOP == request) {
         requested_early_exit_ = true;
       }
       request = GetRequestedAction();
   }

  if (requested_early_exit_) {
    // break out of test loop.
    break;
  }



  Dtype iter_loss;
 // LOG(INFO) << "step1 ";
  test_net2_->Forward(&iter_loss);
iter++;
//LOG(INFO) << "step2 ";


if(scan_[iter].pic!=udl_data.pic_cur_||iter==n_scan_)
{
    int ic=udl_data.pic_cur_;
    int w1=udl_data.imgwidth_;
    int h1=udl_data.imgheight_;
    int w2=3*w1;

       Mat  TestImg_;

        TestImg_.create(enlarge_scale*h1,enlarge_scale*w1, CV_8UC1);

        pTestImg_=(U8 *)TestImg_.data;
        hImg=TestImg_.rows;
        wImg1= TestImg_.cols;

        memset(pTestImg_,0, hImg*wImg1);

          int imagesize=hImg*wImg1;

   for(int y=0;y< hImg;y++) {
       for(int x=0;x< wImg1; x++)
       {
         int k1=y*wImg1+x;       
         pTestImg_[k1]=255.0*(image_target_[k1]);}}

        sprintf(buf2,"./test_pic/b%1d_2.jpg", ic+1 );
        imwrite((const char *)buf2,TestImg_);
        memset(image_label_,0,4*6000*4000);
        memset(image_target_,0,4*12000*8000);
}}



       LOG(INFO) << "n_scan_=: "<<n_scan_;
       LOG(INFO) << "end Testing ";

         if (requested_early_exit_) {
           LOG(INFO)     << "Test interrupted.";
           return;
         }


          double  finish=clock();
          double totaltime=(float)(finish-start)/CLOCKS_PER_SEC;

           LOG(INFO) << "total Testing time: ="<<totaltime;
}




template <typename Dtype>
void Solver<Dtype>::Train_All() {

char buf2[300];
  NetParameter net_param;
  Train_SDBN();

   net_->ToProto(&net_param, param_.snapshot_diff());
   WriteProtoToBinaryFile(net_param,"models/sdbn_80x80.caffemodel");


    udl_data.cx_=160;
    udl_data.cy_=udl_data.cx_;
    udl_data.enlarge_scale=1;
     InitTrainNet();
    net_->CopyTrainedLayersFrom( "models/sdbn_80x80.caffemodel");
    Train_SDBN();
    net_->ToProto(&net_param, param_.snapshot_diff());
   WriteProtoToBinaryFile(net_param,"models/sdbn_160x160.caffemodel");



    udl_data.cx_=320;
    udl_data.cy_=udl_data.cx_;
    udl_data.enlarge_scale=1;
    InitTrainNet();
   net_->CopyTrainedLayersFrom("models/sdbn_160x160.caffemodel");
    Train_SDBN();
    net_->ToProto(&net_param, param_.snapshot_diff());
   WriteProtoToBinaryFile(net_param, "models/sdbn_320x320.caffemodel");



 /*   udl_data.cx_=640;
    udl_data.cy_=udl_data.cx_;
    udl_data.enlarge_scale=1;
    InitTrainNet();
   net_->CopyTrainedLayersFrom("models/sdbn_320x320.caffemodel");
    Train_SDBN();
    net_->ToProto(&net_param, param_.snapshot_diff());
    WriteProtoToBinaryFile(net_param, "models/sdbn_640x640.caffemodel");

*/
    udl_data.Net_Type=Net_Type_SDBN_2;
    udl_data.cx_=80;
    udl_data.cy_=udl_data.cx_;
    udl_data.enlarge_scale=1;
     InitTrainNet();
     net_->CopyTrainedLayersFrom("models/sdbn_80x80.caffemodel");
    Train_SDBN();
    net_->ToProto(&net_param, param_.snapshot_diff());
    WriteProtoToBinaryFile(net_param, "models/sdbn_2.caffemodel");


}

template <typename Dtype>
void Solver<Dtype>::Train_SDBN() {
NetParameter net_param;
 const int stop_iter =  param_.max_iter();
  char buf2[300];

 iteration_timer_.Start();

 float  *sample_label_=(float *)udl_data.sample_label_;
 float  *sample_target_=(float *)udl_data.sample_target_;

 memset(sample_label_,0,4*1000*1000);
 memset(sample_target_,0,4*1000*1000);



LOG(INFO)<<"start Training SDBN_1 or SDBN_2";

iter_=0;

udl_data.pic_cur_=udl_data.train.x;
//udl_data.pic_begin_=udl_data.train.x;
//udl_data.pic_full_=udl_data.train.y;
int ic=udl_data.train.x;
 udl_data.Change_Pic(ic);

 requested_early_exit_ = false;

 iter_=0;

 while (iter_ < 500001) {


    net_->ClearParamDiffs();

     if (iter_>0&&iter_ % 30000 == 0) {
         net_->ToProto(&net_param, param_.snapshot_diff());
          sprintf(buf2,"models/sdbn_iter_%1d.caffemodel", iter_ );
         WriteProtoToBinaryFile(net_param, (const char*)buf2);
     }

     if (requested_early_exit_) {
         net_->ToProto(&net_param, param_.snapshot_diff());
         sprintf(buf2,"models/sdbn_iter_%1d.caffemodel", iter_ );
        WriteProtoToBinaryFile(net_param, (const char*)buf2);
       break;
     }

   for (int i = 0; i < callbacks_.size(); ++i) {
     callbacks_[i]->on_start();
   }
   int syn=100.0*rand()/RAND_MAX;
   const bool display = param_.display() && iter_ % (param_.display() +syn)== 0;
   net_->set_debug_info(display && param_.debug_info());
   // accumulate the loss and gradient
   //net_->iter_=iter_;
//LOG(INFO)<<"step1";
    net_->ForwardBackward();
//LOG(INFO)<<"step2";

  if (display) {

       int w1=udl_data.cx_;
       int h1=udl_data.cy_;

       Mat  LabelImg_;
       LabelImg_.create(h1,w1, CV_8UC1);

       int w2=udl_data.cx2_;
       int h2=udl_data.cy2_;

       Mat  OutputImg_;
       OutputImg_.create(h2,w2, CV_8UC1);


     U8 *pImg_=(U8 *)LabelImg_.data;

     hImg=LabelImg_.rows;
     wImg1= LabelImg_.cols;



     U8 *pImg2_=(U8 *)OutputImg_.data;
     int hImg_2=OutputImg_.rows;
     int wImg1_2= OutputImg_.cols;


     int imagesize=hImg*wImg1;




     Mat  InputImg_;
     InputImg_.create(h1,w1, CV_8UC3);
       U8 *pImg0_=(U8 *)InputImg_.data;


       for(int y=0;y< hImg;y++) {
           for(int x=0;x< wImg1; x++)
           {
            int k2=y*3*wImg1+3*x;
            for(int h=0;h<3;h++) {
            pImg0_[k2+h]=255.0*(udl_data.sample_data_[k2+h]);}}}

           sprintf(buf2,"./train_pic/a%1d.jpg", iter_ );
           imwrite((const char *)buf2,InputImg_);

    for(int y=0;y< hImg;y++) {
        for(int x=0;x< wImg1; x++)
        {         
         int k1=y*wImg1+x;
         pImg_[k1]=255.0*(sample_label_[k1]);}}
        sprintf(buf2,"./train_pic/a%1d_1.jpg", iter_ );
        imwrite((const char *)buf2,LabelImg_);


     for(int y=0;y< hImg_2;y++) {
         for(int x=0;x< wImg1_2; x++)
         {

          int k1=y*wImg1_2+x;
          float t1=255.0*(sample_target_[k1]);
          if(t1<0) t1=0;
          pImg2_[k1]=t1;
         }}

          sprintf(buf2,"./train_pic/a%1d_2.jpg", iter_ );
          imwrite((const char *)buf2,OutputImg_);

          memset(sample_label_,0,4*1000*1000);
          memset(sample_target_,0,4*1000*1000);


          float lapse = iteration_timer_.Seconds();
          float per_s = (iter_ - iterations_last_) / (lapse ? lapse : 1);

          LOG(INFO) << "Iteration " << iter_
              << " (" << per_s << " iter/s, " << lapse << "s/" << param_.display() << " iters)";

          iteration_timer_.Start();
          iterations_last_ = iter_;

    }

//LOG(INFO)<<"step3";

   for (int i = 0; i < callbacks_.size(); ++i) {
     callbacks_[i]->on_gradients_ready();
   }
  // LOG(INFO)<<"step4";
   ApplyUpdate();
   //net_->Update();
//LOG(INFO)<<"step5";
   //net_->Update();
   ++iter_;
   SolverAction::Enum request = GetRequestedAction();

   // Save a snapshot if needed.
   if ((param_.snapshot()
        && iter_ % param_.snapshot() == 0
        && Caffe::root_solver()) ||
        (request == SolverAction::SNAPSHOT)) {
     Snapshot();
   }
   if (SolverAction::STOP == request) {
     requested_early_exit_ = true;
     // Break out of training loop.
      //Snapshot();
      net_->ToProto(&net_param, param_.snapshot_diff());
      WriteProtoToBinaryFile(net_param, "models/sdbn_1.caffemodel");
     break;
   }
 }

 requested_early_exit_ = false;
}


template <typename Dtype>
void Solver<Dtype>::Solve(const char* resume_file) {


  // For a network that is trained by the solver, no bottom or top vecs
  // should be given, and we will just provide dummy vecs.

Train_All( );
Test_SDBN ( );


  if (requested_early_exit_) {
    LOG(INFO) << "Optimization stopped early.";
    return;
  }
  LOG(INFO) << "Optimization Done.";
}




template <typename Dtype>
void Solver<Dtype>::Snapshot() {
  CHECK(Caffe::root_solver());
  string model_filename;
  switch (param_.snapshot_format()) {
  case caffe::SolverParameter_SnapshotFormat_BINARYPROTO:
    model_filename = SnapshotToBinaryProto();
    break;
  case caffe::SolverParameter_SnapshotFormat_HDF5:
    model_filename = SnapshotToHDF5();
    break;
  default:
    LOG(FATAL) << "Unsupported snapshot format.";
  }

  SnapshotSolverState(model_filename);
}

template <typename Dtype>
void Solver<Dtype>::CheckSnapshotWritePermissions() {
  if (Caffe::root_solver() && param_.snapshot()) {
    CHECK(param_.has_snapshot_prefix())
        << "In solver params, snapshot is specified but snapshot_prefix is not";
    string probe_filename = SnapshotFilename(".tempfile");
    std::ofstream probe_ofs(probe_filename.c_str());
    if (probe_ofs.good()) {
      probe_ofs.close();
      std::remove(probe_filename.c_str());
    } else {
      LOG(FATAL) << "Cannot write to snapshot prefix '"
          << param_.snapshot_prefix() << "'.  Make sure "
          << "that the directory exists and is writeable.";
    }
  }
}

template <typename Dtype>
string Solver<Dtype>::SnapshotFilename(const string extension) {
  return param_.snapshot_prefix() + "_iter_" + caffe::format_int(iter_)
    + extension;
}

template <typename Dtype>
string Solver<Dtype>::SnapshotToBinaryProto() {
  string model_filename = SnapshotFilename(".caffemodel");
  LOG(INFO) << "Snapshotting to binary proto file " << model_filename;
  NetParameter net_param;
  net_->ToProto(&net_param, param_.snapshot_diff());
  WriteProtoToBinaryFile(net_param, model_filename);
  return model_filename;
}

template <typename Dtype>
string Solver<Dtype>::SnapshotToHDF5() {
  string model_filename = SnapshotFilename(".caffemodel.h5");
  LOG(INFO) << "Snapshotting to HDF5 file " << model_filename;
  net_->ToHDF5(model_filename, param_.snapshot_diff());
  return model_filename;
}

template <typename Dtype>
void Solver<Dtype>::Restore(const char* state_file) {
  string state_filename(state_file);
  if (state_filename.size() >= 3 &&
      state_filename.compare(state_filename.size() - 3, 3, ".h5") == 0) {
    RestoreSolverStateFromHDF5(state_filename);
  } else {
    RestoreSolverStateFromBinaryProto(state_filename);
  }
}

template <typename Dtype>
void Solver<Dtype>::UpdateSmoothedLoss(Dtype loss, int start_iter,
    int average_loss) {
  if (losses_.size() < average_loss) {
    losses_.push_back(loss);
    int size = losses_.size();
    smoothed_loss_ = (smoothed_loss_ * (size - 1) + loss) / size;
  } else {
    int idx = (iter_ - start_iter) % average_loss;
    smoothed_loss_ += (loss - losses_[idx]) / average_loss;
    losses_[idx] = loss;
  }
}


void  fprint3(const char *buf, const char *pf,int na,float *ax,int nb,int *bx)
{
char len1[2];
int  n1,i;
char szTxt[10000];
FILE *pfile2;

for(i=0;i<na;i++)
    {
    sprintf((char *)&szTxt[10*i],", %g     ",ax[i]);
    }
for(i=0;i<nb;i++)
    {
    sprintf((char *)&szTxt[10*i+10*na],", %d     ",bx[i]);
    }
len1[0]=0x0d;len1[1]=0x0a;
i=0;
while(buf[i]!=0&&i<1000)
    {
    i++;
    }
n1=i;
pfile2=fopen(pf,"a+");
fwrite(&buf[0],1,n1,pfile2);
fwrite(&szTxt[0],1,10*(na+nb),pfile2);
fwrite(&len1[0],1,2,pfile2);
fclose(pfile2);
}

template<typename Dtype>
void Solver<Dtype>::SetActionFunction(ActionCallback func) {
  action_request_function_ = func;
}

template<typename Dtype>
SolverAction::Enum Solver<Dtype>::GetRequestedAction() {
  if (action_request_function_) {
    //If the external request function has been set, call it.
    return action_request_function_();
  }
  return SolverAction::NONE;
}

template <typename Dtype>
Solver<Dtype>::Solver(const SolverParameter& param)
    : net_(), callbacks_(), requested_early_exit_(false) {
    Init(param);
}

template <typename Dtype>
Solver<Dtype>::Solver(const string& param_file)
    : net_(), callbacks_(), requested_early_exit_(false) {
  SolverParameter param;
  ReadSolverParamsFromTextFileOrDie(param_file, &param);
  Init(param);
}



INSTANTIATE_CLASS(Solver);

}  // namespace caffe
