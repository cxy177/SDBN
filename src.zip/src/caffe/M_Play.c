//#include <atlbase.h>
//#include <windows.h>
//#include <iostream>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <ftw.h>
//#include   <direct.h>
//#include <complex.h>
//#include <direct.h>

#include <stdio.h>
#include <stdlib.h>
//#include   <direct.h>
#include   <string.h>
#include "MFace_MAX_DEF.h"
#include "Data_Type.h"
#include "MFace_Type.h"

extern C_Filedata c_file;
extern C_Filedata  *gm_file;
extern CImage     c_image;
extern CMode      c_mode;
extern CBdot      c_bdot;
extern S_Frame    gm_sf;
extern Bdot       g_UB[40000];
extern int        g_U2[40000];
extern int		  gn_U,gn_U2,gn_U3,gn_U4,gn_yc,gn_UB,gn_yc2,LB[200];
extern int        g_show[6];

extern float      g_cv[300],g_Global_rho[10],g_Global_rho2[10];
extern float      FST2[100],FOT2[100];
extern float      fsin[1001];
extern float      facs[1001];
extern float      fcos[1001];
extern float      FCOS[10001];
extern float      FSIN[10001];
extern float      EXP[10001];
extern float      EXP2[10001];
extern float      FSQRT[1001];
extern float      FSQRT2[10001];
extern float      FATAN[2002];

extern CSA        g_csa[10];
extern SIN        g_sin[10];
extern int        Y_Base[1200],X_Base[2000];
extern int        Y_Base2[1200];
extern int        L_Base[1200],L_Base2[1200];

extern int        g_Winh,g_Winw,g_Wr;
extern int        g_Winh,g_Winw,g_Winh2,g_Winw2,g_Wr;
extern int        gn_pa3,gn_cp3,gn_r,gn_ds1,gn_ptz3,gn_ptz4,gn_zpl,gn_gtz3,gn_gtz2,gn_gtz,gn_ptz;
extern int        gm_zel,gm_cx;

extern int        gn_Dis,gn_lp,gn_lp2,gn_m4;
extern CP         g_cp[100],g_cp2[60],g_cp3[100];
extern int        gn_cp;

extern Vecl       g_vcl[4000],g_vcl2[200];
extern int        gn_vcl,gn_vcl2,gn_d,gn_d2,gn_d3,gn_pz,gn_pc;

extern CPoint2      g_pc[60];
extern Section      g_sc[40],g_sc2[40],g_sc3[40];
extern int         gn_sc,gn_sc2,gn_sc3;
extern int         g_Y[8000],gn_svm,gn_svm2,gn_svm3,gn_svm4,g_L,mix,gm_Dis,gm_Dis1,gm_Dis2,gm_Dis3,g_l1,g_l2,g_set[20],gn_set,gn_sv;
extern SVM         g_svm[10000];
extern Boundary    g_boundary[40];
extern int         g_bound[20],gm_bound,gs_boundary,g_curve12;
extern int         g_ra1[10],g_ra2[10],g_class;
extern float        g_blur[10000];

Point3     g_pz[80000];
int        c_file_width,gc_w,gc_h,g_w2,gc_w2,gc_w3,gc_w7;
int        c_file_height,gf_ncolor,gf_ncolor2,gn_pa,gn_pa2,gn_avec,gn_Dir;
int        g_b[10],g_b2[10],g_c[10],gn_Exa,g_b3,g_zd[10],g_b5,g_az[20],g_az2[400],g_zk[10],gx_pz,g_h2,gx_pz2;
int        gn_ki,g_jy,g_ix,g_iy,gn_w,gn_h,gn_zr,gn_zlk,gn_pz4,gn_pc2,gn_bor,g_ic,gn_Uin;
int        gn_Jd,gn_cs,gn_zp,gn_tp,gn_yp,gn_dot,gc_m,gc_m1,gn_Cdot2,gm_syn,ge_w[5],ge_avg[5],gn_SExt,gn_Ext,gn_SColor,gn_Gb,gn_Gb2,gn_fc;
int        gn_avec,gn_avec2,gn_EVec,gna_EVec,gn_EVec2,gna_EVec2,gna2_EVec,gna2_EVec2,g_mi2[100],g_mi3[100];
int        gA_range,gA_crange,gA_center,gC_Dist,gC_Dist2;
float      gc_tx[10],g_dmax[10],g_ax[400],g_cmax[7000];
Point2     gV_zpl,gc_EVec[100],gc_EVec2[100],gc_EVec3[100];
int        gun_z,gun_z2;
int        gn_play,gn_play2,gn_play3,gn_Lk,gn_Lk2,gn_up,gn_bp,g_bp[100],gm_play2;

S_Database   g_database[100];
int          gn_data,gs_data,gn_database,gs_database,g_mx,g_my,g_mx2,g_my2,gn_ker,gn_ker2,gp_data;
int          gn1_play,gn1_play2,gn1_play3;
int          gn_srec,gn_srec2,gn_dv,gn_show,gn_show2,gn_show3,gi_show[2000],gi_show2[200],gi_show3[200];
SRect        g_srec[20000],g_srec2[10000];
Aircraft     g_art[8000],g_art2[8000];
int          gn_art,gn_art2,gi_art[100],gi_art2[100],gn_image,gn_image2,gm_image,gm_start,gm_class2,g_fx2,gn_du,g_hx2,g_hy2,g_hx3,g_hy3,g_han,gn_lp;
Point        g_color[100],g_color2[100],g_color3[100];;
Point        g_pos[36],gi_o[100];
Play         g_ply[10];
HOG          g_Hog[6000];
P_HOG        *g_hog,*gh_svm,*g_data;;
P_LBP        *g_lbp;
P_BST        *g_bst;
P_HOC        *g_hoc,*gc_svm;
float        g_fx[100],g_fy[100],g_Gu[2500];
Rect         g_hrc,g_hrc2;
LPlay        g_lp[520];
RDF          g_rdf[1000];

int          gn_shbp,gm_shbp,g_han2,g_han3,gc_div,gs_hog2,gs_phog,gs_mi,gs_mi2,g_dir[2];
int          gn_W1,gn_W2,gn_W3,gn_W4,gs_WA,gs_HA,gs_L2,gn_buf,g_pn1,g_pn2;
Point2       gc_SLBP[40],g_pc2[2];
float        gc_han3[400],g_len2[10],g_len3[10],g_len4[10],g_radio;
Play         *g_play,*g_play2,*g_play3;
int          gn_C1,gn_C2,gn_C3,gn_obj,gn_o2,gn_bf,gm_nc,gn_dlbp,nc_lbp,c_lbp[1000],gn_man,gn_face,gn_pair,gn_pair2;
NPoint       g_C1[100],g_C2[100],g_C3[100];
Object       g_obj[15000];
char         gm_buf[260];
U8           g_fbuf[20000];
TWIST        g_tw[8];
GVP          g_gvp[25600];
DLBP         g_dlbp[40];
LBP          g_Lbp[60];
HOC          g_Hoc[6000];
BST          g_Bst[60];
P_BST        *gb_svm;
P_Fac        g_fac[6000];
M_Pair       *g_pair,*g_pair2;
int          amp[5000],anp[5000],gn_data2,g_p5;
P_HOG        gi_class[10000];

void c_Show_Play(int m,Play *p)
{
int   i1;
float len[2];
//for(i1=4;i1<5;i1++)
i1=0;
    {
    len[0]=p[0].len[i1];len[1]=0.75*len[0];
    c_Show_RectF(m,255,p[0].pc[0],p[0].dir[0],len);
    }
}


void c_Match_SR1(int md,int sr)
{
int i,j,i1,n1,n2,k,k1;
float t,t1,t2,t3,tx,ty,min;
Point2 p2;


}





int c_JS0_Direction(int m,float md,int th,Rect rec,int *mi,Point2 *p1,float *len)
{
int x,y,i,j,k,i1,i12,i2,i3,j1,j2,j3,k1,k2,k3,s1,na,n1,n2,kc,w,ki,kj,b2[10];
float t,t1,t2,t3,t4,tx,ty,max,max1,min1,l,l1,l2,ax[500],bx[500],cx[50],cx2[50],dx[50];
Point pc,p2,pa[2];
Point2 p0;
if(md<0) {pc.x=0;pc.y=th;}
if(md>0) {pc.x=th;pc.y=255;}

n1=1.73*(rec.x1-rec.x0)+5;if(n1<1.73*(rec.y1-rec.y0)+5) n1=1.73*(rec.y1-rec.y0)+5;
n2=2*n1;
s1=8*n1;
w=0.25*(rec.x1-rec.x0);

i2=0;p0.x=0;p0.y=0;t1=0;
for(j=rec.y0;j<rec.y1;j++)
    {
    y=j-rec.y0;
    for(i=rec.x0;i<rec.x1;i++)
        {
        x=i-rec.x0;
        k=c_image.Y_Base[j]+i;
        k1=c_mode.pLum[m][k];
        if(k1>=pc.x&&k1<=pc.y)
            {
            i1=LB[y]+x;

            g_UB[i1].v[0]=k1-pc.x+1;
            g_UB[i1].v[1]=k1-pc.x+1;
            g_U2[i2]=i1;i2++;
            p0.x+=g_UB[i1].v[0]*x;
            p0.y+=g_UB[i1].v[0]*y;
            t1+=g_UB[i1].v[0];
            }
        }
    }
gn_U2=i2;p0.x=p0.x/t1;p0.y=p0.y/t1;
k1=p0.y;
kc=LB[k1]+p0.x;


    max1=0;min1=1.e+12;
    for(i1=0;i1<gna2_EVec;i1=i1+2)
    //i1=0;0,3,10,23,33
    //i1=34;
        {

        i3=g_mi2[i1];
        memset(ax,0,s1);memset(bx,0,s1);
        for(j1=0;j1<gn_U2;j1++)
            {
            j=g_U2[j1];
            t=g_UB[j].z[i1]-g_UB[kc].z[i1];
            ty=fabs(g_UB[j].z[i3]-g_UB[kc].z[i3]);
            k1=t;t1=t-k1;	k2=k1+1;

            ax[k1+n1]+=(1.0-t1)*g_UB[j].v[0];
            ax[k2+n1]+=t1*g_UB[j].v[0];
            if(ty<=w) bx[k1+n1]+=g_UB[j].v[1];
            }
        c_jisu_avg2(1,n2,ax);
        t1=0;
        for(i=0;i<n2;i++)
            {
            t1+=bx[i];
            }
        if(t1<max1)
            {
            max1=t1;ki=i1;
            }
        max=0;t1=0;t2=0;l1=0;l2=0;
        for(i=0;i<n2;i++)
            {

            if(bx[i]>30) l1++;
            }
        cx[i1]=l1;dx[i1]=0;
        //gm_sf.ac[0]=max/250;gm_sf.ac[1]=b2[0];
        //c_Show_WCurve2(2,&ax[80],n2-160,0,1,b2,0);
        //gm_sf.show[1]=1;
        }
    b2[0]=2;b2[1]=10;b2[2]=22;b2[3]=34;
    b2[4]=max1/150;
    //gm_sf.ac[0]=max1/250;gm_sf.ac[1]=ki;

    //c_Show_WCurve2(2,cx2,40,0,4,b2,0);

    kj=g_mi2[ki];
    mi[0]=kj;

    l=0;
    p1[0].x=rec.x0+p0.x+dx[ki]*gc_EVec[ki].x+l*gc_EVec[kj].x;
    p1[0].y=rec.y0+p0.y+dx[ki]*gc_EVec[ki].y+l*gc_EVec[kj].y;

    len[0]=cx[kj]*0.65;
    //if(cx[kj]>rec.x1-rec.x0) len[0]=cx[kj]*0.75;
    if(len[0]<13) len[0]=13;

    len[1]=len[0]*0.8;
    return(1);
}





int c_JS_Direction(int m,float md,int th,Rect rec,int *mi,Point2 *p1,float *len)
{
int x,y,i,j,k,i1,i12,i2,i3,j1,j2,j3,k1,k2,k3,s1,na,n1,n2,kc,w,ki,kj,b2[10];
float t,t1,t2,t3,t4,tx,ty,max,max1,l,l1,l2,ax[500],bx[500],cx[50],cx2[50],dx[50];
Point pc,p2,pa[2];
Point2 p0;
if(md<0) {pc.x=0;pc.y=th;}
if(md>0) {pc.x=th;pc.y=255;}

n1=1.73*(rec.x1-rec.x0)+5;if(n1<1.73*(rec.y1-rec.y0)+5) n1=1.73*(rec.y1-rec.y0)+5;
n2=2*n1;
s1=8*n1;
w=0.25*(rec.x1-rec.x0);

i2=0;p0.x=0;p0.y=0;t1=0;
for(j=rec.y0;j<rec.y1;j++)
    {
    y=j-rec.y0;
    for(i=rec.x0;i<rec.x1;i++)
        {
        x=i-rec.x0;
        k=c_image.Y_Base[j]+i;
        k1=c_mode.pLum[m][k];
        if(k1>=pc.x&&k1<=pc.y)
            {
            i1=LB[y]+x;

            g_UB[i1].v[0]=k1-pc.x+1;
            g_UB[i1].v[1]=k1-pc.x+1;
            g_U2[i2]=i1;i2++;
            p0.x+=g_UB[i1].v[0]*x;
            p0.y+=g_UB[i1].v[0]*y;
            t1+=g_UB[i1].v[0];
            }
        }
    }
gn_U2=i2;p0.x=p0.x/t1;p0.y=p0.y/t1;
k1=p0.y;
kc=LB[k1]+p0.x;


    max1=0;
    for(i1=0;i1<gna2_EVec;i1=i1+2)
    //i1=0;0,3,10,23,33
    //i1=34;
        {

        i3=g_mi2[i1];
        memset(ax,0,s1);memset(bx,0,s1);
        for(j1=0;j1<gn_U2;j1++)
            {
            j=g_U2[j1];
            t=g_UB[j].z[i1]-g_UB[kc].z[i1];
            ty=fabs(g_UB[j].z[i3]-g_UB[kc].z[i3]);
            k1=t;t1=t-k1;	k2=k1+1;

            ax[k1+n1]+=(1.0-t1)*g_UB[j].v[0];
            ax[k2+n1]+=t1*g_UB[j].v[0];
            if(ty<=w) bx[k1+n1]+=g_UB[j].v[1];
            }
        c_jisu_avg2(1,n2,ax);
        max=0;t1=0;t2=0;l1=0;l2=0;
        for(i=0;i<n2;i++)
            {
            if(max<ax[i])
                {
                max=ax[i];
                k1=i;
                }
            if(bx[i]>30) l1++;
            }
        cx[i1]=l1;dx[i1]=k1-n1;
        cx2[i1]=max;
        if(max1<max)
            {
            max1=max;ki=i1;
            }
        b2[4]=max/110;
        b2[0]=k1-80;
        //gm_sf.ac[0]=max/250;gm_sf.ac[1]=b2[0];
        //c_Show_WCurve2(2,&ax[80],n2-160,0,1,b2,0);
        //gm_sf.show[1]=1;
        }
    b2[0]=2;b2[1]=10;b2[2]=22;b2[3]=34;
    b2[4]=max1/150;
    //gm_sf.ac[0]=max1/250;gm_sf.ac[1]=ki;

    //c_Show_WCurve2(2,cx2,40,0,4,b2,0);

    kj=g_mi2[ki];
    mi[0]=kj;

    l=0;
    p1[0].x=rec.x0+p0.x+dx[ki]*gc_EVec[ki].x+l*gc_EVec[kj].x;
    p1[0].y=rec.y0+p0.y+dx[ki]*gc_EVec[ki].y+l*gc_EVec[kj].y;

    len[0]=cx[kj]*0.65;
    //if(cx[kj]>rec.x1-rec.x0) len[0]=cx[kj]*0.75;
    if(len[0]<13) len[0]=13;

    len[1]=len[0]*0.8;
    return(1);
}




int c_JP_Direction(int m,Rect rec,int *mi,Point2 *p1,float *len)
{
int x,y,i,j,k,i1,i12,i2,i3,j1,j2,j3,k1,k2,k3,s1,na,n1,n2,kc,w,ki,kj,b2[10];
float t,t1,t2,t3,t4,tx,ty,max,max1,l,l1,l2,ax[500],bx[500],cx[50],cx2[50],dx[50];
Point pc,p2,pa[2];
Point2 p0;
float *ax2;

ax2=&c_file.pDis[2][m*g_mx2*g_my2];

n1=1.73*(rec.x1-rec.x0)+5;if(n1<1.73*(rec.y1-rec.y0)+5) n1=1.73*(rec.y1-rec.y0)+5;
n2=2*n1;
s1=8*n1;
w=0.25*(rec.x1-rec.x0);

i2=0;p0.x=0;p0.y=0;t1=0;
for(j=rec.y0;j<rec.y1;j++)
    {
    y=j-rec.y0;
    for(i=rec.x0;i<rec.x1;i++)
        {
        x=i-rec.x0;
        k=j*g_mx2+i;
        t=ax2[k];


            i1=LB[y]+x;

            g_UB[i1].v[0]=t;

            g_U2[i2]=i1;i2++;
            p0.x+=g_UB[i1].v[0]*x;
            p0.y+=g_UB[i1].v[0]*y;
            t1+=g_UB[i1].v[0];

        }
    }
if(t1<10) return(0);
gn_U2=i2;p0.x=p0.x/t1;p0.y=p0.y/t1;
k1=p0.y;
kc=LB[k1]+p0.x;


    max1=0;
    for(i1=0;i1<gna2_EVec;i1=i1+2)
        {

        i3=g_mi2[i1];
        memset(ax,0,s1);memset(bx,0,s1);
        for(j1=0;j1<gn_U2;j1++)
            {
            j=g_U2[j1];
            t=g_UB[j].z[i1]-g_UB[kc].z[i1];
            //ty=fabs(g_UB[j].z[i3]-g_UB[kc].z[i3]);
            k1=t;t1=t-k1;	k2=k1+1;

            ax[k1+n1]+=(1.0-t1)*g_UB[j].v[0];
            ax[k2+n1]+=t1*g_UB[j].v[0];
            }
        c_jisu_avg2(1,n2,ax);
        max=0;t1=0;t2=0;l1=0;l2=0;
        for(i=0;i<n2;i++)
            {
            if(max<ax[i])
                {
                max=ax[i];
                k1=i;
                }

            }
        dx[i1]=k1-n1;
        //cx2[i1]=max;
        if(max1<max)
            {
            max1=max;ki=i1;
            }

        }

    kj=g_mi2[ki];
    mi[0]=kj;
    //dx[ki]=0;
   // p1[0].x=rec.x0+p0.x+dx[ki]*gc_EVec[ki].x;
    //p1[0].y=rec.y0+p0.y+dx[ki]*gc_EVec[ki].y;

    p1[0].x=0.5*(rec.x0+rec.x1);
    p1[0].y=0.5*(rec.y0+rec.y1);

    len[0]=sqrt((rec.x1-rec.x0)*(rec.x1-rec.x0)+(rec.y1-rec.y0)*(rec.y1-rec.y0))*0.5;
    len[1]=len[0]*0.9;
    return(1);
}


void c_Play_Scan_2(int mk)
{
int   nk,ki,ki2,kw,kw1,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,h,w2,h2,n1,n2,nw,n3,w,m3,b[2],b2[2],m,md,f1;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;
int   g_ix,g_iy,gn_w,gn_h,c1,c2,ic,iw,ws[5];
Point2  p0,p1,p2,p3,pc[5];
Point  plum[10];


ws[0]=16;ws[1]=30;ws[2]=45;
ma=0.065;ma2=0.35;m=0;
//ma=0.1;ma2=0.35;m=0;
c_Mode_Zdot(3);md=1;
rec.x0=0;rec.x1=c_image.Width;rec.y0=0;rec.y1=c_image.Height;
gn_srec=0;gp_data=0;

nw=2;kw=0;
//if(mk==1) nw=3;
if(gs_boundary==2)
    {
    //kw=1;nw=3;
    }

for(iw=kw;iw<nw;iw++)
{
w=ws[iw];
h=w;gc_w=w;
gc_w2=gc_w*0.65;
n2=w*w;h2=h/2;w2=w/2;
gn_w=1.0*(rec.x1-rec.x0-1)/w2+0.5;gn_h=1.0*(rec.y1-rec.y0-1)/h2+0.5;
gn_srec2=0;
ic=1;

g_iy=0;g_ix=0;i3=0;i4=0;gn_pz=0;
    for(g_iy=0;g_iy<gn_h-1;g_iy++)
        {
        rc2.y0=g_iy*h2;rc2.y1=rc2.y0+h;if(rc2.y1>rec.y1-1) rc2.y1=rec.y1-1;

        for(g_ix=0;g_ix<gn_w-1;g_ix++)
            {
            rc2.x0=g_ix*w2;rc2.x1=rc2.x0+w;if(rc2.x1>rec.x1-1) rc2.x1=rec.x1-1;
            p0.x=0.5*(rc2.x0+rc2.x1);p0.y=0.5*(rc2.y0+rc2.y1);

            //p0.x=183;p0.y=288;
            //rc2.x0=p0.x-w2;rc2.x1=p0.x+w2;rc2.y0=p0.y-w2;rc2.y1=p0.y+w2;

            i2=0;
            p1.x=0;p1.y=0;t1=0;t2=0;

            ms[0]=0.2;
            c_Rect_Hist(ic,1,ms,rc2,b2);
            //b2[0]=1;
            for(y=rc2.y0;y<=rc2.y1;y++)
                {
                for(x=rc2.x0;x<=rc2.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;i2++;t1+=t;
                        }
                    }
                }

            p0.x=p1.x/t1;p0.y=p1.y/t1;
            s1=1.0*i2/((rc2.y1-rc2.y0+1)*(rc2.x1-rc2.x0+1));
            if(s1>ma2) goto lp3;
            if(s1<ma) goto lp3;
            n1=(rc2.y1-rc2.y0+1)*(rc2.x1-rc2.x0+1);

            y2=p0.y-gc_w2;y3=p0.y+gc_w2;
            x2=p0.x-gc_w2;x3=p0.x+gc_w2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            p2.x=0;p2.y=0;ia=0;ib=0;t1=0;t2=0;
            ms[0]=0.2;
            c_Rect_Hist(ic,1,ms,rc2,b2);
            for(y=y2;y<=y3;y++)
                {
                for(x=x2;x<=x3;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_file.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p2.x+=t*x;p2.y+=t*y;ia++;t1+=t;
                        }
                    }
                }
            n1=(y3-y2+1)*(x3-x2+1);
            p0.x=p2.x/t1;p0.y=p2.y/t1;
            s1=1.0*ia/n1;
            if(s1>ma2) goto lp3;
            if(s1<ma)  goto lp3;
             g_pz[gn_pz].x=p0.x;
             g_pz[gn_pz].y=p0.y;g_pz[gn_pz].s=1.0*ia/n1;g_pz[gn_pz].n=ia;
             g_pz[gn_pz].p0=p0;
             gn_pz++;
        lp3:
            t=0;
            }
        }

    m3=10;
        for(i=0;i<gn_pz;i++)
            {
            if(g_pz[i].s>0)
                {
                for(j=i+1;j<gn_pz;j++)
                    {
                    if(g_pz[j].s>0)
                        {
                        t=c_Get_Dist3(g_pz[i],g_pz[j]);
                        if(t<m3)
                            {
                            if(g_pz[i].s>=g_pz[j].s)
                                {
                                g_pz[j].s=0;
                                }
                           else if(g_pz[i].s<g_pz[j].s)
                                {
                                g_pz[i].s=0; goto lp4;
                                }
                            }
                        }
                    }
                }
        lp4:
            t=0;
            }
        t1=0;t2=0;
        for(i=0;i<gn_pz;i++)
            {
            if(g_pz[i].y>gc_w2&&g_pz[i].y<c_file.ImageHeight-gc_w2&&g_pz[i].x>gc_w2&&g_pz[i].x<c_file.ImageWidth-gc_w2&&g_pz[i].s>ma&&g_pz[i].s<ma2)//&&
                {
                p0.x=g_pz[i].x;p0.y=g_pz[i].y;
                y2=p0.y-gc_w2;y3=p0.y+gc_w2;
                x2=p0.x-gc_w2;x3=p0.x+gc_w2;
                if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
                if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
                rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;
                g_pz[i].r=rc3;
                g_pz[i].x=p0.x;g_pz[i].y=p0.y;
                g_pz[i].p0=p0;
                }
            else g_pz[i].s=0;
            }


k1=gn_srec2;
         for(i=0;i<gn_pz;i++)
            {
            if(g_pz[i].s>ma)
                {
                g_srec2[k1].rec=g_pz[i].r; g_srec2[k1].p0=g_pz[i].p0; g_srec2[k1].iw=iw; g_srec2[k1].ic=ic;	 g_srec2[k1].s=g_pz[i].s;
                k1++;
                }
            }
gn_srec2=k1;


k1=gn_srec;
         for(i=0;i<gn_srec2;i++)
            {
            if(g_srec2[i].s>0)
                {
                memcpy(&g_srec[k1],&g_srec2[i],sizeof(SRect));
                k1++;
                }
            }
gn_srec=k1;

}

ms[0]=0.2;
for(i=0;i<gn_srec;i++)
    {
    g_srec[i].t=0;
    ic=1;
    c_Rect_Hist(ic,1,ms,g_srec[i].rec,b2);
    k=c_JS_Direction(ic,ms[0],b2[0],g_srec[i].rec,g_srec[i].dir,&g_srec[i].p0,g_srec[i].len);
    c_Match_SR1(8,i);
    if(g_show[2]==1) c_Show_RectF(2,255,g_srec[i].p0,g_srec[i].dir[0],g_srec[i].len);

    }
//c_Match_SR2(0.65,1.35,0.85,0.35);

gn_svm2+=gn_srec;

for(i=0;i<10;i++)
{
g_fx[i]=1.0;g_fy[i]=1.0;
}
c_JF_Gus(16);

if(gs_boundary==-1) return;

}


void c_Play_Scan(int mk)
{
int   nk,ki,ki2,kw,kw1,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,h,w2,h2,n1,n2,nw,n3,w,m3,b[2],b2[2],m,md,f1;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;
int   g_ix,g_iy,gn_w,gn_h,c1,c2,ic,iw,ws[5];
Point2  p0,p1,p2,p3,pc[5];
Point  plum[10];
//U8     buf[1000];

ws[0]=16;ws[1]=30;ws[2]=45;
ma=0.065;ma2=0.35;m=0;
//ma=0.1;ma2=0.35;m=0;
c_Mode_Zdot(3);md=1;
rec.x0=0;rec.x1=c_image.Width;rec.y0=0;rec.y1=c_image.Height;
gn_srec=0;gp_data=0;
//memcpy(buf,&c_file.pLum[2][40000],1000);
nw=2;kw=0;
//if(mk==1) nw=3;
if(gs_boundary==2)
    {
    //kw=1;nw=3;
    }

for(iw=kw;iw<nw;iw++)
//iw=1;
{
w=ws[iw];
h=w;gc_w=w;
gc_w2=gc_w*0.65;
n2=w*w;h2=h/2;w2=w/2;
gn_w=1.0*(rec.x1-rec.x0-1)/w2+0.5;gn_h=1.0*(rec.y1-rec.y0-1)/h2+0.5;
gn_srec2=0;
for(ic=3;ic<=5;ic++)
//ic=3;
{
g_iy=0;g_ix=0;i3=0;i4=0;gn_pz=0;
    for(g_iy=0;g_iy<gn_h-1;g_iy++)
        {
        rc2.y0=g_iy*h2;rc2.y1=rc2.y0+h;if(rc2.y1>rec.y1-1) rc2.y1=rec.y1-1;

       for(g_ix=0;g_ix<gn_w-1;g_ix++)
            {
            rc2.x0=g_ix*w2;rc2.x1=rc2.x0+w;if(rc2.x1>rec.x1-1) rc2.x1=rec.x1-1;
            p0.x=0.5*(rc2.x0+rc2.x1);p0.y=0.5*(rc2.y0+rc2.y1);
            //p0.x=380;p0.y=725;
            //p0.x=804;p0.y=604;
            //p0.x=810;p0.y=802;
            //p0.x=592;p0.y=255;
            //p0.x=1266;p0.y=151;
            //p0.x=1202;p0.y=746;
            //p0.x=493;p0.y=72;
            rc2.x0=p0.x-w/2;rc2.x1=rc2.x0+w;rc2.y0=p0.y-w/2;rc2.y1=rc2.y0+w;
            i2=0;
            p1.x=0;p1.y=0;t1=0;t2=0;
            //ms[0]=0.2;
            //c_Rect_Hist(ic,1,ms,rc2,b2);
            //c_Show_Rect(rc2);
            b2[0]=1;
            for(y=rc2.y0;y<=rc2.y1;y++)
                {
                for(x=rc2.x0;x<=rc2.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;i2++;t1+=t;
                        }
                    }
                }

            p0.x=p1.x/t1;p0.y=p1.y/t1;

            //rc2.x0=p0.x-w/2;rc2.x1=rc2.x0+w;rc2.y0=p0.y-w/2;rc2.y1=rc2.y0+w; c_Show_Rect(rc2);
            //rc2.x0=p0.x-gc_w2;rc2.x1=p0.x+gc_w2;rc2.y0=p0.y-gc_w2;rc2.y1=p0.y+gc_w2; c_Show_Rect(rc2);
            //c_Show_Point5()
            s1=1.0*i2/((rc2.y1-rc2.y0+1)*(rc2.x1-rc2.x0+1));
            if(s1>ma2) goto lp3;
            if(s1<ma) goto lp3;
            s1=t1/i2;
            if(s1<30) goto lp3;
            //n1=(rc2.y1-rc2.y0+1)*(rc2.x1-rc2.x0+1);

            y2=p0.y-gc_w2;y3=p0.y+gc_w2;
            x2=p0.x-gc_w2;x3=p0.x+gc_w2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            p2.x=0;p2.y=0;ia=0;ib=0;t1=0;t2=0;
            //ms[0]=0.2;
            //c_Rect_Hist(ic,1,ms,rc2,b2);
            for(y=y2;y<=y3;y++)
                {
                for(x=x2;x<=x3;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_file.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p2.x+=t*x;p2.y+=t*y;ia++;t1+=t;
                        }
                    }
                }
            n1=(y3-y2+1)*(x3-x2+1);
            p0.x=p2.x/t1;p0.y=p2.y/t1;
            //rc2.x0=p0.x-gc_w2;rc2.x1=p0.x+gc_w2;rc2.y0=p0.y-gc_w2;rc2.y1=p0.y+gc_w2; c_Show_Rect(rc2);
            s1=1.0*ia/n1;
            if(s1>ma2) goto lp3;
            if(s1<ma)  goto lp3;

            s1=t1/ia;
            if(s1<30) goto lp3;
             g_pz[gn_pz].x=p0.x;
             g_pz[gn_pz].y=p0.y;g_pz[gn_pz].s=1.0*ia/n1;g_pz[gn_pz].n=ia;
             g_pz[gn_pz].p0=p0;
             gn_pz++;
        lp3:
            t=0;
            }
        }
    //return;
    m3=10;
        for(i=0;i<gn_pz;i++)
            {
            if(g_pz[i].s>0)
                {
                for(j=i+1;j<gn_pz;j++)
                    {
                    if(g_pz[j].s>0)
                        {
                        t=c_Get_Dist3(g_pz[i],g_pz[j]);
                        if(t<m3)
                            {
                            if(g_pz[i].s>=g_pz[j].s)
                                {
                                g_pz[j].s=0;
                                }
                           else if(g_pz[i].s<g_pz[j].s)
                                {
                                g_pz[i].s=0; goto lp4;
                                }
                            }
                        }
                    }
                }
        lp4:
            t=0;
            }
        t1=0;t2=0;
        for(i=0;i<gn_pz;i++)
            {
            if(g_pz[i].y>gc_w2&&g_pz[i].y<c_file.ImageHeight-gc_w2&&g_pz[i].x>gc_w2&&g_pz[i].x<c_file.ImageWidth-gc_w2&&g_pz[i].s>ma&&g_pz[i].s<ma2)//&&
                {
                p0.x=g_pz[i].x;p0.y=g_pz[i].y;
                y2=p0.y-gc_w2;y3=p0.y+gc_w2;
                x2=p0.x-gc_w2;x3=p0.x+gc_w2;
                if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
                if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
                rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;
                g_pz[i].r=rc3;
                g_pz[i].x=p0.x;g_pz[i].y=p0.y;
                g_pz[i].p0=p0;
                }
            else g_pz[i].s=0;
            }



k1=gn_srec2;
         for(i=0;i<gn_pz;i++)
            {
            if(g_pz[i].s>ma)
                {
                g_srec2[k1].rec=g_pz[i].r; g_srec2[k1].p0=g_pz[i].p0; g_srec2[k1].iw=iw; g_srec2[k1].ic=ic;	 g_srec2[k1].s=g_pz[i].s;
                k1++;
                }
            }
gn_srec2=k1;

}



k1=gn_srec;
         for(i=0;i<gn_srec2;i++)
            {
            if(g_srec2[i].s>0)
                {
                memcpy(&g_srec[k1],&g_srec2[i],sizeof(SRect));
                k1++;
                }
            }
gn_srec=k1;


}

ms[0]=0.5;
for(i=0;i<gn_srec;i++)
    {
    g_srec[i].t=0;
    ic=g_srec[i].ic;
    c_Rect_Hist(ic,1,ms,g_srec[i].rec,b2);
    k=c_JS_Direction(ic,ms[0],b2[0],g_srec[i].rec,g_srec[i].dir,&g_srec[i].p0,g_srec[i].len);
    c_Match_SR1(8,i);
    if(g_srec[i].is2>=0)
    {
        i1=g_srec[i].is;
       // g_art[i1].c++;
       //c_Show_RectF(3,255,g_srec[i].p0,g_srec[i].dir[0],g_srec[i].len);
    }
    //if(g_show[2]==1) c_Show_RectF(2,255,g_srec[i].p0,g_srec[i].dir[0],g_srec[i].len);
    }
//c_Match_SR2(0.65,1.35,0.85,0.35);



gn_svm2+=gn_srec;

for(i=0;i<10;i++)
{
g_fx[i]=1.0;g_fy[i]=1.0;
}
c_JF_Gus(16);


for(i=0;i<g_han2;i++)
{
gc_EVec2[i].x=cos(PAI/g_han2*i);
gc_EVec2[i].y=sin(PAI/g_han2*i);
}
for(i=g_han2;i<2*g_han2;i++)
{
gc_EVec2[i+g_han2].x=-gc_EVec2[i].x;
gc_EVec2[i+g_han2].y=-gc_EVec2[i].y;
}
g_han=g_han2;

for(i=0;i<g_han3;i++)
{
gc_EVec3[i].x=cos(PAI/g_han3*i);
gc_EVec3[i].y=sin(PAI/g_han3*i);
}
g_han=g_han2;

//c_Bitmap_Write3("/home/xychen/server/2a.bmp");
if(gs_boundary==-1) return;

}


void c_Add_Positive_Sample()
{
int   nk,ki,ki2,kw,kw1,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,h,w2,h2,n1,n2,nw,n3,w,m3,b[2],b2[2],m,md,f1;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;
int   g_ix,g_iy,gn_w,gn_h,c1,c2,ic,iw,ws[5];
Point2  p0,p1,p2,p3,pc[5];
Point  plum[10];


m=gs_database; i1=0;
for(i=0;i<g_database[m].np;i++)
        {


        g_srec[i1].p0.x=g_database[m].p[i].x;
        g_srec[i1].p0.y=g_database[m].p[i].y;
        max=0;
        for(j=0;j<40;j++)
            {
            t=fabs(g_lp[i].tx*gc_EVec[j].x+g_lp[i].ty*gc_EVec[j].y);
            if(t>max)
                {
                max=t;k=j;
                }
            }
        g_srec[i1].is=g_lp[i].is;
        g_srec[i1].dir[0]=k;
        g_srec[i1].len[0]=g_lp[i].l*1.2;
        g_srec[i1].len[1]=0.9*g_srec[i1].len[0];
        i1++;
        g_srec[i1].is=g_lp[i].is;
        g_srec[i1].dir[0]=k;
        g_srec[i1].len[0]=g_lp[i].l*0.95;
        g_srec[i1].len[1]=0.9*g_srec[i1].len[0];

        }

gn_srec=i1;


gn_svm2+=gn_srec;

for(i=0;i<10;i++)
{
g_fx[i]=1.0;g_fy[i]=1.0;
}
c_JF_Gus(16);


for(i=0;i<g_han2;i++)
{
gc_EVec2[i].x=cos(PAI/g_han2*i);
gc_EVec2[i].y=sin(PAI/g_han2*i);
}
g_han=g_han2;

for(i=0;i<g_han3;i++)
{
gc_EVec3[i].x=cos(PAI/g_han3*i);
gc_EVec3[i].y=sin(PAI/g_han3*i);
}
g_han=g_han2;

}


void c_SRect_HOG(int mk)
{
int     mi,mc,mk2,mk3,s1,nk,ki,ki2,kj,kj2,x,y,i,i1,ij1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,f1,f2,max1,max2,nk3,m1,m2,n1,n2,n3,na,nb,nb2,dy2,b2[10],b3[10],nk2,nz,y2,x2,y3;
float   t,t1,t2,t3,t4,tx,ty,tx2,len[10],ms[7],cx[10],v[200],lben[20],ma,*ax,buf[1000];
Point2  p2,p3,p4,pc[5];
Point   p1;
long    l1;
DP      *d;
Play    *p;
ARect   r;
Rect    rc2,rc3,rc4;
Boundary *b1;
SRect *sr;

for(mi=0;mi<gn_srec;mi++)
{
sr=&g_srec[mi];
if(mk==1)
{
if(sr[0].is<-1) goto lp1;
if(sr[0].is>=0)
{
p=&g_play2[gn_play2];

sr->ip=gn_play2;
gn_play2++;
p[0].Class=1;
p[0].Clas[0]=sr->is;p[0].Clas[1]=sr->is2;
}
if(sr[0].is==-1)
{
p=&g_play3[gn_play3];
sr->ip=gn_play3;
gn_play3++;
p[0].Class=-1;
p[0].Clas[0]=sr->is;p[0].Clas[1]=sr->is2;
}
}
else
{
    p=&g_play[gn_play];
    sr->ip=gn_play;
    gn_play++;
    p[0].Class=-1;
    p[0].Clas[0]=sr->is;p[0].Clas[1]=sr->is2;
    if(p[0].Clas[0]>=0) p[0].Class=1;
}


p[0].image=gs_database;p[0].pc[0]=sr->p0;p[0].dir[0]=sr->dir[0];p[0].len[0]=sr->len[0];p[0].len[1]=sr->len[1];


i2=0;gm_start=0;
//mc=0;c_Get_Image(mc,sr->p0,sr->dir[0],sr->len);
mc=0;c_Get_Image(mc,sr->p0,sr->dir[0],sr->len);

rc2.x0=0;rc2.x1=g_mx2;rc2.y0=0;rc2.y1=g_my2;


ms[0]=1; ms[1]=0.5; ms[2]=0.25; ms[3]=0.125;
b2[0]=0;
c_Rect_Hist2(0,mc,3,&ms[1],&b2[1],rc2);

for(i1=0;i1<4;i1++)
    {
    if(ms[i1]>=0) c_Get_Shape2(mc,i1,1,b2[i1],rc2);
    else c_Get_Shape2(mc,i1,0,b2[i1],rc2);
    }

rc2.x0=0;rc2.x1=g_mx2;rc2.y0=0;rc2.y1=g_my2;
rc3.x0=5;rc3.x1=g_mx2-5;rc3.y0=5;rc3.y1=g_my2-5;
m1=5;
rc4.x0=m1;rc4.x1=g_mx2-m1;rc4.y0=m1;rc4.y1=g_my2-m1;
//rc4.x0=g_mx-m1;rc4.x1=g_mx+m1;rc4.y0=m1;rc4.y1=g_my;
//rc4.x0=m1;rc4.x1=g_mx;rc4.y0=g_my-m1;rc4.y1=g_my+m1;

gm_start=0;
g_color2[0].x=gm_start;
for(i1=0;i1<4;i1++)
    {

    g_color2[i1].x=gm_start;

        c_JB_Gus(1,i1,5);
        c_JA_Gradient(p,i1,rc3,g_han2);


        c_JS_HOG(p,i1,rc3,1,1);
        c_JS_HOG(p,i1,rc3,2,2);
        c_JS_HOG(p,i1,rc3,3,3);
        c_JS_HOG(p,i1,rc3,4,4);
        //c_JS_HOG(p,i1,rc3,5,5);

    g_color2[i1].y=gm_start;
    }

//g_color2[0].y=gm_start;
    //c_Show_WinP(2,103+10+5*gs_HA,90+10);
    //c_Show_WinP(2,103+10+5*gs_HA-1,90+10-1);
gn_dv=gm_start;


lp1:
t=0;
}
}




void  c_JB_Gradient(int m1,int x0,int y0,HOG *h)
{
int i,j,i1,j1,k,k1,m2,m3,x,y,n1;
float t,t1,t2,t3,t4,tx,ty,*ax,*bx,*cx,max,cx2[40],vx,vy,dx,dy;
ax=&c_file.pDis[2][m1*g_mx2*g_my2];
bx=&c_file.pDis[1][m1*g_mx2*g_my2];
//cx=&c_file.pDis[3][m1*g_mx2*g_my2];
//cx2=&c_file.pDis[4][m1*g_mx2*g_my2];

h[0].v1=bx[y0*g_mx2+x0];
h[0].v2=ax[y0*g_mx2+x0];
//x0=g_mx+g_mx/3;
//y0=g_my-10;
n1=m2*m3;
//m2=3;m3=5;
//m2=4;m3=2;
m2=4;m3=1;
//m2=2;m3=6;

tx=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        k=y*g_mx2+x;
        tx+=ax[k]*t1;
        }
    }
ty=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;k=y*g_mx2;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        k1=k+x;
        ty+=ax[k1]*t1;
        }
    }
tx=tx;ty=ty;

if(ty!=0)
{
h->a=atan(tx/ty);
h->a=h->a+3.1415926/2;
}
if(ty==0) h->a=0;
if(h->a>3.14159) h->a=3.14159;
if(h->a<0) h->a=0;
h->i=(h->a*g_han)/3.1415926;

for(i=0;i<g_han;i++)
    {
    t=fabs(tx*gc_EVec2[i].x+ty*gc_EVec2[i].y);
    cx2[i]=t;
    h->d[i]=0;
    }




h->tx=tx;h->ty=ty;
        t2=tx*ty;
        dx=x0-g_mx;dy=y0-g_my;
        vx=-100;

        if(fabs(tx)>0.0001)
            {
            vx=x0+dy*(ty/tx);
            }

        vy=-100;

        if(fabs(ty)>0.0001)
                {
                vy=y0+dx*(tx/ty);
                }

        h->dx=vx;h->dy=vy;




if(tx<0) tx=-tx;
if(ty<0) ty=-ty;

if(tx==0&&ty==0)
    {
    h->v=0;
    goto lp1;
    }

if(tx>ty)
    {
    k=ty/tx*1000;
    h->v=FSQRT[k]*tx;
    }
else
    {
    k=tx/ty*1000;
    h->v=FSQRT[k]*ty;
    }
lp1:
//h->tx=h->tx/h->v;h->ty=h->ty/h->v;

//k=y0*g_mx2+x0;
//cx[k]=h->v;

max=0;k=0;
for(i=0;i<g_han;i++)
    {
    t=cx2[i];
    if(max<t)
    {
     max=t;k=i;
    }
    }

 if(gs_phog==2) h->d[k]=cx2[k];
 if(gs_phog==1) h->d[k]=h->v;
max=0;k1=0;
for(i=0;i<g_han;i++)
    {
    t=cx2[i];
    if(max<t&&i!=k)
    {
     max=t;k1=i;
    }
    }
 if(gs_phog==1) h->d[k1]=cx2[k1];

}

int  c_JS_HOG24(Play *pl,int m1,Rect rc2)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1,dx2,dy2;
float max,s,t,t1,t2,v1,cx[160];
HOG  *h;
Point p0;
Rect  rc3;
h=&c_file.pHog[m1*g_mx2*g_my2];

memset(cx,0,16*g_han);
i1=0;t1=0;max=0;

t2=0;dx2=rc2.x1-rc2.x0;dy2=rc2.y1-rc2.y0;
for(i2=0;i2<2;i2++)
{

rc3.x0=rc2.x0+i2*dx2/2;rc3.x1=rc2.x0+(i2+1)*dx2/2;
for(j1=0;j1<2;j1++)
{
rc3.y0=rc2.y0+j1*dy2/2;rc3.y1=rc2.y0+(j1+1)*dy2/2;
i3=(i2*2+j1)*g_han;
for(x=rc3.x0;x<rc3.x1;x++)
    {
    for(y=rc3.y0;y<rc3.y1;y++)
        {
        i1=y*g_mx2+x;
        //if(h[i1].v>=0)
        for(j=0;j<2*g_han;j++)
            {
            //t2+=h[i1].v;
            //i=h[i1].i;
            cx[i2+j]+=h[i1].d[j];


            }
        }
    }
}
}
s=t2;
i1=0;t1=0;
max=0;t2=0;
for(i=0;i<4*g_han;i++)
    {
    //if(max<cx[i]) max=cx[i];
    if(gs_L2==1) t2+=cx[i]*cx[i];
    if(gs_L2==2) t2+=cx[i];
    }
if(gs_L2==1) t2=sqrt(t2);
i2=gm_start;
for(i=0;i<4*g_han;i++)
    {
    if(t2>0) pl[0].ipf[i2]=cx[i]/(t2+0.001);
    i2++;
    }
gm_start=i2;
return(1);
}

int  c_JS_HOG2(Play *pl,int m1,Rect rc2)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1,dx2,dy2;
float max,s,t,t1,t2,v1,cx[80];
HOG  *h;
Point p0;
Rect  rc3;
h=&c_file.pHog[m1*g_mx2*g_my2];

memset(cx,0,8*g_han);
i1=0;t1=0;max=0;

t2=0;

for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        //if(h[i1].v>=0)
        for(j=0;j<g_han;j++)
            {
            cx[j]+=h[i1].d[j];
            }
        }
    }
s=t2;
i1=0;t1=0;
max=0;t2=0;
for(i=0;i<g_han;i++)
    {
    if(gs_L2==1) t2+=cx[i]*cx[i];
    if(gs_L2==2) t2+=cx[i];
    }
if(gs_L2==1) t2=sqrt(t2);
i2=gm_start;
for(i=0;i<g_han;i++)
    {
    if(t2>0) pl[0].ipf[i2]=cx[i]/(t2+0.001);
    i2++;
    }
gm_start=i2;
return(1);
}

int  c_JS_HOG(Play *p,int m1,Rect rc1,int mx,int my)
{
int i,j,k,k1,k2,i1,i2,i3,j1,j2,n1,dy2,dx2;
float t,t1,t2,max,max1,cx[100];
Rect  rc2;
Point p0;
dx2=rc1.x1-rc1.x0;dy2=rc1.y1-rc1.y0;
t1=0;n1=mx*my;i1=0;k2=gm_start;
for(j2=0;j2<my;j2++)
{
rc2.y0=rc1.y0+(j2*dy2)/my;rc2.y1=rc1.y0+((j2+1)*dy2)/my;
for(i3=0;i3<mx;i3++)
{
rc2.x0=rc1.x0+(i3*dx2)/mx;rc2.x1=rc1.x0+((i3+1)*dx2)/mx;
c_JS_HOG2(p,m1,rc2);

i1++;
}
}




return(1);
}



void  c_PI_V1(Play *p,int md,int m1,int mt,Rect rec,float mr,int mx,int my,int m2,int m3)
{
int i,j,i1,j1,k,k1,dx2,dy2,x,y,x0,y0,x1,y1,i2,i3,j2,s1,s2;
float t,t1,t2,tx,ty,v[50];
Point pc;
Rect  rc2;
HOG  *ax;
dx2=rec.x1-rec.x0;dy2=rec.y1-rec.y0;

t2=0;s1=gm_start;
for(j2=0;j2<my;j2++)
    {
    rc2.y0=(j2*dy2)/my+rec.y0;rc2.y1=((j2+1)*dy2)/my+rec.y0;
    for(i3=0;i3<mx;i3++)
        {
        rc2.x0=(i3*dx2)/mx+rec.x0;rc2.x1=((i3+1)*dx2)/mx+rec.x0;
        if(gs_hog2==1) c_PI_V20(p,md,m1,mt,rc2,m2,m3);
        if(gs_hog2==2) c_PI_V2(p,md,m1,mt,rc2,m2,m3);
        }
    }
s2=gm_start;
t1=0;t2=0;
for(i=s1;i<s2;i++)
    {
    t1+=p[0].ipf[i];
    }

for(i=s1;i<s2;i++)
    {
    //p[0].ipf[i]=p[0].ipf[i]/(t1+0.001);
    }
}

void  c_PI_V20(Play *p,int md,int m1,int mt,Rect rec,float mr,int mx,int my)
{
int i,j,i1,j1,k,k1,k2,dx,dy,dx2,dy2,x,y,xc,yc,x0,y0,x1,y1,i2,i3,j2,n1;
float t,t1,t2,t3,t4,tv,tx,ty,vx,vy,max,max1,*ax,v[600];
Point p0,pc;
Point2 p1,p2;
Rect  rc2;
HOG  *h;

mx=g_mx2;my=g_my2;
memset(v,0,4*(mx+my));
h=&c_file.pHog[m1*g_mx2*g_my2];

t1=0;max=0;
for(y=rec.y0;y<rec.y1;y++)
    {
    //t=fabs(y-g_my)/g_my;
    //if(t<mr) goto lp1;
    k1=y*g_mx2;
    for(x=rec.x0;x<rec.x1;x++)
        {
        //t=fabs(x-g_mx)/g_mx;
        //if(t<mr) goto lp0;
        k=k1+x;
        if(mt==0) tv=h[k].v1;
        if(mt==1) tv=h[k].v2;
        if(mt==2) tv=h[k].v;
        if(mt==3) tv=h[k].c;
        tv=h[k].v2;
        if(tv>max) max=tv;
        t1+=tv;
        tx=h[k].tx;ty=h[k].ty;

        vx=h[k].dx;vy=h[k].dy;

        //vx=x;vy=y;
        if(vx>=0&&vx<g_mx2)
            {
            i=vx*mx/g_mx2;
            v[i]+=tv;
            }
        if(vy>=0&&vy<g_my2)
            {
            i=vy*my/g_my2;
            v[i+mx]+=tv;
            }
lp0:
        t=0;
        }
lp1:
    t=0;
    }

c_jisu_avg2(2,mx,v);
c_jisu_avg2(2,my,&v[mx]);


c_JB_IPF(g_mx2,v,p,5,5);
c_JB_IPF(g_my2,&v[g_mx2],p,5,5);
}

void  c_PI_V2(Play *p,int md,int m1,int mt,Rect rec,int m2,int m3)
{
int i,j,i1,j1,k,k1,k2,kc,dx,dy,dx2,dy2,x,y,xc,yc,x0,y0,x1,y1,i2,i3,j2,n1,mx,my,mi,mi2;
float t,t1,t2,t3,t4,tv,tx,ty,vx,vy,max,max1,*ax,len[2],v[600];
Point p0,pc;
Point2 p1,p2;
Rect  rc2;
float  *ah;





memset(v,0,8*100);
ah=&c_file.pDis[2][m1*g_mx2*g_my2];


k=c_JP_Direction(m1,rec,&mi,&p1,len);
//gs_mi=mi;
/*i2=gm_start;

    pl[0].ipf[i2]=p1.x0-rec.x0;i2++;
    pl[0].ipf[i2]=p1.y0-rec.y0;i2++;
    pl[0].ipf[i2]=mi;i2++;

gm_start=i2;*/


x0=10+m1*100;y0=10;
//c_Show_WRectF(x0,y0,2,255,p1,mi,len);

if(k==0) goto lp1;
mi2=g_mi2[mi];
k1=p1.y;
kc=LB[k1]+p1.x;

for(y=0;y<g_my2;y++)
    {

    k1=y*g_mx2;
    for(x=0;x<g_mx2;x++)
        {                 
        i1=LB[y]+x;
        tx=g_UB[i1].z[mi]-g_UB[kc].z[mi];
        ty=g_UB[i1].z[mi2]-g_UB[kc].z[mi2];
        if(fabs(ty)<len[0]&&fabs(tx)<len[1])
        {
        k=k1+x;
        tv=ah[k];


        i=15.0*(tx+len[0])/len[0];
        v[i]+=tv;
        i=15.0*(ty+len[1])/len[1];
        v[i+30]+=tv;

        }

        }

    }
lp1:
c_jisu_avg2(2,30,v);
c_jisu_avg2(2,30,&v[30]);

c_JB_IPF(30,v,p,5,5);
c_JB_IPF(30,&v[30],p,5,5);

}

int  c_JS_IPF(Play *p,int md,Rect rec,int m1,int mx,int my,int mv,int mh)
{
int i,j,k,k1,k2,i1,i2,i3,j1,j2,n1,s1,s2,dx2,dy2;
float t,t1,t2,max,max1,cx[100];
Rect  rc2;
Point p0;
dx2=rec.x1-rec.x0;dy2=rec.y1-rec.y0;

t1=0;n1=mx*my;i1=0;s1=gm_start;
for(j2=0;j2<my;j2++)
{
rc2.y0=rec.y0+(j2*dy2)/my;rc2.y1=rec.y0+((j2+1)*dy2)/my;
for(i3=0;i3<mx;i3++)
{
rc2.x0=rec.x0+(i3*dx2)/mx;rc2.x1=rec.x0+((i3+1)*dx2)/mx;
cx[i1]=c_JA_IPF(md,m1,rc2);
c_JB_IPF(rc2.x1-rc2.x0,g_ax,p,mv,mh);
c_JB_IPF(rc2.y1-rc2.y0,&g_ax[g_mx2],p,mv,mh);
t1+=cx[i1];
i1++;
}
}
s2=gm_start;

t1=0;t2=0;
for(i=s1;i<s2;i++)
    {
    t1+=p[0].ipf[i];
    }

for(i=s1;i<s2;i++)
    {
    //p[0].ipf[i]=p[0].ipf[i]/(t1+0.001);
    }
return(1);
}

float c_JA_IPF(int md,int m1,Rect rc2)
{
int   i,j,k,i1,j1,k1,u3,u4,v3,v4,mk;
float t,t1,t2,t3,*ax;
ax=&c_file.pDis[md][m1*g_mx2*g_my2];
memset(g_ax,0,8*g_mx2);

i1=0;
t2=0;
for(i=rc2.x0;i<rc2.x1;i++)
    {
    t1=0;
    for(j=rc2.y0;j<rc2.y1;j++)
        {
        k=j*g_mx2+i;
        t1+=ax[k];
        }
    g_ax[i1]=t1;i1++;
    t2+=t1;
    }

i1=0;
for(j=rc2.y0;j<rc2.y1;j++)
    {
    t1=0;j1=j*g_mx2;
    for(i=rc2.x0;i<rc2.x1;i++)
        {
        k=j1+i;
        t1+=ax[k];
        }
    g_ax[i1+g_mx2]=t1;i1++;
    }

return(t2);
}



void c_JB_IPF(int na,float *ax,Play *pl,int mv,int mh)
{
int i,j,i1,k,i2,x,x1,x2;
float t,t1,t2,v[10],v2[10],h[100],max2,ma,s;

memset(&pl[0].ipf[gm_start],0,(mv+mh)*4);
memset(h,0,g_mx2*4);
max2=0;s=0;
for(i=0;i<na;i++)
    {
    t=ax[i];s+=t;
    if(t>max2)
        {
        max2=t;
        }
    }

if(max2>0)
{
t1=0;t2=0;
i2=gm_start;
for(i1=0;i1<mv;i1++)
    {
    ma=1.0*(i1+0.5)*max2/mv;
    v[0]=0;
    for(i=0;i<na;i++)
        {
        if(ax[i]>=ma)
            {
            t=1;
            if(ax[i]<ma+1) t=ax[i]-ma;
            v[0]+=t;
            }
        }
    pl[0].ipf[i2]=v[0]/na;

    i2++;
    }

for(i1=0;i1<mh;i1++)
    {
    x1=(i1*na)/mh;x2=((i1+1)*na)/mh-1;
    t=0;
    for(x=x1;x<x2;x++)
    {t+=ax[x];}
    if(s>0) pl[0].ipf[i2]=t/s;
    i2++;
    }
    }


gm_start+=mv+mh;


}

void  c_JB_Gus(int m1,int m2,int mx)
{
int i,j,i1,i2,j1,k,k1,k2,x,y,n1;
float t,t1,tx,ty,v1,v2,min,max,max1,max2,max3,*ax,*bx,*cx,*cx2,*cx3;
Point p0;
ax=&c_file.pDis[0][(m2+10)*g_mx2*g_my2];
memset(ax,0,4*g_mx2*g_my2);

ax=&c_file.pDis[1][m2*g_mx2*g_my2];
bx=&c_file.pDis[2][m2*g_mx2*g_my2];
memset(bx,0,4*g_mx2*g_my2);
cx=&c_file.pDis[4][m2*g_mx2*g_my2];cx2=&c_file.pDis[4][(m2+10)*g_mx2*g_my2];cx3=&c_file.pDis[4][(m2+20)*g_mx2*g_my2];

n1=4*mx*mx;max=0;min=999999;
for(i=0;i<g_mx2;i++)
    {
    for(j=0;j<g_my2;j++)
        {
        t=0;k2=j*g_mx2+i;i2=0;
        if(mx>0)
        {
        for(i1=-mx;i1<=mx;i1++)
            {
            x=i+i1;
            if(x<0) x=0; if(x>=g_mx2) x=g_mx2-1;
            for(j1=-mx;j1<=mx;j1++)
                {
                y=j+j1;
                if(y<0) y=0; if(y>=g_my2) y=g_my2-1;
                k=y*g_mx2+x;
                k1=i1*i1+j1*j1;
                t+=ax[k]*g_Gu[k1];
                i2++;
                }
            }
        }
        else t=ax[k2];
        if(t>1.e+9)
        {
        t=0;
        }
        bx[k2]=t;
        if(i2>0) bx[k2]=t/i2;
        if(bx[k2]>max) max=bx[k2];
        if(bx[k2]<min) min=bx[k2];
        }
    }
v1=max-min;
for(i=0;i<g_mx2;i++)
    {
    for(j=0;j<g_my2;j++)
        {
        k2=j*g_mx2+i;
        if(v1>0)
        {t=(bx[k2]-min)/v1*255;
        bx[k2]=t;}
        //p0.x=i+10+m2*100;
        //p0.y=j+10;
        //c_Show_WinP3(p0.x,p0.y,t);
        }
    }

}

int  c_JA_CUR(Play *pl,int m1,Rect rc2)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1;
float s,t,t1,t2,max,cx[40];
HOG  *h;
Point p0;
h=&c_file.pHog[m1*g_mx2*g_my2];

memset(cx,0,4*g_han);
i1=0;t1=0;max=0;
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        //c_JB_CUR(m1,x,y);
        if(h[i1].c>max) max=h[i1].c;
        //c_JB_CUR1(m1,x,y,&h[i1]);
        }
    }
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        t=h[i1].c/max*255;
        p0.x=x+10;
            p0.y=y+10+m1*gs_HA;
            ////c_Show_WinP3(p0.x,p0.y,t);

        }
    }
g_hrc2=rc2;g_hx3=rc2.x1-rc2.x0;g_hy3=rc2.y1-rc2.y0;


return(1);
}









void c_PLum_D1(Play *p,Rect rec,int m1,int *b2)
{
int     i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,x,y,x0,x1,y0,y1,n1,n2,n3;
float   t,t1,t2,t3,*ax,v[3];
ax=&c_file.pDis[0][m1*g_mx2*g_my2];
v[0]=0;v[1]=0;v[2]=0;n1=0;n2=0;n3=0;
        for(y=rec.y0;y<rec.y1;y++)
            {
            k=y*g_mx2;
            for(x=rec.x0;x<rec.x1;x++)
                {
                t=ax[k+x];
                if(t>=b2[0])
                    {
                    v[0]+=t;n1++;
                    }
                if(t>=b2[2]&&t<=b2[1])
                    {
                    v[1]+=t;n2++;
                    }
                if(t>=b2[3])
                    {
                    v[2]+=t;n3++;
                    }
                }
            }

v[0]=v[0]/n1;v[1]=v[1]/n2;v[2]=v[2]/n3;
p[0].ipf[gm_start]=v[0];
p[0].ipf[gm_start+1]=v[1];
p[0].ipf[gm_start+2]=v[2];
p[0].ipf[gm_start+3]=v[0]-v[1];
gm_start+=4;
}











void c_Get_Shape(int md2,int mt,int th,Rect rc2)
{
int x2,y2,y3;
float t,v;
memset(c_file.pDis[1],0,4*g_mx2*g_my2);
for(y2=rc2.y0;y2<rc2.y1;y2++)
    {
    y3=y2*g_mx2;
    for(x2=rc2.x0;x2<rc2.x1;x2++)
        {
        t=c_file.pDis[0][y3+x2];
        v=0;
                if(md2<=0&&t<=th)
                    {
                    v=th-t+mt;	//v=1;

                    }
                if(md2>0&&t>=th)
                    {
                    v=t-th+mt;	//v=1;
                    }
        c_file.pDis[1][y3+x2]=v;
        }
    }
}


void c_Get_Shape2(int m1,int m2,int mt,int th,Rect rc2)
{
int x2,y2,y3,n1,n2;
float t,v,*ax,*bx,buf[1000];
Point p0;
n1=m1*g_mx2*g_my2;
n2=m2*g_mx2*g_my2;
ax=&c_file.pDis[1][n2];
bx=&c_file.pDis[0][n1];
memset(ax,0,4*g_mx2*g_my2);
for(y2=rc2.y0;y2<rc2.y1;y2++)
    {
    y3=y2*g_mx2;
    for(x2=rc2.x0;x2<rc2.x1;x2++)
        {
        t=bx[y3+x2];
        v=0;
        if(mt==1&&t>th&&th<255)
        {
        v=(t-th)/(255-th+0.001)*255;
        }

        if(mt==0&&t<th)
        {
        v=(th-t+60)/(th+60)*255;
        }
        if(v>255)
        {
        v=255;
        }
        if(mt==1&&t>=255)
        {
        v=255;
        }
        ax[y3+x2]=v;




            p0.y=x2+10;
            p0.x=y2+10+m2*100;
            c_Show_WinP3(p0.x,p0.y,v);





        }
    }

//memcpy(buf,&c_file.pDis[1][5*g_mx2*g_my2+1600],4000);
}

















void c_JS_Scale(int na,float *ax,Play *pl)
{
int i,j,i1,k,i2,x,x1,x2,mv;
float t,t1,t2,v[10],v2[10],h[100],max2,ma,s;

memset(&pl[0].ipf[gm_start],0,4);
max2=0;s=0;
for(i=0;i<na;i++)
    {
    t=ax[i];s+=t;
    if(t>max2)
        {
        max2=t;
        }

    }
mv=7;i2=gm_start;
if(max2>0)
{
t1=0;t2=0;
    ma=0.5*max2/mv;
    v[0]=0;
    for(i=0;i<na;i++)
        {
        if(ax[i]>=ma)
            {
            t=1;
            if(ax[i]<ma+1) t=ax[i]-ma;
            v[0]+=t;
            }
        }
    pl[0].ipf[i2]=v[0]*pl[0].len[0]/na;
    //pl[0].ipf[i2]=v[0]/na;


}
gm_start+=1;
}


void c_JS_Continuity(int na,float *ax,Play *pl)
{
int i,j,i1,k,i2,x,x1,x2,x3,mv,dx2;
float t,t1,t2,v[10],v2[10],h[100],max2,ma,s;

memset(&pl[0].ipf[gm_start],0,4);
max2=0;s=0;
for(i=0;i<na;i++)
    {
    t=ax[i];s+=t;
    if(t>max2)
        {
        max2=t;
        }

    }
mv=7;i2=gm_start;
if(max2>0)
{
t1=0;t2=0;
    ma=0.5*max2/mv;
    v[0]=0;	v[1]=0;
    for(i=0;i<na;i++)
        {
        if(ax[i]>=ma)
            {
            t=1;
            //if(ax[i]<ma+1) t=ax[i]-ma;
            v[0]+=t;
            v[1]+=t*i;
            }
        }
    dx2=v[0];

    x2=v[1]/v[0];
    v[2]=0;
    x1=x2-dx2/2;
    x3=x2+dx2/2;
    for(i=x1;i<=x3;i++)
        {
        if(ax[i]>=ma)
            {
            t=1;
            if(ax[i]<ma+1) t=ax[i]-ma;
            v[2]+=t;
            }
        }
    pl[0].ipf[gm_start]=v[2]/(x3-x1+1);
    //pl[0].ipf[i2]=v[0]/na;


}
gm_start+=1;
}



void c_List_Play(int x0,int y0,float *ax)
{
int   k,k1,k2;
int   x,y,i,j;
U8    *p;
long l1,l2;


for(j=0;j<g_my2;j++)
    {
    y=j+y0;
    for(i=0;i<g_mx2;i++)
        {
        x=i+x0;
        l1=L_Base[y]+3*x;
        p=&gm_file->pDIBdata[l1];
        k=j*g_mx2+i;
        k1=0;
        if(ax[k]>0) k1=120+ax[k];
        if(k1>255) k1=255;
        p[2]=k1;p[1]=k1;p[0]=k1;
        }
    }

}

void c_Play_Show(int m)
{
int i,j,k,k1,k2,k3,k4,i1,i2,i3,j1,j2,n1,n2,nx,ny,x,y,ki;
Play *p;
float *pf;
if(m==0)
{
n1=gn_play;
p=&g_play;
}
if(m==1)
{
n1=gn_play2;
p=&g_play2;
}
if(m==2)
{
n1=gn_play3;
p=&g_play3;
}

c_Show_White(1);

nx=c_file.ImageWidth/(g_mx2+10);
ny=c_file.ImageHeight/(g_my2+10);
i2=0;
n2=g_mx2*g_my2;
for(ki=0;ki<5;ki++)
{
for(i=0;i<n1;i++)
    {
    if(p[i].Class==1)
        {
        k=p[i].p_data+ki*n2;
        pf=&c_file.pDis[2][k];
        j1=i2/nx;
        i1=i2-j1*nx;
        if(j1<ny)
            {
            x=i1*(g_mx2+10)+5;
            y=j1*(g_my2+10)+5;
            c_List_Play(x,y,pf);
            i2++;
            }
        else return;
        }
    }
}


}


void c_Play_Show2(int m,int m2)
{
int i,j,k,k1,k2,k3,k4,i1,i2,i3,j1,j2,n1,nx,ny,x,y;
Play *p;
float *pf;
if(m==0)
{
n1=gn_play;
p=&g_play;
}
if(m==1)
{
n1=gn_play2;
p=&g_play2;
}
if(m==2)
{
n1=gn_play3;
p=&g_play3;
}

c_Show_White(1);

nx=c_file.ImageWidth/(g_mx2+10);
ny=c_file.ImageHeight/(g_my2+10);
i2=0;
for(i=0;i<n1;i++)
    {
    if(p[i].t1>=m2)
        {
        k=p[i].p_data;
        pf=&c_file.pDis[2][k];
        j1=i2/nx;
        i1=i2-j1*nx;
        if(j1<ny)
            {
            x=i1*(g_mx2+10)+5;
            y=j1*(g_my2+10)+5;
            c_List_Play(x,y,pf);
            if(i==gi_show2[0]) c_Show_Point4(20,x+20,y+15);
            i2++;
            }
        else return;
        }
    }
}




void c_JS_Normal()
{
int i,j,k,k1,k2,k3,k4,i1,i2,i3,j1,j2,j3,n1,n2,n3,nx,ny;
float t,t1,t2,t3,t4;
Play *p,*p2,*p3;

n1=gn_play2;n2=gn_play3;n3=gn_play;
p=&g_play2;p2=&g_play3;p3=&g_play;
//gn_dv=gm_start;

memset(g_cmax,0,4*gn_dv);
            j2=0;
            for(j1=0;j1<n1;j1++)
                {

                    for(i=0;i<gn_dv;i++)
                        {
                        if(g_cmax[i]<fabs(p[j1].ipf[i])) g_cmax[i]=fabs(p[j1].ipf[i]);
                        }

                }

            for(j1=0;j1<n2;j1++)
                {

                    for(i=0;i<gn_dv;i++)
                        {
                        if(g_cmax[i]<fabs(p2[j1].ipf[i])) g_cmax[i]=fabs(p2[j1].ipf[i]);
                        }

                }
}


void c_JS_Normal2()
{
int i,j,k,k1,k2,k3,k4,i1,i2,i3,j1,j2,j3,n1,n2,n3,nx,ny;
float t,t1,t2,t3,t4;
Play *p,*p2,*p3;

n3=gn_play;p3=&g_play;
        for(j1=0;j1<n3;j1++)
                {
                for(i=0;i<gn_dv;i++)
                    {
                    if(g_cmax[i]>0) p3[j1].ipf[i]=p3[j1].ipf[i]/g_cmax[i];
                    else p3[j1].ipf[i]=0;
                    }
                }

}


void c_SVM_PFile()
{
int i,j,k,k1,k2,k3,k4,i1,i2,i3,j1,n1,n2;
Play *p,*p2;
U8    path[260],*buf;
FILE  *f2;


n1=gn_play2;n2=gn_play3;
p=&g_play2;p2=&g_play3;

memcpy(path,gm_file->input_path,260);
i=0;
while(path[i]!=0&&i<250)
{
i++;
}
j1=i;
memcpy(&path[j1],"/vmtrain2.dat",30);
f2=fopen(path,"wb");
fseek(f2,0,SEEK_SET);
buf=c_file.pLum[3];

k=0;
for(i=0;i<n1;i++)
    {
        memcpy(&buf[k],"+1 ",3);k+=3;

            for(j=0;j<gn_dv;j++)
                {
                k1=sprintf(&buf[k],"%d:%f ",j+1,p[i].ipf[j]);k+=k1;
                }

        buf[k]=0x0a;k++;
    }
for(i=0;i<n2;i++)
    {
        memcpy(&buf[k],"-1 ",3);k+=3;

            for(j=0;j<gn_dv;j++)
                {
                k1=sprintf(&buf[k],"%d:%f ",j+1,p2[i].ipf[j]);k+=k1;
                }

        buf[k]=0x0a;k++;
    }
k=fwrite(buf,k,1,f2);
fclose(f2);

n1=gn_play;
p=&g_play;

memcpy(path,gm_file->input_path,260);
i=0;
while(path[i]!=0&&i<250)
{
i++;
}
j1=i;
memcpy(&path[j1],"/vmtest2.dat",30);

    f2=fopen(path,"wb");
    fseek(f2,0,SEEK_SET);
buf=c_file.pLum[3];

k=0;
for(i=0;i<n1;i++)
    {

        if(p[i].Class==1) memcpy(&buf[k],"+1 ",3);
        if(p[i].Class==-1) memcpy(&buf[k],"-1 ",3);
        k+=3;

            for(j=0;j<gn_dv;j++)
                {
                k1=sprintf(&buf[k],"%d:%f ",j+1,p[i].ipf[j]);k+=k1;
                }

        buf[k]=0x0a;k++;
    }

k=fwrite(buf,k,1,f2);
fclose(f2);
}

void c_TransTo_SVM()
{
int i,j,k,k1,k2,k3,k4,i1,i2,i3,j1,j2,j3,n1,n2,n3,nx,ny;
float t,t1,t2,t3,t4;
Play *p,*p2,*p3;

n1=gn_play2;n2=gn_play3;n3=gn_play;
p=&g_play2;p2=&g_play3;p3=&g_play;
//gn_dv=gm_start;
            j2=0;
            for(j1=0;j1<n1;j1++)
                {
                for(i=0;i<gn_dv;i++)
                        {
                        if(g_cmax[i]>0.001) g_svm[j2].v[i]=p[j1].ipf[i]/g_cmax[i];
                        else g_svm[j2].v[i]=0;

                        //if(g_svm[j2].v[i]<-1000||g_svm[j2].v[i]>1000)
                        //{
                            //t=0;
                        //}
                        }
                    g_svm[j2].Class=p[j1].Class;g_svm[j2].Clas[0]=p[j1].Clas[0];
                    g_svm[j2].ip=j1;
                    g_Y[j2]=p[j1].Class;

                    j2++;
                }

            for(j1=0;j1<n2;j1++)
                {
                    for(i=0;i<gn_dv;i++)
                        {
                        if(g_cmax[i]>0.001) g_svm[j2].v[i]=p2[j1].ipf[i]/g_cmax[i];
                        else g_svm[j2].v[i]=0;

                        //if(g_svm[j2].v[i]<-1000||g_svm[j2].v[i]>1000)
                        {
                        //	t=0;
                        }
                        }
                    g_svm[j2].Class=p2[j1].Class;g_svm[j2].Clas[0]=p2[j1].Clas[0];
                    g_svm[j2].ip=j1;
                    g_Y[j2]=p2[j1].Class;
                    j2++;
                }
            g_L=j2;gn_svm=j2;
}





void c_T1_SVM(int mi,Point2 mp)
{
int i,j,k,k1,k2,k3,k4,i1,i2,i3,j1,j2,j3,n1,n2,n3,nx,ny;
float t,t1,t2,t3,t4;
Play *p,*p2,*p3;

n1=gn_play2;n2=gn_play3;n3=gn_play;
p=&g_play2;p2=&g_play3;p3=&g_play;
            j2=0;
for(i=0;i<1000;i++)
g_art[i].c=0;
            for(j1=0;j1<n1;j1++)
                {
                t=p[j1].ipf[mi]/g_cmax[mi];
                //if(t>=mp.x&&t<=mp.y)
                {
                for(i=0;i<gn_dv;i++)
                        {
                        if(g_cmax[i]>0.001) g_svm[j2].v[i]=p[j1].ipf[i]/g_cmax[i];
                        else g_svm[j2].v[i]=0;
                        }

                    g_svm[j2].Class=p[j1].Class;
                    k=p[j1].Clas[0];
                    g_art[k].c=1;
                    g_svm[j2].ip=j1;
                    memcpy(g_svm[j2].Clas,p[j1].Clas,4);
                    g_Y[j2]=p[j1].Class;
                    j2++;
                }
                }
gn_svm4=0;
for(i=0;i<1000;i++)
gn_svm4+=g_art[i].c;
gn_svm3=gn_svm4;

            for(j1=0;j1<n2;j1++)
                {
                t=p2[j1].ipf[mi]/g_cmax[mi];
                //if(t>=mp.x&&t<=mp.y)
                {
                for(i=0;i<gn_dv;i++)
                        {
                        if(g_cmax[i]>0.001) g_svm[j2].v[i]=p2[j1].ipf[i]/g_cmax[i];
                        else g_svm[j2].v[i]=0;
                        }
                    g_svm[j2].Class=p2[j1].Class;
                    g_svm[j2].ip=j1;
                    memcpy(g_svm[j2].Clas,p2[j1].Clas,4);
                    g_Y[j2]=p2[j1].Class;
                    j2++;
                }
                }
            g_L=j2;gn_svm=j2;

}





int  c_JA_Gradient(Play *pl,int m1,Rect rc2,int m2)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1;
float max,s,t,t1,t2,v1,cx[40];
HOG  *h;
Point p0;
h=&c_file.pHog[m1*g_mx2*g_my2];
g_han=m2;
memset(cx,0,4*g_han);
i1=0;t1=0;max=0;
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;

        c_JB_Gradient(m1,x,y,&h[i1]);

        //t1+=h[i1].v;i=h[i1].i;
        //cx[i]+=h[i1].v;
        if(max<h[i1].v)
            {
            max=h[i1].v;
            }
         if(max==0)
            {
            t=0;
            }
        }
    }


for(i=0;i<g_my2;i++)
    {
    i1=(i*g_han)/g_my2;

    k=cx[i1]/max*(g_mx2-10);
    for(j=0;j<g_mx2;j++)
        {
        p0.y=i+10+m1*gs_HA;
        p0.x=g_mx2-j+gs_WA;
         ////c_Show_WinP3(p0.x,p0.y,0);
        }

    for(j=0;j<k;j++)
        {
        p0.y=i+10+m1*gs_HA;
        p0.x=g_mx2-j+gs_WA;
        //if(i!=i1*g_han) //c_Show_WinP3(p0.x,p0.y,255);
        }

    }

g_hrc=rc2;g_hx2=rc2.x1-rc2.x0;g_hy2=rc2.y1-rc2.y0;
return(1);
}




int  c_JS_HOG3(Play *pl,int m1,Rect rc2)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1;
float max,s,t,t1,t2,v1,cx[40];
HOG  *h;
Point p0;
h=&c_file.pHog[m1*g_mx2*g_my2];

memset(cx,0,4*g_han);
i1=0;t1=0;max=0;

v1=0.001*max;t2=0;
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        //if(h[i1].v>=0)
            {
            t2+=h[i1].v;
            i=h[i1].i;
            cx[i]+=h[i1].v;
            }
        }
    }
s=t2+0.001;
i1=0;t1=0;
max=0;
for(i=0;i<g_han;i++)
    {
    if(max<cx[i]) max=cx[i];
    }

i2=gm_start;
for(i=0;i<g_han;i++)
    {
    if(s>0) pl[0].ipf[i2]=cx[i]/s;
    i2++;
    }
gm_start=i2;
return(1);
}




int  c_JA_HOG1(Play *pl,int m1,Rect rc2)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1;
float s,t,t1,t2,*ax,*bx,max,min,v1,cx[40];
HOG  *h;
h=&c_file.pHog[m1*g_mx2*g_my2];

memset(cx,0,4*g_han);
i1=0;t1=0;max=0;min=1.e+11;
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        c_JB_Gradient(m1,x,y,&h[i1]);
        t1+=h[i1].v;i=h[i1].i;
        cx[i]+=h[i1].v;
        if(h[i1].v>max) max=h[i1].v;
        if(h[i1].v<min) min=h[i1].v;
        }
    }

g_hrc=rc2;g_hx2=rc2.x1-rc2.x0;g_hy2=rc2.y1-rc2.y0;
v1=max-min;

ax=&c_file.pDis[3][m1*g_mx2*g_my2];
if(v1>0)
{
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        ax[i1]=255.0*(h[i1].v-min)/v1;
        }
    }
}
else
{
memset(ax,0,4*g_mx2*g_my2);
}

return(1);
}



int  c_JA_HOG3(Play *pl,int m1,int mt,int mx,int my)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1,j2,n1;
float t,t1,t2,*ax,cx[40],bx[100];
Rect rc2;
HOG  *h;
h=&c_file.pHog[m1*g_mx2*g_my2];
ax=&c_file.pDis[3][m1*g_mx2*g_my2];

t2=0;n1=mx*my;i2=0;
for(j2=0;j2<my;j2++)
{
rc2.y0=(j2*g_hy2)/my+g_hrc.y0;rc2.y1=((j2+1)*g_hy2)/my+g_hrc.y0;
for(i3=0;i3<mx;i3++)
{
rc2.x0=(i3*g_hx2)/mx+g_hrc.x0;rc2.x1=((i3+1)*g_hx2)/mx+g_hrc.x0;
memset(cx,0,4*g_han);
t1=0;
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        if(ax[i1]>=mt)
        {
        t1+=h[i1].v;i=h[i1].i;
        cx[i]+=h[i1].v;
        }
        }
    }
t2+=t1;
for(i=0;i<g_han;i++)
{
if(t1>0) pl[0].ipf[i+gm_start]=cx[i]/t1;
else pl[0].ipf[i+gm_start]=0;
//pl[0].ipf[i+gm_start]=cx[i];
}
gm_start+=g_han;
bx[i2]=t1;i2++;
}

}

for(i=0;i<n1;i++)
{
if(t2>0) pl[0].ipf[i+gm_start]=bx[i]/t2;
else pl[0].ipf[i+gm_start]=0;
//pl[0].ipf[i+gm_start]=bx[i];
}

gm_start+=n1;

return(1);
}




int  c_JA_HOG2(Play *pl,int m1,int mx,int my)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1,j2,n1;
float t,t1,t2,*ax,cx[40],bx[100];
Rect rc2;
HOG  *h;
h=&c_file.pHog[m1*g_mx2*g_my2];

t2=0;n1=mx*my;i2=0;
for(j2=0;j2<my;j2++)
{
rc2.y0=(j2*g_hy2)/my+g_hrc.y0;rc2.y1=((j2+1)*g_hy2)/my+g_hrc.y0;
for(i3=0;i3<mx;i3++)
{
rc2.x0=(i3*g_hx2)/mx+g_hrc.x0;rc2.x1=((i3+1)*g_hx2)/mx+g_hrc.x0;
memset(cx,0,8*g_han);
t1=0;
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        for(i=0;i<g_han;i++)
        {cx[i]+=h[i1].d[i];}
        }
    }
t2+=t1;
for(i=0;i<g_han;i++)
{
if(t1>0) pl[0].ipf[i+gm_start]=cx[i]/t1;
else pl[0].ipf[i+gm_start]=0;
}
gm_start+=g_han;
bx[i2]=t1;i2++;
}

}

for(i=0;i<n1;i++)
{
if(t2>0) pl[0].ipf[i+gm_start]=bx[i]/t2;
else pl[0].ipf[i+gm_start]=0;
//pl[0].ipf[i+gm_start]=bx[i];
}

gm_start+=n1;

return(1);
}




void  c_JF_Gus(float o1)
{
int i,k,n1;
n1=30*o1;
for(i=0;i<n1;i++)
{
g_Gu[i]=exp(-1.0*i/o1);
}
}



void  c_JB_Gusv(int m1,int m2,int mx)
{
int i,j,i1,i2,j1,k,k1,k2,x,y,n1;
float t,t1,tx,ty,max,max1,max2,max3,*ax,*bx,*cx,*cx2,*cx3;
Point p0;
HOG   *h;
h=c_file.pHog;
ax=&c_file.pDis[0][(m2+10)*g_mx2*g_my2];bx=&c_file.pDis[1][(m2+10)*g_mx2*g_my2];
memset(bx,0,4*g_mx2*g_my2);
n1=4*mx*mx;max=0;
for(i=0;i<g_mx2;i++)
    {
    for(j=0;j<g_my2;j++)
        {
        t=0;k2=j*g_mx2+i;i2=0;
        if(mx>0)
        {
        for(i1=-mx;i1<=mx;i1++)
            {
            x=i+i1;
            if(x<0) x=0; if(x>=g_mx2) x=g_mx2-1;
            for(j1=-mx;j1<=mx;j1++)
                {
                y=j+j1;
                if(y<0) y=0; if(y>=g_my2) y=g_my2-1;
                k=y*g_mx2+x;
                k1=i1*i1+j1*j1;
                t+=ax[k]*g_Gu[k1];
                i2++;
                }
            }
        }
        else t=ax[k2];
        bx[k2]=t;
        if(i2>0) bx[k2]=t/i2;
        if(bx[k2]>max) max=bx[k2];
        }
    }
for(i=0;i<g_mx2;i++)
    {
    for(j=0;j<g_my2;j++)
        {

        k2=j*g_mx2+i;
        h[k2].v=bx[k2];

        t=bx[k2]/max*255;
        p0.x=i+10;
        p0.y=j+10+m2*gs_HA;
        ////c_Show_WinP3(p0.x,p0.y,t);
        }
    }

}



void  c_JB_Gus2(int m1,int m2,int m3,int mx)
{
int i,j,i1,j1,k,k1,k2,x,y;
float t,t1,tx,ty,*ax,*bx;
ax=&c_file.pDis[m1][m2*g_mx2*g_my2];bx=&c_file.pDis[2][m3*g_mx2*g_my2];
memset(bx,0,4*g_mx2*g_my2);
for(i=0;i<g_mx2;i++)
    {
    for(j=0;j<g_my2;j++)
        {
        t=0;k2=j*g_mx2+i;
        if(mx>0)
        {
        for(i1=-mx;i1<=mx;i1++)
            {
            x=i+i1;
            if(x<0) x=0; if(x>=g_mx2) x=g_mx2-1;
            for(j1=-mx;j1<=mx;j1++)
                {
                y=j+j1;
                if(y<0) y=0; if(y>=g_my2) y=g_my2-1;
                k=y*g_mx2+x;
                k1=i1*i1+j1*j1;
                t+=ax[k]*g_Gu[k1];
                }
            }
        }
        else t=ax[k2];
        bx[k2]=t;
        }
    }

}




void  c_JS_RDF1(Play *p,int m1,int m2,Rect rec,int mx,int my)
{
int i,j,i1,j1,k,k1,dx2,dy2,x,y,x0,y0,x1,y1,i2,i3;
float t,t1,t2,tx,ty,*ax,v[50];
ax=&c_file.pDis[m1][m2*g_mx2*g_my2];
dx2=rec.x1-rec.x0;dy2=rec.y1-rec.y0;


i2=0;t2=0;
y=rec.y0;k1=y*g_mx2;
for(i3=0;i3<mx;i3++)
{
x0=rec.x0+(i3*dx2)/mx;x1=rec.x0+((i3+1)*dx2)/mx;
t=0;
for(x=x0;x<x1;x++)
    {
    k=k1+x;
    t+=ax[k];
    }
v[i2]=t;i2++;
t2+=t;
}
y=rec.y1;k1=y*g_mx2;
for(i3=0;i3<mx;i3++)
{
x0=rec.x0+(i3*dx2)/mx;x1=rec.x0+((i3+1)*dx2)/mx;
t=0;
for(x=x0;x<x1;x++)
    {
    k=k1+x;
    t+=ax[k];
    }
v[i2]=t;i2++;
t2+=t;
}

x=rec.x0;
for(i3=0;i3<my;i3++)
{
y0=rec.y0+(i3*dy2)/my;y1=rec.y0+((i3+1)*dy2)/my;
t=0;
for(y=y0;y<y1;y++)
    {
    k=y*g_mx2+x;
    t+=ax[k];
    }
v[i2]=t;i2++;
t2+=t;
}

x=rec.x1;
for(i3=0;i3<my;i3++)
{
y0=rec.y0+(i3*dy2)/my;y1=rec.y0+((i3+1)*dy2)/my;
t=0;
for(y=y0;y<y1;y++)
    {
    k=k1+x;
    t+=ax[k];
    }
v[i2]=t;i2++;
t2+=t;
}

if(t2>0)
{
for(i=0;i<i2;i++)
    {
    p[0].ipf[gm_start+i]=v[i]/t2;
    }
}
gm_start+=i2;

}


void  c_JS_RDF2(Play *p,int m1,int m2,Rect rec,Point pc,int mx,int my)
{
int i,j,i1,j1,k,k1,dx2,dy2,x,y,x0,y0,x1,y1,i2,i3;
float t,t1,t2,tx,ty,tr,*ax,v[50];
ax=&c_file.pDis[m1][m2*g_mx2*g_my2];
dx2=rec.x1-rec.x0;dy2=rec.y1-rec.y0;


i2=0;t2=0;
y=rec.y0;k1=y*g_mx2;
for(i3=0;i3<mx;i3++)
{
x0=rec.x0+(i3*dx2)/mx;x1=rec.x0+((i3+1)*dx2)/mx;
t=0;
for(x=x0;x<x1;x++)
    {
    k=k1+x;
    tx=x-pc.x;ty=y-pc.y;
    tr=tx*tx+ty*ty;
    t+=ax[k]*tr;
    }
v[i2]=t;i2++;
t2+=t;
}
y=rec.y1;k1=y*g_mx2;
for(i3=0;i3<mx;i3++)
{
x0=rec.x0+(i3*dx2)/mx;x1=rec.x0+((i3+1)*dx2)/mx;
t=0;
for(x=x0;x<x1;x++)
    {
    k=k1+x;
    tx=x-pc.x;ty=y-pc.y;
    tr=tx*tx+ty*ty;
    t+=ax[k]*tr;
    }
v[i2]=t;i2++;
t2+=t;
}

x=rec.x0;
for(i3=0;i3<my;i3++)
{
y0=rec.y0+(i3*dy2)/my;y1=rec.y0+((i3+1)*dy2)/my;
t=0;
for(y=y0;y<y1;y++)
    {
    k=y*g_mx2+x;
    tx=x-pc.x;ty=y-pc.y;
    tr=tx*tx+ty*ty;
    t+=ax[k]*tr;
    }
v[i2]=t;i2++;
t2+=t;
}

x=rec.x1;
for(i3=0;i3<my;i3++)
{
y0=rec.y0+(i3*dy2)/my;y1=rec.y0+((i3+1)*dy2)/my;
t=0;
for(y=y0;y<y1;y++)
    {
    k=k1+x;
    tx=x-pc.x;ty=y-pc.y;
    tr=tx*tx+ty*ty;
    t+=ax[k]*tr;
    }
v[i2]=t;i2++;
t2+=t;
}

if(t2>0)
{
for(i=0;i<i2;i++)
    {
    p[0].ipf[gm_start+i]=v[i]/t2;
    }
}
gm_start+=i2;

}



void  c_Hog_RDF1(Play *p,int m1,Rect rec,int mx,int my)
{
int i,j,i1,j1,k,k1,dx2,dy2,x,y,x0,y0,x1,y1,i2,i3;
float t,t1,t2,tx,ty,v[50];
HOG  *ax;
ax=&c_file.pHog[m1*g_mx2*g_my2];
dx2=rec.x1-rec.x0;dy2=rec.y1-rec.y0;


i2=0;t2=0;
y=rec.y0;k1=y*g_mx2;
for(i3=0;i3<mx;i3++)
{
x0=rec.x0+(i3*dx2)/mx;x1=rec.x0+((i3+1)*dx2)/mx;
t=0;
for(x=x0;x<x1;x++)
    {
    k=k1+x;
    t+=ax[k].v;
    }
v[i2]=t;i2++;
t2+=t;
}
y=rec.y1;k1=y*g_mx2;
for(i3=0;i3<mx;i3++)
{
x0=rec.x0+(i3*dx2)/mx;x1=rec.x0+((i3+1)*dx2)/mx;
t=0;
for(x=x0;x<x1;x++)
    {
    k=k1+x;
    t+=ax[k].v;
    }
v[i2]=t;i2++;
t2+=t;
}

x=rec.x0;
for(i3=0;i3<my;i3++)
{
y0=rec.y0+(i3*dy2)/my;y1=rec.y0+((i3+1)*dy2)/my;
t=0;
for(y=y0;y<y1;y++)
    {
    k=y*g_mx2+x;
    t+=ax[k].v;
    }
v[i2]=t;i2++;
t2+=t;
}

x=rec.x1;
for(i3=0;i3<my;i3++)
{
y0=rec.y0+(i3*dy2)/my;y1=rec.y0+((i3+1)*dy2)/my;
t=0;
for(y=y0;y<y1;y++)
    {
    k=k1+x;
    t+=ax[k].v;
    }
v[i2]=t;i2++;
t2+=t;
}

if(t2>0)
{
for(i=0;i<i2;i++)
    {
    p[0].ipf[gm_start+i]=v[i]/t2;
    }
}
gm_start+=i2;

}



void  c_Hog_R1(Play *p,int mt,int m1,Rect rec,int mx,int my,int m2,int m3)
{
int i,j,i1,j1,k,k1,dx2,dy2,x,y,x0,y0,x1,y1,i2,i3,j2;
float t,t1,t2,tx,ty,v[50];
Point pc;
Rect  rc2;
HOG  *ax;
dx2=rec.x1-rec.x0;dy2=rec.y1-rec.y0;


t2=0;
for(j2=0;j2<my;j2++)
{
rc2.y0=(j2*dy2)/my+rec.y0;rc2.y1=((j2+1)*dy2)/my+rec.y0;
for(i3=0;i3<mx;i3++)
{
rc2.x0=(i3*dx2)/mx+rec.x0;rc2.x1=((i3+1)*dx2)/mx+rec.x0;
c_Hog_R2(p,mt,m1,rc2,m2,m3);
}
}


}

void  c_Hog_R2(Play *p,int mt,int m1,Rect rec,int mx,int my)
{
int i,j,i1,j1,k,k1,dx2,dy2,x,y,x0,y0,x1,y1,i2,i3,j3;
float t,t1,t2,tx,ty,v[50];
Point pc;
HOG  *ax;
ax=&c_file.pHog[m1*g_mx2*g_my2];
dx2=rec.x1-rec.x0;dy2=rec.y1-rec.y0;

pc.x=0.5*(rec.x0+rec.x1);pc.y=0.5*(rec.y0+rec.y1);

i2=0;t2=0;
y=rec.y0;k1=y*g_mx2;
for(i3=0;i3<mx;i3++)
{
x0=rec.x0+(i3*dx2)/mx;x1=rec.x0+((i3+1)*dx2)/mx;
t=0;
for(x=x0;x<x1;x++)
    {
    k=k1+x;
    tx=x-pc.x;ty=y-pc.y;
    if(mt==0) t+=fabs(ax[k].tx*tx+ax[k].ty*ty);
    if(mt==1) t+=fabs(ax[k].tx*ty-ax[k].ty*tx);
    if(mt==2) t+=fabs(ax[k].tx*ty+ax[k].ty*tx);
    if(mt==3) t+=fabs(ax[k].ty*tx);
    if(mt==3) t+=fabs(ax[k].tx*ty);
    }
v[i2]=t;i2++;
t2+=t;
}
y=rec.y1;k1=y*g_mx2;
for(i3=0;i3<mx;i3++)
{
x0=rec.x0+(i3*dx2)/mx;x1=rec.x0+((i3+1)*dx2)/mx;
t=0;
for(x=x0;x<x1;x++)
    {
    k=k1+x;
    tx=x-pc.x;ty=y-pc.y;
    if(mt==0) t+=fabs(ax[k].tx*tx+ax[k].ty*ty);
    if(mt==1) t+=fabs(ax[k].tx*ty-ax[k].ty*tx);
    if(mt==2) t+=fabs(ax[k].tx*ty+ax[k].ty*tx);
    if(mt==3) t+=fabs(ax[k].ty*tx);
    if(mt==3) t+=fabs(ax[k].tx*ty);
    }
v[i2]=t;i2++;
t2+=t;
}

x=rec.x0;
for(i3=0;i3<my;i3++)
{
y0=rec.y0+(i3*dy2)/my;y1=rec.y0+((i3+1)*dy2)/my;
t=0;
for(y=y0;y<y1;y++)
    {
    k=y*g_mx2+x;
    tx=x-pc.x;ty=y-pc.y;
    if(mt==0) t+=fabs(ax[k].tx*tx+ax[k].ty*ty);
    if(mt==1) t+=fabs(ax[k].tx*ty-ax[k].ty*tx);
    if(mt==2) t+=fabs(ax[k].tx*ty+ax[k].ty*tx);
    if(mt==3) t+=fabs(ax[k].ty*tx);
    if(mt==3) t+=fabs(ax[k].tx*ty);
    //t+=fabs(ax[k].tx*tx+ax[k].ty*ty);
    }
v[i2]=t;i2++;
t2+=t;
}

x=rec.x1;
for(i3=0;i3<my;i3++)
{
y0=rec.y0+(i3*dy2)/my;y1=rec.y0+((i3+1)*dy2)/my;
t=0;
for(y=y0;y<y1;y++)
    {
    k=k1+x;
    tx=x-pc.x;ty=y-pc.y;
    if(mt==0) t+=fabs(ax[k].tx*tx+ax[k].ty*ty);
    if(mt==1) t+=fabs(ax[k].tx*ty-ax[k].ty*tx);
    if(mt==2) t+=fabs(ax[k].tx);
    if(mt==3) t+=fabs(ax[k].ty);
    if(mt==4) t+=fabs(ax[k].v);

    //t+=fabs(ax[k].tx*tx+ax[k].ty*ty);
    }
v[i2]=t;i2++;
t2+=t;
}

if(t2>0)
{
for(i=0;i<i2;i++)
    {
    p[0].ipf[gm_start+i]=v[i]/t2;
    }
}
//gm_start+=i2;
//p[0].ipf[gm_start]=t2;
gm_start+=i2;

}


void  c_Hog_R3(Play *p,int m1,Rect rec,int mx,int my)
{
int i,j,i1,j1,k,k1,dx2,dy2,x,y,x0,y0,x1,y1,i2,i3;
float t,t1,t2,tx,ty,v[50];
Point pc;
HOG  *ax;
ax=&c_file.pHog[m1*g_mx2*g_my2];
dx2=rec.x1-rec.x0;dy2=rec.y1-rec.y0;
pc.x=0.5*(rec.x0+rec.x1);pc.y=0.5*(rec.y0+rec.y1);

i2=0;t2=0;
y=rec.y0;k1=y*g_mx2;
for(i3=0;i3<mx;i3++)
{
x0=rec.x0+(i3*dx2)/mx;x1=rec.x0+((i3+1)*dx2)/mx;
t=0;
for(x=x0;x<x1;x++)
    {
    k=k1+x;
    tx=x-pc.x;ty=y-pc.y;
    t+=fabs(ax[k].tx*tx-ax[k].ty*ty);
    }
v[i2]=t;i2++;
t2+=t;
}
y=rec.y1;k1=y*g_mx2;
for(i3=0;i3<mx;i3++)
{
x0=rec.x0+(i3*dx2)/mx;x1=rec.x0+((i3+1)*dx2)/mx;
t=0;
for(x=x0;x<x1;x++)
    {
    k=k1+x;
    tx=x-pc.x;ty=y-pc.y;
    t+=fabs(ax[k].tx*tx-ax[k].ty*ty);
    }
v[i2]=t;i2++;
t2+=t;
}

x=rec.x0;
for(i3=0;i3<my;i3++)
{
y0=rec.y0+(i3*dy2)/my;y1=rec.y0+((i3+1)*dy2)/my;
t=0;
for(y=y0;y<y1;y++)
    {
    k=y*g_mx2+x;
    tx=x-pc.x;ty=y-pc.y;
    t+=fabs(ax[k].tx*tx-ax[k].ty*ty);
    }
v[i2]=t;i2++;
t2+=t;
}

x=rec.x1;
for(i3=0;i3<my;i3++)
{
y0=rec.y0+(i3*dy2)/my;y1=rec.y0+((i3+1)*dy2)/my;
t=0;
for(y=y0;y<y1;y++)
    {
    k=k1+x;
    tx=x-pc.x;ty=y-pc.y;
    t+=fabs(ax[k].tx*tx-ax[k].ty*ty);
    }
v[i2]=t;i2++;
t2+=t;
}

if(t2>0)
{
for(i=0;i<i2;i++)
    {
    p[0].ipf[gm_start+i]=v[i]/t2;
    }
}
//p[0].ipf[gm_start]=t2;
gm_start+=i2;

}




void  c_GLobal_PH1(Play *p,int mt,int m1,int mx,int my)
{
int i,j,i1,j1,k,k1,dx,dy,dx2,dy2,x,y,x0,y0,x1,y1,i2,i3,j2;
float t,t1,t2,t3,t4,tx,ty,tv,vx,vy,v1,v2,v[50],*ax;
Point pc;
Rect  rec,rc2;
HOG  *h;

rec=g_hrc;
if(mt==3) rec=g_hrc2;

h=&c_file.pHog[m1*g_mx2*g_my2];
memset(v,0,8*(mx+my));

for(i1=0;i1<2;i1++)
    {
    if(i1==0) {y0=rec.y0;y1=2.0*(rec.y0+rec.y1)/4;ax=v;}
    if(i1==1) {y0=2.0*(rec.y0+rec.y1)/4;y1=rec.y1;ax=&v[mx+my];}
    t1=0;
    for(y=y0;y<y1;y++)
    {
    k1=y*g_mx2;
    for(x=rec.x0;x<rec.x1;x++)
        {
        dx=x-g_mx;
        k=k1+x;
        if(mt==0) tv=h[k].v1;
        if(mt==1) tv=h[k].v2;
        if(mt==2) tv=h[k].v;
        if(mt==3) tv=h[k].c;
        t1+=tv;
        vx=h[k].dx;vy=h[k].dy;
        if(vx>=0&&vx<g_mx2)
            {
            i=vx*mx/g_mx2;
            ax[i]+=tv;
            }
        if(vy>=0&&vy<g_my2)
            {
            i=vy*my/g_my2;
            ax[i+mx]+=tv;
            }
lp0:
        t=0;
        }
lp1:
    t=0;
    }

    for(i=0;i<mx+my;i++)
        {
        if(t1>0)
            {
            ax[i]=ax[i]/t1;
            }
        }
    }

t1=0;
for(i=0;i<mx;i++)
{
t1+=fabs(v[i]-v[i+mx+my]);
}

t2=0;
for(i=0;i<mx;i++)
{
t1+=fabs(v[i]-v[i+mx+my]);
}
p[0].ipf[gm_start]=t1/mx;
gm_start+=1;

}






void  c_JB_CUR1(int m1,int x0,int y0,HOG *h)
{
int i,j,i1,j1,k,k1,m2,m3,x,y;
float t,t1,t2,tx,ty,txy,*ax,*bx;
ax=&c_file.pDis[2][m1*g_mx2*g_my2];
m2=3;m3=2;
tx=0;
for(i=-2*m2;i<2*m2;i++)
    {
    x=i+x0;t1=-1;
    if(i>=-m2&&i<m2) t1=1;
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        k=y*g_mx2+x;
        tx+=ax[k]*t1;
        }
    }
ty=0;
for(i=-2*m2;i<2*m2;i++)
    {
    y=i+y0;k=y*g_mx2;
    t1=-1;
    if(i>=-m2&&i<m2) t1=1;
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        k1=k+x;
        ty+=ax[k1]*t1;
        }
    }
txy=0;
for(i=-m3;i<m3;i++)
    {
    y=i+y0;k=y*g_mx2;
    t1=-1;
    if(i>=0&&i<m3) t1=1;
    for(j=-m3;i<m3;i++)
        {
        t2=-1;
        if(j>=0&&j<m3) t2=1;
        x=j+x0;
        k1=k+x;
        txy+=ax[k1]*t1*t2;
        }
    }



if(tx<0) tx=-tx;
if(ty<0) ty=-ty;



if(tx==0&&ty==0) h->c=0;

if(tx>ty)
    {
    k=ty/tx*1000;
    h->c=FSQRT[k]*tx;
    }
else if(ty>tx)
    {
    k=tx/ty*1000;
    h->c=FSQRT[k]*ty;
    }


}



int c_JS_Dir(int m,int wc,Rect rec,Point3 *gz)
{
int x,y,i,j,k,i1,i2,i3,j1,j2,j3,k1,k2,k3,s1,na,n1,n2,kc,w,ki,kj,mt,ne;
float t,t1,t2,t3,t4,tx,ty,s,max,max1,l,l1,l2,ax[500],bx[500],ax2[200],cx[50],cx2[50],dx[50],c[10];
Point pc,p2;
Point2 p0;
Ext2 e[10];

mt=100;
gz[0].mi=0;
n1=1.414*wc;
n2=2*n1+1;
s1=8*n1+10;
w=0.25*(rec.x1-rec.x0);

i2=0;p0.x=0;p0.y=0;t1=0;
for(j=rec.y0;j<rec.y1;j++)
    {
    y=j-rec.y0;
    for(i=rec.x0;i<rec.x1;i++)
        {
        x=i-rec.x0;
        k=c_image.Y_Base[j]+i;
        k1=c_file.pLum[m][k];
        if(k1>=mt)
        {
        i1=LB[y]+x;
        g_UB[i1].v[0]=k1-mt+1;
        g_UB[i1].v[1]=k1-mt+1;
        g_U2[i2]=i1;i2++;
        p0.x+=g_UB[i1].v[0]*x;
        p0.y+=g_UB[i1].v[0]*y;
        t1+=g_UB[i1].v[0];
        }
        }
    }

s=1.0*i2/((rec.x1-rec.x0)*(rec.y1-rec.y0));
if(i2<=3) return;
gn_U2=i2;p0.x=p0.x/(t1+0.0001);p0.y=p0.y/(t1+0.0001);
k1=p0.y;
kc=LB[k1]+p0.x;


    max1=0;
    for(i1=0;i1<gna2_EVec;i1++)
        {
        i3=g_mi2[i1];
        memset(ax,0,s1);memset(bx,0,s1);
        for(j1=0;j1<gn_U2;j1++)
            {
            j=g_U2[j1];
            t=g_UB[j].z[i1]-g_UB[kc].z[i1];
            if(fabs(t)<=n1)
            {
            k1=t;t1=t-k1;	k2=k1+1;
            if(k2>=n1) k2=n1;
            ax[k1+n1]+=(1.0-t1)*g_UB[j].v[0];
            ax[k2+n1]+=t1*g_UB[j].v[0];
            }

            }
        c_jisu_avgm(2,n2,ax,ax2);
        max=0;t1=0;t2=0;l1=0;l2=0;
        for(i=0;i<n2-1;i++)
            {
            t=ax2[i];
            if(max<t)
                {
                max=t;
                k1=i;
                }
            }
        cx[i1]=max;dx[i1]=k1-n1;

        if(max1<max)
            {
            max1=max;ki=i1;
            }
        }





    kj=g_mi2[ki];



    //dx[ki]=0;


    l=0;
    g_pc2[0].x=rec.x0+p0.x+dx[ki]*gc_EVec[ki].x+l*gc_EVec[kj].x;
    g_pc2[0].y=rec.y0+p0.y+dx[ki]*gc_EVec[ki].y+l*gc_EVec[kj].y;
    g_dir[0]=kj;
    g_dir[1]=ki;

    g_len2[0]=0.707*wc;
    g_len2[1]=0.707*wc;
    if(m>1) g_len2[1]=0.6*wc;


    gz[0].p0=g_pc2[0];
    gz[0].mi=kj;

    //c_Show_RectF(2,255,g_pc2[0],kj,g_len2);
    return(1);
}



void  c_Get_Image0(int m,int m1,Point2 p0,int mi,float *len,Play *pl)
{
int x,y,x0,y0,x1,x2,y2,y3,y1,i,j,k,k1,k2,k3,k4,ki,kj,i1,i2,i3,j1,mx,my,m2,mi2,n1,n2;
float s,t,t1,t2,max,min,t3,t4,tx,ty,l1,rx,ry,v[2],vt;
Point2 v1,v2;
Point  pc;
long l2;
U8   *p,*bx,*bx2;
float  *ax;


//g_mx=30;g_my=24;
//g_mx=40;g_my=32;
//g_mx=30;g_my=24;
g_mx=24;g_my=24;

g_mx2=2*g_mx;g_my2=2*g_my;
mx=g_mx;my=g_my;

n1=g_mx2*g_my2;
bx=&pl[0].v[m1*n1];
//bx2=&pl[0].v[(m1+20)*n1];


rx=len[0]/mx;
ry=len[1]/my;

ax=&c_file.pDis[0][0];mi2=g_mi2[mi];
v1.x=gc_EVec[mi].x;v1.y=-gc_EVec[mi].y;
v2.x=-gc_EVec[mi2].x;v2.y=gc_EVec[mi2].y;
max=0;min=99999;
for(y2=-my;y2<my;y2++)
    {
    y=y2+my;y3=y*g_mx2;
    for(x2=-mx;x2<mx;x2++)
        {
        x=x2+mx;
        tx=rx*x2*v1.x+ry*y2*v1.y+p0.x;
        ty=rx*x2*v2.x+ry*y2*v2.y+p0.y;
        v[0]=0;
        if(tx<0) tx=0;if(tx>=c_image.Width1) tx=c_image.Width1;
        if(ty<0) ty=0;if(ty>=c_image.Height1) ty=c_image.Height1;


                x0=tx;y0=ty;x1=x0+1;y1=y0+1;
                t1=tx-x0;t2=ty-y0;
                k=Y_Base[y0]+x0; k1=Y_Base[y1]+x0; k2=Y_Base[y0]+x1; k3=Y_Base[y1]+x1;
                t=(1-t1)*(1-t2)*c_file.pLum[m][k]+(1-t1)*t2*c_file.pLum[m][k1]+t1*(1-t2)*c_file.pLum[m][k2]+t1*t2*c_file.pLum[m][k3];
                v[0]=t;

        k=y3+x;
        ax[k]=v[0];
        //bx2[k]=j1;
        if(max<v[0]) max=v[0];
        if(min>v[0]) min=v[0];
        }
    }

vt=max-min;
n2=0;
if(vt>0)
{
for(i=0;i<n1;i++)
{
t=1.0*(ax[i]-min)/vt;
    k=10000.0*t;
    //if(k>10000) k=10000;
    bx[i]=255.0*FSQRT2[k];
if(ax[i]>30) n2++;
}
}
else
{
memset(bx,0,n1);
}

pl[0].f[m1]=1.0*n2/n1;




/*if(gn_C1<200&&m>=0)
{

for(y2=0;y2<g_my2;y2++)
    {

    for(x2=0;x2<g_mx2;x2++)
        {
        k=bx[y2*g_mx2+x2];
        m1=gn_C1/16;
        m2=gn_C1-m1*16;
        c_Show_WinP3(x2+10+m2*50,y2+10+m1*50,k);
        }
    }

}
if(gn_C1==200)
{
c_Bitmap_Write3("/home/xychen/server/1ac.bmp");
}*/
pl[0].u[100+m]=100;
if(pl[0].ds<1)
{
m2=6;t=0;n1=(2*m2+1)*(2*m2+1);
for(y2=-m2;y2<=m2;y2++)
    {
    y=y2+pl[0].pc[1].y;
    if(y<0) y=0;
    if(y>c_image.Height1) y=c_image.Height1;
    for(x2=-m2;x2<=m2;x2++)
        {
        x=x2+pl[0].pc[1].x;
        if(x<0) x=0;
        if(x>c_image.Width1) x=c_image.Width1;
         k=Y_Base[y]+x;
         t+=c_file.pLum[m][k];
        }
    }
t=t/n1;
pl[0].u[100+m]=t;
}

}



void  c_Get_Image1(int m,int m1,Point2 p0,int mi,float *len,P_HOG *pl)
{
int x,y,x0,y0,x1,x2,y2,y3,y1,i,j,k,k1,k2,k3,k4,ki,kj,i1,i2,i3,j1,mx,my,m2,m3,mi2,n1,n2;
float s,t,t1,t2,max,min,t3,t4,tx,ty,l1,rx,ry,v[2],vt;
Point2 v1,v2;
Point  pc;
long l2;
U8   *p,*bx,*bx2;
float  *ax;


//g_mx=30;g_my=24;
//g_mx=40;g_my=32;
g_mx=24;g_my=24;
//g_mx=16;g_my=16;

g_mx2=2*g_mx;g_my2=2*g_my;
mx=g_mx;my=g_my;

n1=g_mx2*g_my2;
bx=&pl[0].v2[m1*n1];
//bx2=&pl[0].v[(m1+20)*n1];


rx=len[0]/mx;
ry=len[1]/my;

ax=&c_file.pDis[0][0];mi2=g_mi2[mi];
v1.x=gc_EVec[mi].x;v1.y=-gc_EVec[mi].y;
v2.x=-gc_EVec[mi2].x;v2.y=gc_EVec[mi2].y;
max=0;min=99999;
for(y2=-my;y2<my;y2++)
    {
    y=y2+my;y3=y*g_mx2;
    for(x2=-mx;x2<mx;x2++)
        {
        x=x2+mx;
        tx=rx*x2*v1.x+ry*y2*v1.y+p0.x;
        ty=rx*x2*v2.x+ry*y2*v2.y+p0.y;
        v[0]=0;
        if(tx<0) tx=0;if(tx>=c_image.Width1) tx=c_image.Width1;
        if(ty<0) ty=0;if(ty>=c_image.Height1) ty=c_image.Height1;


                x0=tx;y0=ty;x1=x0+1;y1=y0+1;
                t1=tx-x0;t2=ty-y0;
                k=Y_Base[y0]+x0; k1=Y_Base[y1]+x0; k2=Y_Base[y0]+x1; k3=Y_Base[y1]+x1;
                t=(1-t1)*(1-t2)*c_file.pLum[m][k]+(1-t1)*t2*c_file.pLum[m][k1]+t1*(1-t2)*c_file.pLum[m][k2]+t1*t2*c_file.pLum[m][k3];
                v[0]=t;

        k=y3+x;
        ax[k]=v[0];
        //bx2[k]=j1;
        if(max<v[0]) max=v[0];
        if(min>v[0]) min=v[0];
        }
    }

vt=max-min;
n2=0;
if(vt>0)
{
for(i=0;i<n1;i++)
{
t=1.0*(ax[i]-min)/vt;
k=10000.0*t;
bx[i]=255.0*FSQRT2[k];
}
}
else
{
memset(bx,0,n1);
}

if(gn_C1<600&&pl[0].ds<0.66666)
{
k1=(gn_C1-1)*6+m1;
k2=(gn_C1-1)/3;
k3=(gn_C1-1)-k2*3;

for(y2=0;y2<g_my2;y2++)
    {

    for(x2=0;x2<g_mx2;x2++)
        {
        k=bx[y2*g_mx2+x2];
        m2=k1/18;
        m3=k1-m2*18;
        c_Show_WinP3(x2+0+m3*50+k3*10,y2+0+m2*50+k2*10,k);
        }
    }

}
if(gn_C1==600)
{
c_Bitmap_Write3("/home/xychen/36ac.bmp");
}
}


void c_JPoint3(int w,float ds,Point3 *pa)
{
int i,j,n1,n2,k1,k2,x,y,w2;
float t,min;
Point2 p2,p3;

min=1000;
    n1=g_database[gs_database].np;
    k1=gi_o[gs_database].x;
    for(i=0;i<n1;i++)
        {
        j=i+k1;
        p2.x=g_art[j].p.x;p2.y=g_art[j].p.y;
        t=c_Get_Dist2(pa->p0,p2);
        if(t<min)
            {
            min=t;k2=j;p3=p2;
            }
        }

    pa->ds=min/w; pa->i=k2; pa->p1=p3;
    if(pa->ds<ds)
        {
        g_art[k2].c=1;
        //c_Show_Point4(10,pa->p0.x,pa->p0.y);
        }
}






int   c_get_digit(int s,int *b)
{
int i,j,k,n1;
char b2[100];
i=s;b[0]=-1;
while(g_fbuf[i]!=0x3c&&i-s<10)
{
i++;
}
n1=i;
k=g_fbuf[s]-0x30;
b[0]=-1;
for(j=s+1;j<=n1-1;j++)
{
k=k*10+g_fbuf[j]-0x30;
if(g_fbuf[j]>0x39||g_fbuf[j]<0x30) return(0);
}

b[0]=k;

return(1);
}



int   c_object_class(int s,int *b)
{
 int i,j,k,n1;
char b2[100];
i=s;b[0]=-1;
while(g_fbuf[i]!=0x3c&&i-s<100)
{
i++;
}
n1=i-s;
if(i>=s+100) return(0);

memcpy(b2,&g_fbuf[s],n1+1);
b2[n1]=0;
/*
• person
• bird, cat, cow, dog, horse, sheep
• aeroplane, bicycle, boat, bus, car, motorbike, train
• bottle, chair, dining table, potted plant, sofa, tv/monitor
*/
b[0]=-1;
if(!(k=strcmp(b2,"person"))) b[0]=1;
if(!(k=strcmp(b2,"bird"))) b[0]=2;
if(!(k=strcmp(b2,"cat"))) b[0]=3;
if(!(k=strcmp(b2,"cow"))) b[0]=4;
if(!(k=strcmp(b2,"dog"))) b[0]=5;
if(!(k=strcmp(b2,"horse"))) b[0]=6;
if(!(k=strcmp(b2,"sheep"))) b[0]=7;
if(!(k=strcmp(b2,"aeroplane"))) b[0]=8;
if(!(k=strcmp(b2,"bicycle"))) b[0]=9;
if(!(k=strcmp(b2,"boat"))) b[0]=10;
if(!(k=strcmp(b2,"bus"))) b[0]=11;
if(!(k=strcmp(b2,"car"))) b[0]=12;
if(!(k=strcmp(b2,"motorbike"))) b[0]=13;
if(!(k=strcmp(b2,"train"))) b[0]=14;
if(!(k=strcmp(b2,"bottle"))) b[0]=15;
if(!(k=strcmp(b2,"chair"))) b[0]=16;
if(!(k=strcmp(b2,"dining table"))) b[0]=17;
if(!(k=strcmp(b2,"potted plant"))) b[0]=18;
if(!(k=strcmp(b2,"sofa"))) b[0]=19;
if(!(k=strcmp(b2,"tv"))) b[0]=20;
if(!(k=strcmp(b2,"monitor"))) b[0]=20;
b[1]=n1+i;
return(b[0]);
}




int   c_search_str(int s,char *str,int *b)
{
int i,j,k,n1,n2;
i=0;b[0]=-1;
while(str[i]!=0)
{
i++;
}
n1=i;
i=s;
k=0;
for(j=0;j<n1;j++)
{k+=fabs(g_fbuf[i+j]-str[j]);}
while(k!=0&&i<gn_bf-n1)
{
i++;
k=0;
for(j=0;j<n1;j++)
{k+=fabs(g_fbuf[i+j]-str[j]);}
}
if(i>gn_bf-2) return(0);

b[0]=i;
b[1]=i+n1;

return(1);
}








int   c_get_bndbox(int s,Rect *r)
{
int i,j,k,n1,b[10],b2[10];

 c_search_str(s,"<xmin>",b);
 c_get_digit(b[1],b2);
 c_search_str(s,"<xmax>",b);
 c_get_digit(b[1],&b2[1]);
 c_search_str(s,"<ymin>",b);
 c_get_digit(b[1],&b2[2]);
 c_search_str(s,"<ymax>",b);
 c_get_digit(b[1],&b2[3]);
r[0].x0=b2[0];r[0].x1=b2[1];
r[0].y0=b2[2];r[0].y1=b2[3];
if(b2[1]<b2[0]||b2[3]<b2[2])
{
    return(0);
}

return(1);
}


int   c_get_to(int s,int *t,int *o)
{
int i,j,k,n1,b[10],b2[10];

 c_search_str(s,"<truncate>",b);
 *t=1;
 if(g_fbuf[b[1]]=0x30) *t=0; 
 c_search_str(s,"<occluded>",b);
 *o=1;
 if(g_fbuf[b[1]]=0x30) *o=0;

return(1);
}

/*
c_search_str(s1,"<filename>",b);
i=b[1];
while(g_fbuf[i]!=0x3c&&i<b[1]+100)
{
i++;
}
b[2]=i;n3=b[2]-b[1];
memcpy(p2[n2],g_fbuf[b[1]],n3);
p2[n2+n3]=0;
*/

void c_get_info(char *path)
{
int i,j,k,k1,n1,n2,b[10],b2[10],c1,tr,oc,nc,s1;
Rect rec;
Object *ob;
FILE  *f2;
char p2[260],p3[260];
memcpy(p3,path,260);
gn_bf=260;
memcpy(g_fbuf,path,260);
c_search_str(0,"Ann",b);
g_fbuf[b[0]]='I';g_fbuf[b[0]+1]='m';g_fbuf[b[0]+2]='g';
c_search_str(0,"xml",b);
g_fbuf[b[0]]='j';g_fbuf[b[0]+1]='p';g_fbuf[b[0]+2]='g';
memcpy(p2,g_fbuf,260);
//n2=b[0]+3;
f2=fopen(path,"rb");
if(f2==0)
{
return;
}
gn_bf=fread(g_fbuf,1,20000,f2);
fclose(f2);
k1=1;
ob=&g_obj[gn_obj];
memcpy(ob[0].path,p2,260);
ob[0].nc=0;s1=0;
nc=0;k1=1;
while(k1>0)
	{

    c_search_str(s1,"<name>",b);
    k1=c_object_class(b[1],b);    
	if(k1>0)
		{
        s1=b[1];      c1=k1;
        c_get_to(b[1],&tr,&oc);
                c_get_bndbox(b[1],&rec);
                ob[0].Class[nc]=c1;
                ob[0].tr[nc]=tr;ob[0].oc[nc]=oc;
                ob[0].rec[nc]=rec;
                ob[0].nc++;

                nc++;
                if(nc>gm_nc)
                {
                    gm_nc=nc;
                    memcpy(gm_buf,p2,260);
                }
		}
	}
 gn_obj++;
}

int c_file_read(char *path,struct stat *fst,int flag)
{
  char   filename[260];
  memcpy(filename,path,260);
    if(flag!=FTW_D)
        {
        c_get_info(path);
        }
    return(0);
}

void c_VOCFile_Read()
{
char   path[260];
int k,i,j,n1;
FILE *f2;


gn_obj=0;
k=ftw("/home/xychen/pic/P2010/Train/Ann",c_file_read,300);
memcpy(path,"/home/xychen/pic/P2010/Train/ann_train.dat",260);
n1=sizeof(Object);
f2=fopen(path,"wb");
fseek(f2,0,SEEK_SET);
k=fwrite(g_obj,n1,gn_obj,f2);
fclose(f2);


gn_obj=0;
k=ftw("/home/xychen/pic/P2010/Test/Ann",c_file_read,300);
memcpy(path,"/home/xychen/pic/P2010/Test/ann_test.dat",260);

n1=sizeof(Object);
f2=fopen(path,"wb");
fseek(f2,0,SEEK_SET);
k=fwrite(g_obj,n1,gn_obj,f2);
fclose(f2);


}






void c_Object_Scan2(int mo,int mk)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,k3,h,w2,h2,n1,n2,n3,w,w3,m3,b[2],b2[2],b3[10],m,md,f1,ic2;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;
int   g_ix,g_iy,gn_w,gn_h,c1,c2,ic,iw,ws[10];
Point2  p0,p1,p2,p3,pc[15];
Point  plum[10];
Play   *pl;


g_C1[gs_database].x=gn_C1;
g_C3[gs_database].x=gn_C3;
for(i=0;i<10;i++)
{ws[i]=36;}
ma=0.3;ma2=1.0;m=0;
c_Mode_Zdot(3);md=1;
rec.x0=0;rec.x1=c_image.Width;rec.y0=0;rec.y1=c_image.Height;
gn_srec=0;gp_data=0;
gn_play=0;gn_play2=0;gn_play3=0;

n1=0;gn_play=0;gn_pz=0;
b3[0]=1;b3[1]=2;b3[2]=3;
for(iw=1;iw<2;iw++)
{
w=36;
h=w;
gc_w2=w*0.65;
n2=w*w;h2=h/2;w2=w/2;
gn_w=1.0*(rec.x1-rec.x0-1)/w2+0.35;gn_h=1.0*(rec.y1-rec.y0-1)/h2+0.35;
gn_srec2=0;
for(ic2=1;ic2<3;ic2++)
{
ic=b3[ic2];
{ma=0.1;ma2=0.8;}
//if(ic>=3) {ma=0.1;ma2=0.6;}
g_iy=0;g_ix=0;i3=0;i4=0;
    for(g_iy=0;g_iy<gn_h;g_iy++)
        {
        rc2.y0=g_iy*h2;rc2.y1=rc2.y0+h;if(rc2.y1>rec.y1-1) rc2.y1=rec.y1-1;

        for(g_ix=0;g_ix<gn_w;g_ix++)
            {
            rc2.x0=g_ix*w2;rc2.x1=rc2.x0+w;if(rc2.x1>rec.x1-1) rc2.x1=rec.x1-1;
            p0.x=0.5*(rc2.x0+rc2.x1);p0.y=0.5*(rc2.y0+rc2.y1);
            i2=0;
            p1.x=0;p1.y=0;t1=0;t2=0;

            b2[0]=1;
            for(y=rc2.y0;y<=rc2.y1;y++)
                {
                for(x=rc2.x0;x<=rc2.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;i2++;t1+=t;
                        }
                    }
                }
            p0.x=p1.x/t1;p0.y=p1.y/t1;
            s1=1.0*i2/((rc2.y1-rc2.y0+1)*(rc2.x1-rc2.x0+1));
            if(s1>ma2) goto lp3;
            if(s1<ma) goto lp3;
            rc3=rc2;

            y2=p0.y-gc_w2;y3=p0.y+gc_w2;
            x2=p0.x-gc_w2;x3=p0.x+gc_w2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;

            i2=0;b2[0]=1;p1.x=0;p1.y=0;t1=0;
            for(y=rc3.y0;y<=rc3.y1;y++)
                {
                for(x=rc3.x0;x<=rc3.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;
                        i2++;t1+=t;
                        }
                    }
                }
            p0.x=p1.x/t1;p0.y=p1.y/t1;

            //rc3=rc2;

            y2=p0.y-gc_w2;y3=p0.y+gc_w2;
            x2=p0.x-gc_w2;x3=p0.x+gc_w2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;

            i2=0;b2[0]=1;p1.x=0;p1.y=0;t1=0;
            for(y=rc3.y0;y<=rc3.y1;y++)
                {
                for(x=rc3.x0;x<=rc3.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        i2++;
                        }
                    }
                }

            //
             g_pz[gn_pz].x=p0.x;g_pz[gn_pz].y=p0.y;
             g_pz[gn_pz].r=rc3;
             g_pz[gn_pz].y=p0.y;g_pz[gn_pz].s=1.0*i2/((rc3.y1-rc3.y0+1)*(rc3.x1-rc3.x0+1));
             g_pz[gn_pz].p0=p0;
             g_pz[gn_pz].ic=ic;
             gn_pz++;
            //c_Show_Rect(rc3);
            n1++;
lp3:
            t=0;
            }
        }
}

}
m3=5;



        for(i=0;i<gn_pz;i++)
            {
            if(g_pz[i].s>0)
                {
                for(j=i+1;j<gn_pz;j++)
                    {
                    if(g_pz[j].s>0)
                        {
                        t=c_Get_Dist3(g_pz[i],g_pz[j]);
                        if(t<m3)
                            {
                            if(g_pz[i].s>=g_pz[j].s)
                                {
                                g_pz[j].s=0;
                                }
                           else if(g_pz[i].s<g_pz[j].s)
                                {
                                g_pz[i].s=0; goto lp4;
                                }
                            }
                        }
                    }
                }
        lp4:
            t=0;
            }

        i2=0;g_len2[0]=gc_w2;g_len2[1]=gc_w2;
        g_len3[0]=2.0*gc_w2;g_len3[1]=2.0*gc_w2;
        g_len4[0]=1.35*gc_w2;g_len4[1]=1.35*gc_w2;


        //g_len2[0]=24;g_len2[1]=24;
        for(i=0;i<gn_pz;i++)
            {

            if(g_pz[i].s>0)
                {
                //k=c_JS_Dir(g_pz[i].ic,w,g_pz[i].r);
                c_JPoint3(gc_w2,0.5,&g_pz[i]);
                pl=&g_play[gn_play];pl->pc[0]=g_pz[i].p0;pl->pc[1]=g_pz[i].p1;pl->Clas[0]=g_pz[i].i;pl->Clas[1]=gs_database;pl->w=gc_w2; pl->ds=g_pz[i].ds;

                if(g_pz[i].ds>0.666666&&g_pz[i].ds<1.2) goto lps;
                gn_C3++;


                                if(g_pz[i].ds<=0.66666)
                                        {
                                        pl->Class=1;
                                        gn_C1++;
                                        }
                                 else
                                        {
                                        pl->Class=-1;
                                        gn_C2++;
                                        }



                memcpy(pl->path,gm_file->input_filename,260);
                j1=0;
                cx[0]=1.1;cx[1]=1.2;cx[2]=1.3;cx[3]=1.4;cx[4]=1.0;cx[5]=0.9;


                                for(i2=0;i2<1;i2++)
                                    {
                                    g_len3[0]=cx[i2]*gc_w2;g_len3[1]=cx[i2]*gc_w2;
                                    c_Get_Image0(0,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                                    c_Get_Image0(1,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                                    c_Get_Image0(2,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                                    c_Get_Image0(3,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                                    c_Get_Image0(4,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                                    c_Get_Image0(5,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                                    c_Get_Image0(0,j1,g_pz[i].p0,2,g_len3,pl);j1++;
                                    c_Get_Image0(1,j1,g_pz[i].p0,2,g_len3,pl);j1++;
                                    c_Get_Image0(2,j1,g_pz[i].p0,2,g_len3,pl);j1++;
                                    c_Get_Image0(3,j1,g_pz[i].p0,2,g_len3,pl);j1++;
                                    c_Get_Image0(4,j1,g_pz[i].p0,2,g_len3,pl);j1++;
                                    c_Get_Image0(5,j1,g_pz[i].p0,2,g_len3,pl);j1++;
                                    c_Get_Image0(0,j1,g_pz[i].p0,4,g_len3,pl);j1++;
                                    c_Get_Image0(1,j1,g_pz[i].p0,4,g_len3,pl);j1++;
                                    c_Get_Image0(2,j1,g_pz[i].p0,4,g_len3,pl);j1++;
                                    c_Get_Image0(3,j1,g_pz[i].p0,4,g_len3,pl);j1++;
                                    c_Get_Image0(4,j1,g_pz[i].p0,4,g_len3,pl);j1++;
                                    c_Get_Image0(5,j1,g_pz[i].p0,4,g_len3,pl);j1++;
                                    }





                                 gn_play++;

lps:

                t=0;i2++;
                }

            }

    gn_Lk=i2;


    g_C1[gs_database].y=gn_C1;
    g_C3[gs_database].y=gn_C3;
}


void  c_Get_Image2(int m,int m1,TWIST *tw,Point2 p0,float *len,Play *pl)
{
int x,y,x0,y0,x1,x2,y2,x3,y3,y1,i,j,k,k1,k2,k3,k4,ki,kj,i1,i2,i3,j1,mx,my,mx2,mx1,m2,m3,mi2,mi,n1,n3,n2,blr;
float s,t,t1,t2,max,min,t3,t4,tx,ty,l1,rx,ry,v[2],vt,s1,mg1,elg;
Point2 v1,v2,p1;
Point  pc;
long l2;
U8   *p,*bx,*bx2;
float  *ax,*blur;

blr=2.0*tw[0].blur;if(blr>0) blur=&g_blur[(blr-1)*300];
mx1=blr;if(mx1>16) mx=16;

mg1=1+tw[0].margin;
elg=1+tw[0].enlarge;
g_mx=24*mg1*elg;g_my=g_mx;g_mx2=2*g_mx;g_my2=2*g_my;mx=g_mx;my=g_my;
mx2=24*elg;
s1=1.0/elg;

memset(g_gvp,0,48*48*sizeof(GVP));

n3=48*48;
n1=g_mx2*g_my2;bx=&c_file.pDis[0][n1];
rx=len[1]*mg1/mx;ry=len[1]*mg1/my;

mi=tw[0].rotate;

ax=&c_file.pDis[0][0];mi2=g_mi2[mi];
v1.x=gc_EVec[mi].x;v1.y=-gc_EVec[mi].y;
v2.x=-gc_EVec[mi2].x;v2.y=gc_EVec[mi2].y;
max=0;min=99999;
p1.x=p0.x+tw[0].displace.x;p1.y=p0.y+tw[0].displace.y;
for(y2=-my;y2<my;y2++)
    {
    y=y2+my;y3=y*g_mx2;
    for(x2=-mx;x2<mx;x2++)
        {
        x=x2+mx;
        tx=rx*x2*v1.x+ry*y2*v1.y+p1.x;
        ty=rx*x2*v2.x+ry*y2*v2.y+p1.y;
        v[0]=0;
        if(tx<0) tx=0;if(tx>=c_image.Width1) tx=c_image.Width1;
        if(ty<0) ty=0;if(ty>=c_image.Height1) ty=c_image.Height1;

                x0=tx;y0=ty;x1=x0+1;y1=y0+1;
                t1=tx-x0;t2=ty-y0;
                k=Y_Base[y0]+x0; k1=Y_Base[y1]+x0; k2=Y_Base[y0]+x1; k3=Y_Base[y1]+x1;
                t=(1-t1)*(1-t2)*c_file.pLum[m][k]+(1-t1)*t2*c_file.pLum[m][k1]+t1*(1-t2)*c_file.pLum[m][k2]+t1*t2*c_file.pLum[m][k3];
                v[0]=t;
        
        k=y3+x;
        ax[k]=v[0];bx[k]=v[0];
        if(max<v[0]) max=v[0];
        if(min>v[0]) min=v[0];
        
       
        }
    }
if(blr>0)
    {
    for(y2=-my;y2<my;y2++)
        {
        y=y2+my;
        for(x2=-mx;x2<mx;x2++)
            {
            x=x2+mx;
            x1=x-mx1;x3=x+mx1;
            y1=y-mx1;y3=y+mx1;

            if(x1<0) x1=0;if(x3>g_mx2-1) x3=g_mx2-1;
            if(y1<0) y1=0;if(y3>g_my2-1) y3=g_my2-1;
            t1=0;t2=0;
            for(j=y1;j<=y3;j++)
                {
                for(i=x1;i<=x3;i++)
                    {
                    k=j*g_mx2+i;
                    k1=j-y; if(k1<0) k1=-k1;
                    k2=i-x; if(k2<0) k2=-k2;
                    k1=k1*16+k2;
                    t1+=blur[k1];
                    t2+=blur[k1]*ax[k];
                    }
                }

            k=y*g_mx2+x;
            bx[k]=t2/t1;
            if(max<bx[k]) max=bx[k];
            if(min>bx[k]) min=bx[k];
            }
        }
    }


vt=max-min;
n2=0;
if(vt>0)
{
for(i=0;i<n1;i++)
{
t=1.0*(bx[i]-min)/vt;
k=10000.0*t;
bx[i]=255.0*FSQRT2[k];
//if(bx[i]>30) n2++;
}
}
else
{
memset(bx,0,n1);
}


for(y2=-my;y2<my;y2++)
    {
    y=y2+my;y3=y*g_mx2;
    for(x2=-mx;x2<mx;x2++)
        {
        x=x2+mx;
        k=y3+x;
        v[0]=bx[k];
        k1=1.0*(tw[0].cy.x*x2+tw[0].cy.y*y2)/mx2*10000;
        if(k1<0) k1=-k1;
        k1=k1%10000;
        ty=s1*y2*(1.0+tw[0].ratio.y*FCOS[k1]);
        k1=1.0*(tw[0].cx.x*x2+tw[0].cx.y*y2)/mx2*10000;
        if(k1<0) k1=-k1;
        k1=k1%10000; 
        tx=s1*x2*(1.0+tw[0].ratio.x*FCOS[k1]);  
        
        y1=(ty+24);x1=tx+24;
        if(y1<48&&y1>=0&&x1>=0&&x1<48)
        	{
	        t=2.0-(ty+24-y1)*(ty+24-y1)-(tx+24-x1)*(tx+24-x1);
        	k=y1*48+x1;
	        if(t>g_gvp[k].d)
			{
	                g_gvp[k].d=t;g_gvp[k].v=v[0];     
			}
	        }        
        }
    }

bx2=&pl[0].v[m1*n3];

for(i=0;i<n3;i++)
bx2[i]=g_gvp[i].v;


if(gn_C1<30&&m1>=0&&pl[0].ds<0.6666)
{

for(y2=0;y2<48;y2++)
    {

    for(x2=0;x2<48;x2++)
        {
        k=bx2[y2*48+x2];
        m2=((gn_C1-1)*9+m1)/16;
        m3=((gn_C1-1)*9+m1)-m2*16;
        c_Show_WinP3(x2+m3*50,y2+m2*50,k);
        }
    }
}
if(gn_C1==30&&m1==1)
{
c_Bitmap_Write3("/home/xychen/rac.bmp");
}


}

void c_Object_Scan(int mk)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,k3,h,w2,h2,n1,n2,n3,w,w3,m3,b[2],b2[2],b3[10],m,md,m1,f1,ic2;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;
int   g_ix,g_iy,gn_w,gn_h,c1,c2,ic,iw,ws[5];
Point2  p0,p1,p2,p3,pc[15];
Point  plum[10];
P_HOG   *pl;
TWIST  tw[20];

g_C1[gs_database].x=gn_C1;
g_C3[gs_database].x=gn_C3;

ws[0]=36;ws[1]=40;
ma=0.3;ma2=1.0;m=0;
c_Mode_Zdot(3);md=1;
rec.x0=0;rec.x1=c_image.Width;rec.y0=0;rec.y1=c_image.Height;
gn_srec=0;gp_data=0;
gn_play=0;gn_play2=0;gn_play3=0;

n1=0;gn_play=0;gn_pz=0;
b3[0]=1;b3[1]=2;b3[2]=3;
for(iw=0;iw<1;iw++)
{
w=ws[iw];
h=w;
gc_w2=w*0.65;
n2=w*w;h2=h/2;w2=w/2;
gn_w=1.0*(rec.x1-rec.x0-1)/w2+0.35;gn_h=1.0*(rec.y1-rec.y0-1)/h2+0.35;
gn_srec2=0;
for(ic2=1;ic2<3;ic2++)
{
ic=b3[ic2];
{ma=0.1;ma2=0.8;}

g_iy=0;g_ix=0;i3=0;i4=0;
    for(g_iy=0;g_iy<gn_h;g_iy++)
        {
        rc2.y0=g_iy*h2;rc2.y1=rc2.y0+h;if(rc2.y1>rec.y1-1) rc2.y1=rec.y1-1;

        for(g_ix=0;g_ix<gn_w;g_ix++)
            {
            rc2.x0=g_ix*w2;rc2.x1=rc2.x0+w;if(rc2.x1>rec.x1-1) rc2.x1=rec.x1-1;
            p0.x=0.5*(rc2.x0+rc2.x1);p0.y=0.5*(rc2.y0+rc2.y1);
            i2=0;
            p1.x=0;p1.y=0;t1=0;t2=0;

            b2[0]=1;
            for(y=rc2.y0;y<=rc2.y1;y++)
                {
                for(x=rc2.x0;x<=rc2.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;i2++;t1+=t;
                        }
                    }
                }
            p0.x=p1.x/t1;p0.y=p1.y/t1;
            s1=1.0*i2/((rc2.y1-rc2.y0+1)*(rc2.x1-rc2.x0+1));
            if(s1>ma2) goto lp3;
            if(s1<ma) goto lp3;
            rc3=rc2;

            y2=p0.y-gc_w2;y3=p0.y+gc_w2;
            x2=p0.x-gc_w2;x3=p0.x+gc_w2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;

            i2=0;b2[0]=1;p1.x=0;p1.y=0;t1=0;
            for(y=rc3.y0;y<=rc3.y1;y++)
                {
                for(x=rc3.x0;x<=rc3.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;
                        i2++;t1+=t;
                        }
                    }
                }
            p0.x=p1.x/t1;p0.y=p1.y/t1;





            y2=p0.y-gc_w2;y3=p0.y+gc_w2;
            x2=p0.x-gc_w2;x3=p0.x+gc_w2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;

            i2=0;b2[0]=1;p1.x=0;p1.y=0;t1=0;
            for(y=rc3.y0;y<=rc3.y1;y++)
                {
                for(x=rc3.x0;x<=rc3.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        i2++;
                        }
                    }
                }            
             g_pz[gn_pz].x=p0.x;g_pz[gn_pz].y=p0.y;
             g_pz[gn_pz].r=rc3;
             g_pz[gn_pz].y=p0.y;g_pz[gn_pz].s=1.0*i2/((rc3.y1-rc3.y0+1)*(rc3.x1-rc3.x0+1));
             g_pz[gn_pz].p0=p0;
             g_pz[gn_pz].ic=ic;
             gn_pz++;
            //c_Show_Rect(rc3);
            n1++;
lp3:
            t=0;
            }
        }
}

}
m3=5;



        for(i=0;i<gn_pz;i++)
            {
            if(g_pz[i].s>0)
                {
                for(j=i+1;j<gn_pz;j++)
                    {
                    if(g_pz[j].s>0)
                        {
                        t=c_Get_Dist3(g_pz[i],g_pz[j]);
                        if(t<m3)
                            {
                            if(g_pz[i].s>=g_pz[j].s)
                                {
                                g_pz[j].s=0;
                                }
                           else if(g_pz[i].s<g_pz[j].s)
                                {
                                g_pz[i].s=0; goto lp4;
                                }
                            }
                        }
                    }
                }
        lp4:
            t=0;
            }

        i2=0;g_len2[0]=gc_w2;g_len2[1]=gc_w2;
        g_len3[0]=2.0*gc_w2;g_len3[1]=2.0*gc_w2;
        g_len4[0]=1.35*gc_w2;g_len4[1]=1.35*gc_w2;


        //g_len2[0]=24;g_len2[1]=24;
        //memset(tw,0,20*sizeof(TWIST));

        for(i=0;i<gn_pz;i++)
            {

            if(g_pz[i].s>0)
                {
                //k=c_JS_Dir(g_pz[i].ic,w,g_pz[i].r);
                c_JPoint3(gc_w2,0.5,&g_pz[i]);
                pl=&g_hog[gn_play];pl->pc[0]=g_pz[i].p0;pl->pc[1]=g_pz[i].p1;pl->Clas[0]=g_pz[i].i;pl->Clas[1]=gs_database;pl->w=gc_w2; pl->ds=g_pz[i].ds;

                if(g_pz[i].ds>0.666666&&g_pz[i].ds<1.2) goto lps;
                gn_C3++;


                                if(g_pz[i].ds<=0.66666)
                                        {
                                        pl->Class=1;
                                        gn_C1++;
                                        }
                                 else
                                        {
                                        pl->Class=-1;
                                        gn_C2++;
                                        }



                memcpy(pl->path,gm_file->input_filename,260);
                j1=0;
                cx[0]=1.1;cx[1]=1.0;cx[2]=1.2;cx[3]=1.3;cx[4]=1.4;cx[5]=0.9;
                g_len3[0]=cx[0]*gc_w2;g_len3[1]=cx[0]*gc_w2;
                c_Get_Image1(0,0,g_pz[i].p0,0,g_len3,pl);j1++;
                c_Get_Image1(1,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                          c_Get_Image1(2,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                          c_Get_Image1(3,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                          c_Get_Image1(4,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                                    c_Get_Image1(5,j1,g_pz[i].p0,0,g_len3,pl);j1++;

                /*tw[1].ratio.x=-0.3;tw[1].cx.y=0.5;tw[2].ratio.x=-0.2;tw[2].cx.y=0.5;
                tw[3].ratio.x=0.2;tw[3].cx.y=0.5;tw[4].ratio.x=0.4;tw[4].cx.y=0.5;
                tw[5].ratio.y=-0.3;tw[5].cy.x=0.5;tw[6].ratio.y=-0.2;tw[6].cy.x=0.5;
                tw[7].ratio.y=0.2;tw[7].cy.x=0.5;tw[8].ratio.y=0.4;tw[8].cy.x=0.5;*/
                //tw[1].ratio.x=-0.3;tw[2].ratio.x=-0.15;tw[3].ratio.x=0.15;tw[4].ratio.x=0.3;
                //tw[5].ratio.y=-0.3;tw[6].ratio.y=-0.15;tw[7].ratio.y=0.15;tw[8].ratio.y=0.3;
                //tw[0].blur=0.0;tw[1].blur=1.0;tw[2].blur=1.5;tw[3].blur=2.0;tw[4].blur=2.5;tw[5].blur=3.0;tw[6].blur=3.5;tw[7].blur=4.0;tw[8].blur=4.5;
                /*j1=0;
                g_len3[0]=cx[0]*gc_w2;g_len3[1]=cx[0]*gc_w2;
                for(k=0;k<6;k++)
                        {
                        for(m1=0;m1<6;m1++)
                                    {
                                    c_Get_Image0(m1,j1,g_pz[i].p0,2*k,g_len3,pl);j1++;
                                    }
                        }
                for(k=1;k<6;k++)
                        {
                        g_len3[0]=cx[k]*gc_w2;g_len3[1]=cx[k]*gc_w2;
                        for(m1=0;m1<6;m1++)
                                    {
                                    c_Get_Image0(m1,j1,g_pz[i].p0,0,g_len3,pl);j1++;
                                    }
                        }*/
                /*memset(tw,0,20*sizeof(TWIST));
                for(j=0;j<20;j++)
                    {
                    tw[j].margin=0.5;tw[j].enlarge=0.0;
                    }
                tw[0].blur=0.0;tw[1].blur=1.0;tw[2].blur=1.5;tw[3].blur=2.0;tw[4].blur=2.5;tw[5].blur=3.0;tw[6].blur=3.5;tw[7].blur=4.0;tw[8].blur=4.5;
                for(k=1;k<6;k++)
                        {
                        for(m1=0;m1<6;m1++)
                                    {
                                    c_Get_Image2(m1,j1,&tw[k],g_pz[i].p0,g_len3,pl);j1++;
                                    }
                        }

                memset(tw,0,20*sizeof(TWIST));
                for(j=0;j<20;j++)
                    {
                    tw[j].margin=0.5;tw[j].enlarge=0.5;
                    }
                tw[1].ratio.x=-0.3;tw[1].cx.y=0.5;tw[2].ratio.x=0.4;tw[2].cx.y=0.5;
                tw[3].ratio.y=-0.3;tw[3].cy.x=0.5;tw[4].ratio.y=0.4;tw[4].cy.x=0.5;
                for(k=1;k<5;k++)
                        {
                        for(m1=0;m1<6;m1++)
                                    {
                                    c_Get_Image2(m1,j1,&tw[k],g_pz[i].p0,g_len3,pl);j1++;
                                    }
                        }*/



                  gn_play++;

lps:

                t=0;i2++;
                }

            }

    gn_Lk=i2;


    g_C1[gs_database].y=gn_C1;
    g_C3[gs_database].y=gn_C3;



}
void  c_JHOG2(Play *pl,int m)
{
int i,j,i1,i2,j1,k,k1,k2,m2,m3,x,y,x0,y0,n1;
float t,t1,t2,t3,t4,tx,ty,v,v1,max,cx2[40],vx,vy,dx,dy,*h;
U8 *p;

g_mx2=48;g_my2=48;
p=&pl[0].v[m*g_mx2*g_my2];


m2=2;m3=2;
memset(g_Hog,0,sizeof(HOG)*g_mx2*g_my2);

v1=0;
for(y0=0;y0<g_my2;y0++)
{
for(x0=0;x0<g_mx2;x0++)
{
tx=0;i2=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;    
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(x>=0&&x<g_mx2&&y>=0&&y<g_my2)
	{ 
        k=y*g_mx2+x;
        tx+=t1*p[k];i2++;
	}
        }
    
    }
tx=tx/i2;
ty=0;i2=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;k=y*g_mx2;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        if(x>=0&&x<g_mx2&&y>=0&&y<g_my2)
	{  
        k1=k+x;
        ty+=t1*p[k1];i2++;
	}
        }
    }
ty=ty/i2;


max=0;k=0;
for(i=0;i<g_han;i++)
    {
    t=fabs(tx*gc_EVec2[i].x+ty*gc_EVec2[i].y);    
    cx2[i]=t;    
    if(t>max)
    	{
        max=t;k=i;
	}
    }
max=0;k1=0;
for(i=0;i<g_han;i++)
    	{
        if(cx2[i]>max&&i!=k)
        	{
                max=cx2[i];k1=i;   
		}
	}


k2=y0*g_mx2+x0;
g_Hog[k2].d[k]+=cx2[k];g_Hog[k2].d[k1]+=cx2[k1];
if(tx<0) tx=-tx;
if(ty<0) ty=-ty;

if(tx==0&&ty==0)
    {
    v=0;
    goto lp1;
    }

if(tx>ty)
    {
    k=ty/tx*1000;
    v=FSQRT[k]*tx;
    }
else
    {
    k=tx/ty*1000;
    v=FSQRT[k]*ty;
    }
g_Hog[k2].v=v;
lp1:
t=0;
}
}

}

void  c_JHOG(Play *pl,int m,int m1,Rect rec, P_HOG *ph)
{
int i,j,i1,j1,k,k1,m2,m3,x,y,x0,y0,n1;
float t,t1,t2,t3,t4,tx,ty,v,v1,max,cx2[40],vx,vy,dx,dy,*h;
U8 *p;

p=&pl[0].v[m*g_mx2*g_my2];
h=&ph[0].v[m1*g_han];

m2=2;m3=2;
memset(h,0,4*g_han);

v1=0;
for(y0=rec.y0;y0<rec.y1;y0++)
{
for(x0=rec.x0;x0<rec.x1;x0++)
{
k=y0*g_mx2+x0;
for(i=0;i<g_han;i++)
	{
	h[i]+=g_Hog[k].d[i];
	}
v1+=g_Hog[k].v;
}
}


for(i=0;i<g_han;i++)
	{
	h[i]=h[i]/v1;
	}
}


void c_Image_HOG(Play *pl,P_HOG *ph)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,k3,h,w2,h2,n1,n2,n3,w,w3,m3,b[2],b2[2],b3[10],m,md,f1,ic2;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;


g_mx2=48;g_my2=48;
ph[0].Class=pl[0].Class;
ph[0].ds=pl[0].ds;ph[0].p0=pl[0].p0;ph[0].pc[0]=pl[0].pc[0];//ph[0].image=pl[0].image;
memcpy(ph[0].path,pl[0].path,260);
c_JHOG2(pl,0);
rc2.x0=0;rc2.x1=g_mx2;rc2.y0=0;rc2.y1=g_my2;

i1=0;
c_JHOG(pl,0,i1,rc2,ph);i1++;
n1=2;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JHOG(pl,0,i1,rc2,ph);i1++;  
		}
	}
n1=3;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JHOG(pl,0,i1,rc2,ph);i1++;  
		}
	}
n1=4;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JHOG(pl,0,i1,rc2,ph);i1++;  
		}
	}
                
n1=5;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JHOG(pl,0,i1,rc2,ph);i1++;  
		}
	}
ph[0].w=i1*g_han;
}


void c_transTo_HOG(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,m3,m2,x2,y2,n1,n2,n3,n4,b2[10];
float t,t1,t2,t3,*ax,*bx,*cx;
char path[260],path2[260];
FILE *f2;
m=0;
memcpy(path,gm_file->input_path,260);
memcpy(path2,gm_file->input_path,260);
i=0;
while(path[i]!=0&&i<250)
    {
    i++;
    }
j1=i;
memcpy(&path[0],"/home/xychen/server/cnn3/Vehicle_Train48.dat",250);//1c=blur,2c,ratio,3c,twistVehicle_Train48.

f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=1;
k=fread(&g_hog[0],n1,56247,f2);//53637
gn_data=k;
fclose(f2);
memcpy(&path2[0],"/home/xychen/server/cnn3/Vehicle_Test48.dat",250);//1c=blur,2c,ratio,3c,twist
f2=fopen(path2,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(P_HOG);
k=1;
k=fread(&g_hog[gn_data],n1,30000,f2);
gn_data2=k;
fclose(f2);


g_han=9;
for(i=0;i<g_han;i++)
{
gc_EVec2[i].x=cos(PAI/g_han*i);
gc_EVec2[i].y=sin(PAI/g_han*i);
}

for(i=g_han;i<2*g_han;i++)
{
gc_EVec2[i+g_han].x=-gc_EVec2[i].x;
gc_EVec2[i+g_han].y=-gc_EVec2[i].y;
}
g_mx2=48;g_my2=48;
//gn_dim=g_hog[0].dim;
g_radio=2;

return;

g_radio=2;
for(i=0;i<gn_data+gn_data2;i++)
    {
    gm_start=0;
    c_Mnist_HOG(&g_hog[i]);
    //c_Mnist_LBP(0,&g_hog[i]);
    }

f2=fopen(path,"wb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=1;
k=fwrite(&g_hog[0],n1,gn_data,f2);//53637
fclose(f2);

f2=fopen(path2,"wb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=1;
k=fwrite(&g_hog[gn_data],n1,gn_data2,f2);//53637
fclose(f2);

}



void  c_JLBP2(Play *pl,int m)
{
int i,j,i1,i2,j1,k,k1,k2,m2,m3,x,y,x0,y0,n,n1;
float t,t1,t2,t3,t4,tx,ty,v,v1,max,cx2[40],vx,vy,dx,dy,*h;
U8 *p,u[40];

g_mx2=48;g_my2=48;
p=&pl[0].v[m*g_mx2*g_my2];


m2=2;m3=2;
memset(g_Lbp,0,sizeof(LBP)*g_mx2*g_my2);

v1=0;
for(y0=0;y0<g_my2;y0++)
	{
	for(x0=0;x0<g_mx2;x0++)
		{
		v=p[y0*g_mx2+x0];n=0;
		for(i=0;i<gn_dlbp;i++)
			{
			v1=0;
			for(j=0;j<4;j++)
				{
				x=g_dlbp[i].p[j].x+x0;y=g_dlbp[i].p[j].y+y0;
				if(x<0) x=0; if(y<0) y=0;
				if(x>=g_mx2-1) x=g_mx2-1; if(y>=g_my2-1) y=g_my2-1;
                v1+=g_dlbp[i].u[j]*p[y*g_mx2+x];
				}
			u[i]=0;
			if(v1>v+1) u[i]=1;
			n+=u[i];
			}		

		u[gn_dlbp]=u[0];k=0;k1=0;
		for(i=0;i<gn_dlbp;i++)
			{
			if(u[i]!=u[i+1]) k++;
			if(u[i]==1&&k1==0) k1=i;
			}
		g_Lbp[y0*g_mx2+x0].n=n;g_Lbp[y0*g_mx2+x0].x=k1;g_Lbp[y0*g_mx2+x0].y=k1+n;
        if(k>2) g_Lbp[y0*g_mx2+x0].c=0;
        if(k==0&&n==gn_dlbp) g_Lbp[y0*g_mx2+x0].c=1;
        if(k==0&&n==0) g_Lbp[y0*g_mx2+x0].c=2;
        if(k==2) g_Lbp[y0*g_mx2+x0].c=c_lbp[(n-1)*20+k1];
		}
	}


}

void  c_JLBP(Play *pl,int m,int m1,Rect rec, P_LBP *ph)
{
int i,j,i1,j1,k,k1,m2,m3,x,y,x0,y0,n1;
float t,t1,t2,t3,t4,tx,ty,v,v1,max,cx2[40],vx,vy,dx,dy,*h;
U8 *p;



p=&pl[0].v[m*g_mx2*g_my2];
h=&ph[0].v[m1*nc_lbp];


memset(h,0,4*nc_lbp);

v1=0;n1=0;
for(y0=rec.y0;y0<rec.y1;y0++)
{
for(x0=rec.x0;x0<rec.x1;x0++)
{
k=y0*g_mx2+x0;
i=g_Lbp[k].c;
	h[i]++;	
n1++;
}
}

for(i=0;i<nc_lbp;i++)
	{
	h[i]=h[i]/n1;
	}

}

void c_Image_LBP(Play *pl,P_LBP *ph)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,k3,h,w2,h2,n1,n2,n3,w,w3,m3,b[2],b2[2],b3[10],m,md,f1,ic2;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;


g_mx2=48;g_my2=48;
ph[0].Class=pl[0].Class;
ph[0].ds=pl[0].ds;ph[0].p0=pl[0].p0;ph[0].pc[0]=pl[0].pc[0];ph[0].image=pl[0].image;
memcpy(ph[0].path,pl[0].path,260);
c_JLBP2(pl,0);
rc2.x0=0;rc2.x1=g_mx2;rc2.y0=0;rc2.y1=g_my2;

i1=0;
c_JLBP(pl,0,i1,rc2,ph);i1++;
n1=2;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JLBP(pl,0,i1,rc2,ph);i1++;  
		}
	}
n1=3;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JLBP(pl,0,i1,rc2,ph);i1++;  
		}
	}
n1=4;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JLBP(pl,0,i1,rc2,ph);i1++;  
		}
	}
                
n1=5;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JLBP(pl,0,i1,rc2,ph);i1++;  
		}
	}
ph[0].w=i1*nc_lbp;
}

void c_init_LBP()
{
int i1,i,j,i2,k,x,y;
float t,t1,t2,t3;

gn_dlbp=4*g_han2;
i1=0;
x=g_radio;t=g_radio-x;
g_dlbp[i1].x=g_radio;g_dlbp[i1].y=0;
g_dlbp[i1].p[0].x=x;g_dlbp[i1].p[0].y=0;
g_dlbp[i1].p[1].x=1+x;g_dlbp[i1].p[1].y=0;
g_dlbp[i1].p[2].x=x+1;g_dlbp[i1].p[2].y=1;
g_dlbp[i1].p[3].x=x;g_dlbp[i1].p[3].y=1;
g_dlbp[i1].u[0]=1-t;g_dlbp[i1].u[1]=t;g_dlbp[i1].u[2]=0;g_dlbp[i1].u[3]=0;
i1++;
for(i=1;i<g_han2;i++)
	{
    g_dlbp[i1].x=g_radio*cos(i*PAI/(2*g_han2)); g_dlbp[i1].y=g_radio*sin(i*PAI/(2*g_han2));
        x=g_dlbp[i1].x;y=g_dlbp[i1].y;t=g_dlbp[i1].x-x;t1=g_dlbp[i1].y-y;
        g_dlbp[i1].u[0]=(1-t)*(1-t1);g_dlbp[i1].u[1]=t*(1-t1);g_dlbp[i1].u[2]=t*t1;g_dlbp[i1].u[3]=(1-t)*t1;
        g_dlbp[i1].p[0].x=x;g_dlbp[i1].p[0].y=y;
        g_dlbp[i1].p[1].x=1+x;g_dlbp[i1].p[1].y=y;
        g_dlbp[i1].p[2].x=x+1;g_dlbp[i1].p[2].y=y+1;
        g_dlbp[i1].p[3].x=x;g_dlbp[i1].p[3].y=y+1;
        i1++;
	}
y=g_radio;t=g_radio-y;
g_dlbp[i1].y=g_radio;g_dlbp[i1].x=0;
g_dlbp[i1].p[0].x=0;g_dlbp[i1].p[0].y=y;
g_dlbp[i1].p[1].x=0;g_dlbp[i1].p[1].y=1+y;
g_dlbp[i1].p[2].x=-1;g_dlbp[i1].p[2].y=1+y;
g_dlbp[i1].p[3].x=-1;g_dlbp[i1].p[3].y=y;
g_dlbp[i1].u[0]=1-t;g_dlbp[i1].u[1]=t;g_dlbp[i1].u[2]=0;g_dlbp[i1].u[3]=0;
i1++;
for(i=1;i<g_han2;i++)
	{
    g_dlbp[i1].y=g_radio*cos(i*PAI/(2*g_han2)); g_dlbp[i1].x=-g_radio*sin(i*PAI/(2*g_han2));
        x=g_dlbp[i1].x;y=g_dlbp[i1].y;t=g_dlbp[i1].y-y;t1=x-g_dlbp[i1].x;
        g_dlbp[i1].u[0]=(1-t)*(1-t1);g_dlbp[i1].u[1]=t*(1-t1);g_dlbp[i1].u[2]=t*t1;g_dlbp[i1].u[3]=(1-t)*t1;
        g_dlbp[i1].p[0].x=x;g_dlbp[i1].p[0].y=y;
        g_dlbp[i1].p[1].x=x;g_dlbp[i1].p[1].y=y+1;
        g_dlbp[i1].p[2].x=x-1;g_dlbp[i1].p[2].y=y+1;
        g_dlbp[i1].p[3].x=x-1;g_dlbp[i1].p[3].y=y;
        i1++;
	}

x=-g_radio;t=x+g_radio;
g_dlbp[i1].x=-g_radio;g_dlbp[i1].y=0;
g_dlbp[i1].p[0].x=x;g_dlbp[i1].p[0].y=0;
g_dlbp[i1].p[1].x=x-1;g_dlbp[i1].p[1].y=0;
g_dlbp[i1].p[2].x=x-1;g_dlbp[i1].p[2].y=-1;
g_dlbp[i1].p[3].x=x;g_dlbp[i1].p[3].y=-1;
g_dlbp[i1].u[0]=1-t;g_dlbp[i1].u[1]=t;g_dlbp[i1].u[2]=0;g_dlbp[i1].u[3]=0;
i1++;
for(i=1;i<g_han2;i++)
	{
    g_dlbp[i1].x=-g_radio*cos(i*PAI/(2*g_han2)); g_dlbp[i1].y=-g_radio*sin(i*PAI/(2*g_han2));
        x=g_dlbp[i1].x;y=g_dlbp[i1].y;t=y-g_dlbp[i1].y;t1=x-g_dlbp[i1].x;
        g_dlbp[i1].u[0]=(1-t)*(1-t1);g_dlbp[i1].u[1]=t*(1-t1);g_dlbp[i1].u[2]=t*t1;g_dlbp[i1].u[3]=(1-t)*t1;
        g_dlbp[i1].p[0].x=x;g_dlbp[i1].p[0].y=y;
        g_dlbp[i1].p[1].x=x-1;g_dlbp[i1].p[1].y=y;
        g_dlbp[i1].p[2].x=x-1;g_dlbp[i1].p[2].y=y-1;
        g_dlbp[i1].p[3].x=x;g_dlbp[i1].p[3].y=y-1;
        i1++;
	}
y=-g_radio;t=y+g_radio;
g_dlbp[i1].x=-g_radio;g_dlbp[i1].y=0;
g_dlbp[i1].p[0].x=0;g_dlbp[i1].p[0].y=y;
g_dlbp[i1].p[1].x=0;g_dlbp[i1].p[1].y=y-1;
g_dlbp[i1].p[2].x=1;g_dlbp[i1].p[2].y=y-1;
g_dlbp[i1].p[3].x=1;g_dlbp[i1].p[3].y=y;
g_dlbp[i1].u[0]=1-t;g_dlbp[i1].u[1]=t;g_dlbp[i1].u[2]=0;g_dlbp[i1].u[3]=0;
i1++;
for(i=1;i<g_han2;i++)
	{
    g_dlbp[i1].x=g_radio*sin(i*PAI/(2*g_han2)); g_dlbp[i1].y=-g_radio*cos(i*PAI/(2*g_han2));
        x=g_dlbp[i1].x;y=g_dlbp[i1].y;t=y-g_dlbp[i1].y;t1=g_dlbp[i1].x-x;
        g_dlbp[i1].u[0]=(1-t)*(1-t1);g_dlbp[i1].u[1]=t*(1-t1);g_dlbp[i1].u[2]=t*t1;g_dlbp[i1].u[3]=(1-t)*t1;
        g_dlbp[i1].p[0].x=x;g_dlbp[i1].p[0].y=y;
        g_dlbp[i1].p[1].x=x;g_dlbp[i1].p[1].y=y-1;
        g_dlbp[i1].p[2].x=x+1;g_dlbp[i1].p[2].y=y-1;
        g_dlbp[i1].p[3].x=x+1;g_dlbp[i1].p[3].y=y;
        i1++;
	}
gn_dlbp=i1;
i2=3;
for(i1=0;i1<gn_dlbp-1;i1++)
	{                
        for(j=0;j<gn_dlbp;j++)
        	{ 
        	c_lbp[i1*20+j]=i2;i2++;
		}
	}

nc_lbp=i2;
}
void c_transTo_LBP(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,n1,n2,n3,n4,b2[10];
float t,ax[100];
char path[260],path2[260];
FILE *f2;
m=0;
memcpy(path,gm_file->input_path,260);
memcpy(path2,gm_file->input_path,260);
i=0;
while(path[i]!=0&&i<250)
    {
    i++;
    }
j1=i;
if(m1==1) memcpy(&path[j1],"/Play_File0c.dat",40);//1c=blur,2c,ratio,3c,twist
if(m1==3) memcpy(&path[j1],"/Play_File0d.dat",40);
if(m1==1) memcpy(&path2[j1],"/LBP_File0c.dat",40);
if(m1==3) memcpy(&path2[j1],"/LBP_File0d.dat",40);

f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(Play);
k=1;m=0;
while(k>0)
{
k=fread(&g_data[m],n1,1,f2);
if(k>0) m++;
}
gn_data=m;
fclose(f2);

g_han2=2;
g_radio=1.5;
c_init_LBP();

f2=fopen(path2,"wb");
fseek(f2,0,SEEK_SET);
n2=sizeof(P_LBP);
n3=gn_data/10000;
n4=gn_data-n3*10000;
i1=0;
for(j=0;j<n3;j++)
{
for(i=0;i<10000;i++)
	{
	c_Image_LBP(&g_data[i1],&g_lbp[i]);  i1++;     
	}
k=fwrite(g_lbp,n2,10000,f2);
}
for(i=0;i<n4;i++)
	{
	c_Image_LBP(&g_data[i1],&g_lbp[i]); i1++;      
	}
k=fwrite(g_lbp,n2,n4,f2);
fclose(f2);
}


void c_transTo_BST(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,n1,n2,n3,n4,b2[10];
float t,ax[100];
char path[260],path2[260];
FILE *f2;
m=0;
memcpy(path,gm_file->input_path,260);
memcpy(path2,gm_file->input_path,260);
i=0;
while(path[i]!=0&&i<250)
    {
    i++;
    }
j1=i;
if(m1==1) memcpy(&path[j1],"/Play_File0c.dat",40);//1c=blur,2c,ratio,3c,twist
if(m1==3) memcpy(&path[j1],"/Play_File0d.dat",40);
if(m1==1) memcpy(&path2[j1],"/BST_File0c.dat",40);
if(m1==3) memcpy(&path2[j1],"/BST_File0d.dat",40);

f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(Play);
k=1;m=0;
while(k>0)
{
k=fread(&g_data[m],n1,1,f2);
if(k>0) m++;
}
gn_data=m;
fclose(f2);



f2=fopen(path2,"wb");
fseek(f2,0,SEEK_SET);
n2=sizeof(P_BST);
n3=gn_data/10000;
n4=gn_data-n3*10000;
i1=0;
for(j=0;j<n3;j++)
{
for(i=0;i<10000;i++)
    {
    c_Image_BST(&g_data[i1],&g_bst[i]);  i1++;
    }
k=fwrite(g_bst,n2,10000,f2);
}
for(i=0;i<n4;i++)
    {
    c_Image_BST(&g_data[i1],&g_bst[i]); i1++;
    }
k=fwrite(g_bst,n2,n4,f2);
fclose(f2);
}

void c_Image_BST(Play *pl,P_BST *ph)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,k3,h,w2,h2,n1,n2,n3,w,w3,m3,b[2],b2[2],b3[10],m,md,f1,ic2;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;


g_mx2=48;g_my2=48;
ph[0].Class=pl[0].Class;
ph[0].ds=pl[0].ds;ph[0].p0=pl[0].p0;ph[0].pc[0]=pl[0].pc[0];ph[0].image=pl[0].image;
memcpy(ph[0].path,pl[0].path,260);
c_JBST2(pl,0);
rc2.x0=0;rc2.x1=g_mx2;rc2.y0=0;rc2.y1=g_my2;
ph[0].w=0;


c_JBST(4,2,ph);
c_JBST(6,3,ph);
c_JBST(8,4,ph);
c_JBST(12,6,ph);
c_JBST(16,8,ph);
c_JBST(3,3,ph);
c_JBST(4,4,ph);
c_JBST(6,6,ph);
c_JBST(8,8,ph);
c_JBST(12,12,ph);
c_JBST(16,16,ph);

}


void  c_JBST2(Play *pl,int m)
{
int i,j,i1,i2,j1,k,k1,k2,m2,m3,x,y,x0,y0,n,n1;
float t,t1,t2,t3,t4,tx,ty,v,v1,max,cx2[40],vx,vy,dx,dy,*ax,*bx,*h;
U8 *p,u[40];

g_mx2=48;g_my2=48;
p=&pl[0].v[m*g_mx2*g_my2];
ax=c_file.pDis[0];
bx=c_file.pDis[1];

for(y0=0;y0<g_my2;y0++)
    {
        k=y0*g_mx2;
        t=0;
    for(x0=0;x0<g_mx2;x0++)
        {
            t+=p[k+x0];
            ax[k+x0]=t;
        }
    }

for(x0=0;x0<g_mx2;x0++)
    {
    for(y0=0;y0<g_my2;y0++)
        {
            t=0;
            for(j=0;j<=y0;j++)
            {
            t+=ax[j*g_mx2+x0];
            }

            bx[y0*g_mx2+x0]=t;
        }
    }

}


void  c_JBST(int mx,int dx,P_BST *ph)
{
int i,j,i1,i2,j1,k,k1,m2,m3,x,y,x0,y0,n1,n2,n3;
float t,t1,t2,t3,t4,tx,ty,v[4],v1,max,cx2[40],*ax,*bx,*h;
U8 *p;


bx=c_file.pDis[1];
ax=c_file.pDis[2];
i2=0;
n1=(g_my2-mx)/dx+1;n2=(g_mx2-mx)/dx+1;
for(y0=0;y0<=g_my2-mx;y0+=dx)
    {
    for(x0=0;x0<=g_mx2-mx;x0+=dx)
        {
                v[0]=0;v[1]=0;v[3]=0;
                k=(y0+mx-1)*g_mx2+(x0+mx-1);v[2]=bx[k];
                if(y0>0&&x0>0)
            {
            k=(y0-1)*g_mx2+x0-1; v[0]=bx[k];
            }
                if(x0>0)
            {
            k=(y0+mx-1)*g_mx2+x0-1; v[1]=bx[k];
            }
                if(y0>0)
            {
            k=(y0-1)*g_mx2+x0+mx-1; v[3]=bx[k];
            }
                t=(v[2]+v[0]-v[1]-v[3])/(mx*mx);
                ax[i2]=t;i2++;
        }
    }

i1=ph[0].w;v[0]=0;v[1]=0;v[2]=0;v[3]=0;
for(j=0;j<n1-1;j++)
    {
        for(i=0;i<n2-1;i++)
            {
            t=ax[j*n2+i];
            k=i1;
                ph[0].v[k+0]=t-ax[j*n2+i+1];
                ph[0].v[k+1]=t-ax[j*n2+i+n2];
                ph[0].v[k+2]=t-ax[j*n2+i+1+n2];
                ph[0].v[k+3]=ax[j*n2+i+1]-ax[j*n2+i+n2];
                i1+=4;
                for(j1=0;j1<4;j1++)
                {
                if(v[j1]<fabs(ph[0].v[k+j1])) v[j1]=fabs(ph[0].v[k+j1]);
                }
        }
    }
n3=(n1-1)*(n2-1);
for(i=0;i<n3;i++)
{
    k=ph[0].w+i*4;
    for(j=0;j<4;j++)
        {
        if(v[j]>0) ph[0].v[k+j]=ph[0].v[k+j]/v[j];
        }
}

ph[0].w+=n3*4;

}



void c_transTo_HOC(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,n1,n2,n3,n4,b2[10];
float t,ax[100];
char path[260],path2[260];
FILE *f2;
m=0;
memcpy(path,gm_file->input_path,260);
memcpy(path2,gm_file->input_path,260);
i=0;
while(path[i]!=0&&i<250)
    {
    i++;
    }
j1=i;
if(m1==1) memcpy(&path[j1],"/Play_File0c.dat",40);//1c=blur,2c,ratio,3c,twist
if(m1==3) memcpy(&path[j1],"/Play_File0d.dat",40);
if(m1==1) memcpy(&path2[j1],"/HOC_File0c.dat",40);
if(m1==3) memcpy(&path2[j1],"/HOC_File0d.dat",40);

f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(Play);
k=1;m=0;
while(k>0)
{
k=fread(&g_data[m],n1,1,f2);
if(k>0) m++;
}
gn_data=m;
fclose(f2);

g_han=9;
for(i=0;i<g_han;i++)
{
gc_EVec2[i].x=cos(PAI/g_han*i);
gc_EVec2[i].y=sin(PAI/g_han*i);
}
for(i=g_han;i<2*g_han;i++)
{
gc_EVec2[i+g_han].x=-gc_EVec2[i].x;
gc_EVec2[i+g_han].y=-gc_EVec2[i].y;
}

g_han2=2;
g_radio=1.5;
c_init_LBP();

f2=fopen(path2,"wb");
fseek(f2,0,SEEK_SET);
n2=sizeof(P_HOC);
n3=gn_data/10000;
n4=gn_data-n3*10000;
i1=0;
for(j=0;j<n3;j++)
{
for(i=0;i<10000;i++)
	{
	c_Image_HOC(&g_data[i1],&g_hoc[i]);  i1++;     
	}
k=fwrite(g_hoc,n2,10000,f2);
}
for(i=0;i<n4;i++)
	{
	c_Image_HOC(&g_data[i1],&g_hoc[i]); i1++;      
	}
k=fwrite(g_hoc,n2,n4,f2);
fclose(f2);
}



void  c_JHOC2(Play *pl,int m,int mx,int my)
{
int i,j,i1,i2,j1,k,k1,k2,k3,m2,m3,x,y,x0,y0,x1,y1,n1,n2,n3,n4;
float t0,t,t1,t2,t3,t4,tx,ty,v,v1,vt,max,min,cx2[40],cx3[40],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p;


p=&pl[0].v[m*g_mx2*g_my2];
ax=c_file.pDis[0];
bx=&c_file.pDis[0][g_mx2*g_my2];ax2=c_file.pDis[1];

m2=2;m3=2;


v1=0;
for(y0=0;y0<g_my2;y0++)
{
for(x0=0;x0<g_mx2;x0++)
{
tx=0;i2=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0; 
    if(x<0) x=0; 
    if(x>g_mx2-1) x=g_mx2-1;     
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0; 
        if(y>g_my2-1) y=g_my2-1;
        //if(x>=0&&x<g_mx2&&y>=0&&y<g_my2)
        {
        k=y*g_mx2+x;
        tx+=t1*p[k];i2++;
        }
        }
    
    }
tx=tx/i2;
ty=0;i2=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0; 
    if(y>g_my2-1) y=g_my2-1;
    k=y*g_mx2;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        //if(x>=0&&x<g_mx2&&y>=0&&y<g_my2)
        if(x<0) x=0; 
        if(x>g_mx2-1) x=g_mx2-1;  
            {
            k1=k+x;
            ty+=t1*p[k1];i2++;
            }
        }
    }
ty=ty/i2;
ax[y0*g_mx2+x0]=tx;
bx[y0*g_mx2+x0]=ty;

}
}

n1=g_mx2*g_my2;
for(y0=0;y0<g_my2;y0++)
	{
	for(x0=0;x0<g_mx2;x0++)
		{

		t1=ax[y0*g_mx2+x0];t2=bx[y0*g_mx2+x0];
        for(i1=0;i1<gn_dlbp;i1++)
			{
            t3=0;t4=0;
			for(j=0;j<4;j++)
				{
				x=g_dlbp[i1].p[j].x+x0;y=g_dlbp[i1].p[j].y+y0;
				if(x<0) x=0; if(y<0) y=0;
				if(x>=g_mx2-1) x=g_mx2-1; if(y>=g_my2-1) y=g_my2-1;
                		t3+=g_dlbp[i1].u[j]*ax[y*g_mx2+x];
                                t4+=g_dlbp[i1].u[j]*bx[y*g_mx2+x];
                }
			tx=t3-t1;ty=t4-t2;
            k3=y0*g_mx2+x0;

            for(i=0;i<g_han;i++)
    				{
                    t=(tx*gc_EVec2[i].x+ty*gc_EVec2[i].y);
                    ax2[i1*g_han*n1+i*n1+k3]=t;
    				}


			lp1:
                        

			t=0;
			}
        t3=sqrt(t1*t1+t2*t2);
        ax2[gn_dlbp*g_han*n1+k3]=t3;

		}
	}


rx=1.0*(g_mx2-1)/(mx-1);
ry=1.0*(g_my2-1)/(my-1);
n4=gn_dlbp*g_han+1;
for(i1=0;i1<n4;i1++)
    {
    n1=i1*g_mx2*g_my2;
    max=-99999;min=99999;
    for(y0=0;y0<g_my2;y0++)
        {
        for(x0=0;x0<g_mx2;x0++)
            {
            k2=y0*g_mx2+x0;
            t=ax2[n1+k2];
            if(t>max) max=t;
            if(t<min) min=t;
            }
        }
    vt=max-min;
    cx2[i1]=vt;
    if(vt>0)
    	{
        n3=i1*g_mx2*g_my2;
    	n2=i1*mx*my;
    	for(y=0;y<my;y++)
    	    {    	
    	    for(x=0;x<mx;x++)
            	{        
        	tx=rx*x;
        	ty=ry*y;        	
                x0=tx;y0=ty;x1=x0+1;y1=y0+1;
                t1=tx-x0;t2=ty-y0;
                k=y0*g_mx2+x0+n3; k1=y1*g_mx2+x0+n3; k2=y0*g_mx2+x1+n3; k3=y1*g_mx2+x1+n3;
                t=ax2[k];
                k3=255.0*(t-min)/vt;
                k2=y*mx+x;
                pl[0].v[1*mx*my+n2+k2]=k3;
                }
            }
        } 
     else
         {
         memset(&pl[0].v[1*mx*my+i1*mx*my],0,mx*my);
         }   
        
       

    }

pl[0].w=0;

}




void  c_JHOC3(Play *pl,int m,int mx,int my)
{
int i,j,i1,i2,j1,k,k1,k2,k3,m2,m3,x,y,x0,y0,x1,y1,n1,n2,n3,n4;
float t0,t,t1,t2,t3,t4,tx,ty,v,v1,vt,max,min,cx2[40],cx3[40],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p;


p=&pl[0].v[m*g_mx2*g_my2];
ax=c_file.pDis[0];
bx=&c_file.pDis[0][g_mx2*g_my2];ax2=c_file.pDis[1];

m2=2;m3=2;


v1=0;
for(y0=0;y0<g_my2;y0++)
{
for(x0=0;x0<g_mx2;x0++)
{
tx=0;i2=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    if(x<0) x=0;
    if(x>g_mx2-1) x=g_mx2-1;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0;
        if(y>g_my2-1) y=g_my2-1;
        //if(x>=0&&x<g_mx2&&y>=0&&y<g_my2)
        {
        k=y*g_mx2+x;
        tx+=t1*p[k];i2++;
        }
        }

    }
tx=tx/i2;
ty=0;i2=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0;
    if(y>g_my2-1) y=g_my2-1;
    k=y*g_mx2;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        //if(x>=0&&x<g_mx2&&y>=0&&y<g_my2)
        if(x<0) x=0;
        if(x>g_mx2-1) x=g_mx2-1;
            {
            k1=k+x;
            ty+=t1*p[k1];i2++;
            }
        }
    }
ty=ty/i2;
ax[y0*g_mx2+x0]=tx;
bx[y0*g_mx2+x0]=ty;

}
}

n1=g_mx2*g_my2;
for(y0=0;y0<g_my2;y0++)
    {
    for(x0=0;x0<g_mx2;x0++)
        {

        t1=ax[y0*g_mx2+x0];t2=bx[y0*g_mx2+x0];
        for(i1=0;i1<gn_dlbp;i1++)
            {
            t3=0;t4=0;
            for(j=0;j<4;j++)
                {
                x=g_dlbp[i1].p[j].x+x0;y=g_dlbp[i1].p[j].y+y0;
                if(x<0) x=0; if(y<0) y=0;
                if(x>=g_mx2-1) x=g_mx2-1; if(y>=g_my2-1) y=g_my2-1;
                        t3+=g_dlbp[i1].u[j]*ax[y*g_mx2+x];
                                t4+=g_dlbp[i1].u[j]*bx[y*g_mx2+x];
                }
            tx=t3-t1;ty=t4-t2;
            k3=y0*g_mx2+x0;

            for(i=0;i<g_han;i++)
                    {
                    t=(tx*gc_EVec2[i].x+ty*gc_EVec2[i].y);
                    ax2[i1*g_han*n1+i*n1+k3]=t;
                    }


            lp1:


            t=0;
            }
        t3=sqrt(t1*t1+t2*t2);
        ax2[gn_dlbp*g_han*n1+k3]=t3;

        }
    }


rx=1.0*(g_mx2-1)/(mx-1);
ry=1.0*(g_my2-1)/(my-1);
n4=gn_dlbp*g_han+1;
for(i1=0;i1<n4;i1++)
    {
    n1=i1*g_mx2*g_my2;
    max=-99999;min=99999;
    for(y0=0;y0<g_my2;y0++)
        {
        for(x0=0;x0<g_mx2;x0++)
            {
            k2=y0*g_mx2+x0;
            t=ax2[n1+k2];
            if(t>max) max=t;
            if(t<min) min=t;
            }
        }
    vt=max-min;
    cx2[i1]=vt;
    if(vt>0)
        {
        n3=i1*g_mx2*g_my2;
        n2=i1*mx*my;
        for(y=0;y<my;y++)
            {
            for(x=0;x<mx;x++)
                {
            tx=rx*x;
            ty=ry*y;
                x0=tx;y0=ty;x1=x0+1;y1=y0+1;
                t1=tx-x0;t2=ty-y0;
                k=y0*g_mx2+x0+n3; k1=y1*g_mx2+x0+n3; k2=y0*g_mx2+x1+n3; k3=y1*g_mx2+x1+n3;
                t=ax2[k];
                k3=255.0*(t-min)/vt;
                k2=y*mx+x;
                pl[0].v[1*mx*my+n2+k2]=k3;
                }
            }
        }
     else
         {
         memset(&pl[0].v[1*mx*my+i1*mx*my],0,mx*my);
         }



    }

pl[0].w=0;

}

void  c_JHOC(Play *pl,int m,int m1,Rect rec, P_HOC *ph)
{
int i,j,i1,j1,k,k1,m2,m3,x,y,x0,y0,n1;
float t,t1,t2,t3,t4,tx,ty,v,max,cx2[40],vx,vy,dx,dy,v1[40],*h;
U8 *p;

p=&pl[0].v[m*g_mx2*g_my2];
h=&ph[0].v[m1*g_han*gn_dlbp];

m2=2;m3=2;
memset(h,0,4*g_han*gn_dlbp);

memset(v1,0,4*gn_dlbp);
for(y0=rec.y0;y0<rec.y1;y0++)
{
for(x0=rec.x0;x0<rec.x1;x0++)
{
k=y0*g_mx2+x0;
for(i=0;i<gn_dlbp;i++)
	{         
	for(j=0;j<g_han;j++)
		{
        	k1=i*g_han+j;   
		h[k1]+=g_Hoc[k].d[k1];
		}
		
    v1[i]+=g_Hoc[k].v[i];
	}
}
}


for(i=0;i<gn_dlbp;i++)
	{
        for(j=0;j<g_han;j++)
		{
        	k1=i*g_han+j;   
        if(v1[i]>0) h[k1]=h[k1]/v1[i];
		}	
	}


}


void  c_Jhoc(Play *pl,int m1,Rect rec)
{
int i,j,i1,j1,k,k1,m2,m3,x,y,x0,y0,n1;
float t,t1,t2,t3,t4,tx,ty,v,max,cx2[40],vx,vy,dx,dy,v1[40],*h;
U8 *p;


h=&pl[0].ipf[m1*g_han*gn_dlbp];

m2=2;m3=2;
memset(h,0,4*g_han*gn_dlbp);

memset(v1,0,4*gn_dlbp);
for(y0=rec.y0;y0<rec.y1;y0++)
{
for(x0=rec.x0;x0<rec.x1;x0++)
{
k=y0*g_mx2+x0;
for(i=0;i<gn_dlbp;i++)
    {
    for(j=0;j<g_han;j++)
        {
            k1=i*g_han+j;
        h[k1]+=g_Hoc[k].d[k1];
        }

    v1[i]+=g_Hoc[k].v[i];
    }
}
}


for(i=0;i<gn_dlbp;i++)
    {
        for(j=0;j<g_han;j++)
        {
            k1=i*g_han+j;
        if(v1[i]>0) h[k1]=h[k1]/v1[i];
        }
    }


}



void c_Image_HOC(Play *pl,P_HOC *ph)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,k3,h,w2,h2,n1,n2,n3,w,w3,m3,b[2],b2[2],b3[10],m,md,f1,ic2;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;


g_mx2=48;g_my2=48;
ph[0].Class=pl[0].Class;
ph[0].ds=pl[0].ds;ph[0].p0=pl[0].p0;ph[0].pc[0]=pl[0].pc[0];ph[0].image=pl[0].image;
memcpy(ph[0].path,pl[0].path,260);
c_JHOC2(pl,0,28,28);
ph[0].w=gn_dlbp*2;

/*rc2.x0=0;rc2.x1=g_mx2;rc2.y0=0;rc2.y1=g_my2;
i1=0;
c_JHOC(pl,0,i1,rc2,ph);i1++;

n1=2;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JHOC(pl,0,i1,rc2,ph);i1++;  
		}
	}
n1=3;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JHOC(pl,0,i1,rc2,ph);i1++;  
		}
	}
n1=4;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JHOC(pl,0,i1,rc2,ph);i1++;  
		}
	}
                
n1=5;
for(i=0;i<n1;i++)
	{
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
	for(j=0;j<n1;j++)
		{
		rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;	
                c_JHOC(pl,0,i1,rc2,ph);i1++;  
		}
	}
ph[0].w=i1*g_han*gn_dlbp;*/

}


void c_JS_HOC(int m1,Play *pl)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,k3,h,w2,h2,n1,n2,n3,w,w3,m3,b[2],b2[2],b3[10],m,md,mx,my,f1,ic2;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;


if(m1==0) {g_mx2=48;g_my2=48;mx=48;my=48;}
if(m1==1) {g_mx2=28;g_my2=28;mx=28;my=28;}


c_JHOC2(pl,0,mx,mx);


/*rc2.x0=0;rc2.x1=g_mx2;rc2.y0=0;rc2.y1=g_my2;

i1=0;
c_Jhoc(pl,i1,rc2);i1++;
n1=2;
for(i=0;i<n1;i++)
    {
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
    for(j=0;j<n1;j++)
        {
        rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;
        c_Jhoc(pl,i1,rc2);i1++;
        }
    }
n1=3;
for(i=0;i<n1;i++)
    {
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
    for(j=0;j<n1;j++)
        {
        rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;
        c_Jhoc(pl,i1,rc2);i1++;
        }
    }
n1=4;
for(i=0;i<n1;i++)
    {
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
    for(j=0;j<n1;j++)
        {
        rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;
        c_Jhoc(pl,i1,rc2);i1++;
        }
    }

n1=5;
for(i=0;i<n1;i++)
    {
        rc2.x0=(i*g_mx2)/n1;rc2.x1=((i+1)*g_mx2)/n1;
    for(j=0;j<n1;j++)
        {
        rc2.y0=(j*g_my2)/n1;rc2.y1=((j+1)*g_my2)/n1;
        c_Jhoc(pl,i1,rc2);i1++;
        }
    }
pl[0].w=i1*g_han*gn_dlbp;
*/

}



void c_trans_Minist(int m1,int m2)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,n1,n2,n3,n4,b2[10];
float t,ax[100];
char path[260],path2[260];
FILE *f2;
m=0;

//if(m1==1&&m2==0) memcpy(path,"/home/xychen/mnist/train_48.dat",200);//1c=blur,2c,ratio,3c,twist
//if(m1==3&&m2==0) memcpy(path,"/home/xychen/mnist/test_48.dat",200);

memcpy(path,"/home/xychen/mnist/trainf_28.dat",200);//1c=blur,2c,ratio,3c,twist

f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(P_HOG);
k=fread(g_data,n1,70000,f2);
gn_data=k;
fclose(f2);

/*
memcpy(path,"/home/xychen/mnist/testf_28.dat",200);
g_data2=(P_HOG *)&g_data[gn_data];

f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(P_HOG);
k=fread(g_data2,n1,70000,f2);
gn_data2=k;
fclose(f2);


g_han=3;
for(i=0;i<g_han;i++)
{
gc_EVec2[i].x=cos(PAI/g_han*i);
gc_EVec2[i].y=sin(PAI/g_han*i);
}
for(i=g_han;i<2*g_han;i++)
{
gc_EVec2[i+g_han].x=-gc_EVec2[i].x;
gc_EVec2[i+g_han].y=-gc_EVec2[i].y;
}

g_han2=2;
g_radio=2.0;
c_init_LBP();*/



}







void c_get_info2(char *path)
{
int i,j,k,k1,n1,n2,b[10],b2[10],c1,tr,oc,nc,s1,nf,nf2,f1,f12;
Rect rec;
Object *ob;
FILE  *f2;
char p2[260],p3[260],fname[260];
memcpy(fname,path,260);

i=g_pn2+1;f1=0;
while(f1==0)
{
if(path[i]>0x30&&path[i]<0x3a) f1=i;
i++;
}

while(path[i]!=46)
{
i++;
}
f12=i-1;
n1=i-f1;
k1=path[f1]-0x30;
for(j=f1+1;j<=f12;j++)
{
    k1=k1*10+path[j]-0x30;
}

k=c_OpenFile3(path,120);
if(k!=1)
{
    return;
}
nf=gn_man-1;
nf2=gn_face;
memcpy(g_hog[nf2].path,g_fac[nf].path,260);
g_hog[nf2].Class=g_fac[nf].Class;
g_hog[nf2].DIBWidth=c_file.DIBWidth;
g_hog[nf2].w=50;
g_hog[nf2].h=50;
g_hog[nf2].id=k1;

//memcpy(g_hog[nf2].v,c_file.pRGB,c_file.DIBWidth*c_file.ImageHeight);
rec.x0=35;rec.x1=85;
rec.y0=35;rec.y1=85;
c_Fac_Threshold(&g_hog[nf2],rec,50,50);

//c_Fac_HOG(&g_hog[nf2],rec,50,50);
g_fac[nf].n++;
gn_face++;
}

int c_file_read2(char *path,struct stat *fst,int flag)
{
int i,j,k,n1,n2;
  char   filename[260];
  memcpy(filename,path,260);

  if(gn_man==0&&g_pn1==0)
  {
  i=0;
  while(path[i]!=0)
    {
    i++;
    }
  g_pn1=i;
  return(0);
  }

  if(flag==FTW_D)
      {
      memcpy(g_fac[gn_man].path,&path[g_pn1+1],160);
      g_fac[gn_man].n=0;g_fac[gn_man].Class=gn_man+1;
      i=0;
      while(path[i]!=0)
        {
        i++;
        }
      g_pn2=i;
      gn_man++;
      }
    if(flag!=FTW_D)
        {
        c_get_info2(path);
        //if(gn_face>10) return;
        }
    return(0);
}

void c_trans_LFW(int m1,int m2)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,n1,n2,n3,n4,b2[10];
float t,ax[100];
char path[260],path2[260];
FILE *f2;

g_han=9;g_p5=0;
for(i=0;i<g_han;i++)
{
gc_EVec2[i].x=cos(PAI/g_han*i);
gc_EVec2[i].y=sin(PAI/g_han*i);
}
for(i=g_han;i<2*g_han;i++)
{
gc_EVec2[i+g_han].x=-gc_EVec2[i].x;
gc_EVec2[i+g_han].y=-gc_EVec2[i].y;
}

m=0;
g_pn1=0;
gn_man=0;gn_face=0;
memcpy(path,"/home/xychen/LFW/pic/",260);
k=ftw(path,c_file_read2,300);

g_fac[0].nf=gn_man;
g_fac[0].nf2=gn_face;

memcpy(path,"/home/xychen/LFW/fac_rgb.dat",260);
f2=fopen(path,"wb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=fwrite(g_hog,n1,gn_face,f2);
fclose(f2);


}



void c_LFW_pairs(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,s1,s2,start,n1,n2,n3,n4,b2[10];
float t,ax[100];
char path[260],path2[260],fname[260];
FILE *f2;
U8 *p;
m=0;

memcpy(path,"/home/xychen/LFW/fac_rgb.dat",260);
n1=sizeof(P_Fac);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=fread(g_hog,n1,20000,f2);
gn_face=k;
fclose(f2);

p=c_file.pBuf;

if(m1==0) memcpy(path,"/home/xychen/LFW/pairsDevTrain.txt",260);
if(m1==1) memcpy(path,"/home/xychen/LFW/pairsDevTest.txt",260);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

k=fread(p,1,70000,f2);
gn_buf=k;

n1=0;
start=1;
s1=0;
k=0;
lp1:
if(p[k]==0x09&&start==1) 
{
memcpy(g_pair[n1].man,&p[s1],k-s1);
g_pair[n1].man[k-s1]=0;
g_pair[n1].s1=k-s1;
start=2;
s1=k+1;
}
else if(p[k]==0x09&&start==2) 
{
j=p[s1]-0x30;
for(i=s1+1;i<k;i++)
{
j=j*10+p[i]-0x30;
}
g_pair[n1].id=j;
start=3;
s1=k+1;
}
else if(p[k]==0x0a&&start==3) 
{
j=p[s1]-0x30;
for(i=s1+1;i<k;i++)
{
j=j*10+p[i]-0x30;
}
g_pair[n1].id2=j;
g_pair[n1].Class=1;
start=1;
s1=k+1;
n1++;
}
else if(p[k]==0x09&&start==3) 
{
memcpy(g_pair[n1].man2,&p[s1],k-s1);
g_pair[n1].man2[k-s1]=0;
g_pair[n1].s2=k-s1;
g_pair[n1].Class=0;
start=4;
s1=k+1;
}
else if(p[k]==0x0a&&start==4) 
{
j=p[s1]-0x30;
for(i=s1+1;i<k;i++)
{
j=j*10+p[i]-0x30;
}
g_pair[n1].id2=j;
start=1;
s1=k+1;
n1++;
}



k++;
if(k<gn_buf) goto lp1;
for(i=0;i<n1;i++)
{
 c_search_pairs(i);
}

if(m1==0) memcpy(path,"/home/xychen/LFW/pairsDevTrain.dat",260);
if(m1==1) memcpy(path,"/home/xychen/LFW/pairsDevTest.dat",260);
f2=fopen(path,"wb");
s1=sizeof(M_Pair);
k=fwrite(g_pair,s1,n1,f2);
fclose(f2);


}



void c_LFW_people(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,s1,s2,start,n1,n2,n3,n4,b2[10],max;
float t,ax[100];
char path[260],path2[260];
FILE *f2;
U8 *p;
m=0;


p=c_file.pBuf;

if(m1==0) memcpy(path,"/home/xychen/LFW/peopleDevTrain.txt",260);
if(m1==1) memcpy(path,"/home/xychen/LFW/peopleDevTest.txt",260);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

k=fread(p,1,70000,f2);
gn_buf=k;
k=0;

n1=0;
start=1;
s1=0;
lp1:
if(p[k]==0x09&&start==1) 
{
memcpy(g_pair[n1].man,&p[s1],k-s1);
g_pair[n1].man[k-s1]=0;
g_pair[n1].s1=k-s1;
start=2;
s1=k+1;
}
else if(p[k]==0x0a&&start==2) 
{
j=p[s1]-0x30;
for(i=s1+1;i<k;i++)
{
j=j*10+p[i]-0x30;
}
g_pair[n1].n1=j;
start=1;
s1=k+1;
n1++;
}

k++;


if(k<gn_buf) goto lp1;

g_pair2=&g_pair[5000];

for(i=0;i<n1;i++)
{
    amp[i]=0;
}

for(i=0;i<n1;i++)
    {
    max=0;
    for(j=0;j<n1;j++)
        {
        if(amp[j]==0&&g_pair[j].n1>max)
            {
            max=g_pair[j].n1;k=j;
            }
        }
    amp[k]=1;
    anp[i]=k;
    }

for(i=0;i<n1;i++)
    {

    k=anp[i];
    memcpy(&g_pair2[i],&g_pair[k],sizeof(M_Pair));
    g_pair2[i].Class=i;
    }




if(m1==0) memcpy(path,"/home/xychen/LFW/peopleDevTrain.dat",260);
if(m1==1) memcpy(path,"/home/xychen/LFW/peopleDevTest.dat",260);
f2=fopen(path,"wb");
s1=sizeof(M_Pair);
k=fwrite(g_pair2,s1,n1,f2);
fclose(f2);


}


void c_search_pairs(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,s1,s2,strat,n1,n2,n3,n4,b2[10];
float t,t1,t2,t3,ax[100];
char path[260],path2[260];
FILE *f2;
U8 *p;
m=0;

for(i1=0;i1<gn_face;i1++)
	{
        if(g_pair[m1].Class==1)
        	{
                s1=g_pair[m1].s1;
                t=0; 
                for(k=0;k<=s1;k++)
                	{
                    t+=fabs(g_pair[m1].man[k]-g_hog[i1].path[k]);
                    }
                t1=fabs(g_pair[m1].id-g_hog[i1].id);
                t2=fabs(g_pair[m1].id2-g_hog[i1].id);
                if(t==0&&t1==0) g_pair[m1].n1=i1;
            if(t==0&&t2==0) g_pair[m1].n2=i1;
			
            }
       if(g_pair[m1].Class==0)
        	{
                s1=g_pair[m1].s1;
                t=0; 
                for(k=0;k<=s1;k++)
                	{
                    t+=fabs(g_pair[m1].man[k]-g_hog[i1].path[k]);
                    }
                t1=0; 
                s2=g_pair[m1].s2;
                for(k=0;k<=s2;k++)
                	{
                    t1+=fabs(g_pair[m1].man2[k]-g_hog[i1].path[k]);
                    }
                t2=fabs(g_pair[m1].id-g_hog[i1].id);
                t3=fabs(g_pair[m1].id2-g_hog[i1].id);
                if(t==0&&t2==0) g_pair[m1].n1=i1;
            if(t1==0&&t3==0) g_pair[m1].n2=i1;
            }
	}


}

void c_search_pairs2(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,s1,s2,strat,n1,n2,n3,n4,b2[10];
float t,t1,t2,t3,ax[100];
char path[260],path2[260];
FILE *f2;
U8 *p;
m=0;

for(i1=0;i1<gn_face;i1++)
    {
        if(g_pair2[m1].Class==1)
                {
                s1=g_pair2[m1].s1;
                t=0;
                for(k=0;k<=s1;k++)
                    {
                    t+=fabs(g_pair2[m1].man[k]-g_hog[i1].path[k]);
                    }
                t1=fabs(g_pair2[m1].id-g_hog[i1].id);
                t2=fabs(g_pair2[m1].id2-g_hog[i1].id);
                if(t==0&&t1==0) g_pair2[m1].n1=i1;
                if(t==0&&t2==0) g_pair2[m1].n2=i1;

                }
       if(g_pair2[m1].Class==0)
                {
                s1=g_pair2[m1].s1;
                t=0;
                for(k=0;k<=s1;k++)
                    {
                    t+=fabs(g_pair2[m1].man[k]-g_hog[i1].path[k]);
                    }
                t1=0;
                s2=g_pair2[m1].s2;
                for(k=0;k<=s2;k++)
                    {
                    t1+=fabs(g_pair2[m1].man2[k]-g_hog[i1].path[k]);
                    }
                t2=fabs(g_pair2[m1].id-g_hog[i1].id);
                t3=fabs(g_pair2[m1].id2-g_hog[i1].id);
                if(t==0&&t2==0) g_pair2[m1].n1=i1;
                if(t1==0&&t3==0) g_pair2[m1].n2=i1;
                }
    }


}

void c_build_pairs1(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,s1,s2,strat,n1,n2,n3,n4,b2[100],b3[1000];
float t,t1,t2,t3,t4,ax[100],min;
char path[260],path2[260];
FILE *f2;
U8 *p;
m=0;


memcpy(path,"/home/xychen/LFW/face.dat",260);
n1=sizeof(P_Fac);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=fread(g_hog,n1,20000,f2);
gn_face=k;
fclose(f2);

 memcpy(path,"/home/xychen/LFW/peopleDevTrain.dat",260);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);
n1=sizeof(M_Pair);
k=fread(g_pair,n1,5000,f2);
fclose(f2);
gn_pair=k;
gn_pair2=0;
g_pair2=&g_pair[5000];

for(i1=0;i1<gn_pair;i1++)
{
n1=g_pair[i1].n1;
if(g_pair[i1].n1>1&&g_pair[i1].n1<50)
	{
        for(i=1;i<n1;i++)
        	{
            for(j=i+1;j<=n1;j++)
                {
                g_pair2[gn_pair2].Class=1;
                memcpy(g_pair2[gn_pair2].man,g_pair[i1].man,260);
                g_pair2[gn_pair2].s1=g_pair[i1].s1;
                g_pair2[gn_pair2].id=i;	g_pair2[gn_pair2].id2=j;	   gn_pair2++;
                }
            }
	}

if(g_pair[i1].n1>=50)
	{
        memset(b3,0,g_pair[i1].n1*4+4);
        t=g_pair[i1].n1; 
        for(i=1;i<=50;i++)
        	{
            t1=1.0*g_pair[i1].n1*rand()/RAND_MAX;
                min=9999;
                for(j=1;j<=g_pair[i1].n1;j++)
                    {
                        t=fabs(t1-j);
                        if(b3[j]==0&&t<min)
                        {
                        min=t;k1=j;
                        }
                    }
                b3[k1]=1;
                b2[i]=k1; 
            }
        for(i=1;i<50;i++)
        	{
		for(j=i+1;j<=50;j++)
			{
                        g_pair2[gn_pair2].Class=1; 
                        memcpy(g_pair2[gn_pair2].man,g_pair[i1].man,260);
                        g_pair2[gn_pair2].s1=g_pair[i1].s1;
                        g_pair2[gn_pair2].id=b2[i];	g_pair2[gn_pair2].id2=b2[j];
                        gn_pair2++;	                        
			}
		}
	}

}

for(i=0;i<gn_pair2;i++)
{
 c_search_pairs2(i);
}

memcpy(path,"/home/xychen/LFW/peopleDevTrain2.dat",260);

f2=fopen(path,"wb");
s1=sizeof(M_Pair);
k=fwrite(g_pair2,s1,gn_pair2,f2);
fclose(f2);

}

void c_build_pairs2(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,s1,s2,strat,n1,n2,n3,n4,b2[100],b3[1000];
float t,t1,ax[100];
char path[260],path2[260];
FILE *f2;
U8 *p;
m=0;

memcpy(path,"/home/xychen/LFW/face.dat",260);
n1=sizeof(P_Fac);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=fread(g_hog,n1,20000,f2);
gn_face=k;
fclose(f2);

memcpy(path,"/home/xychen/LFW/peopleDevTrain.dat",260);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);
n1=sizeof(M_Pair);
k=fread(g_pair,n1,5000,f2);
gn_pair=k;
gn_pair2=0;
g_pair2=&g_pair[5000];

for(i2=0;i2<40000;i2++)
{

    t=1.0*(gn_pair-1)*rand()/RAND_MAX;
    k=t;
    t1=1.0*(gn_pair-1)*rand()/RAND_MAX;
    k1=t1;
    if(k1==k&&k>0) k1=k-1;
    if(k1==k&&k==0) k1=1;

                        g_pair2[gn_pair2].Class=0;
                        memcpy(g_pair2[gn_pair2].man,g_pair[k].man,260);
                        memcpy(g_pair2[gn_pair2].man2,g_pair[k1].man,260);
                        g_pair2[gn_pair2].s1=g_pair[k].s1;g_pair2[gn_pair2].s2=g_pair[k1].s1;
                        g_pair2[gn_pair2].id=1;
                        g_pair2[gn_pair2].id2=1;
                        gn_pair2++;
                        if(gn_pair2>=400000) goto lp1;


}
lp1:
for(i=0;i<gn_pair2;i++)
{
c_search_pairs2(i);
}

memcpy(path,"/home/xychen/LFW/peopleDevTrain3.dat",260);

f2=fopen(path,"wb");
s1=sizeof(M_Pair);
k=fwrite(g_pair2,s1,gn_pair2,f2);
fclose(f2);
}


void c_show_pairs(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,ik2,m,m2,m3,mx,my,x2,y2,x3,y3,s1,s2,strat,n1,n2,n3,n4,b2[100],b3[1000];
float t,t1,t2,t3,t4,ax[100],min;
char path[260],buf2[260];
FILE *f2;
U8 *p;
m=0;


/*memcpy(path,"/home/xychen/LFW/fac2.dat",260);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=fread(g_hog,n1,20000,f2);
gn_face=k;
fclose(f2);*/

memcpy(path,"/home/xychen/LFW/peopleDevTrain_2.dat",260);
//if(m1==1) memcpy(path,"/home/xychen/LFW/pairsDevTest.dat",260);
//memcpy(path,"/home/xychen/LFW32_3/err32.dat",260);
f2=fopen(path,"rb");
s1=sizeof(M_Pair);
k=fread(g_pair,s1,20000,f2);
gn_pair=k;
fclose(f2);



c_Show_RectW(1);
i1=0;i2=0;ik2=0;
mx=40;my=40;
for(i=0;i<10;i++)
    {
    k1=i;
    //if(g_pair[i].Class==0)//g_pair[i].f1==1&&
        {
        for(j1=0;j1<72;j1++)
        {
        n2=mx*my*j1;
        for(y2=0;y2<my;y2++)
            {
            for(x2=0;x2<mx;x2++)
                {
                k=(g_hog[k1].v2[y2*mx+x2+n2]);
                m2=i2/13;
                m3=i2-m2*13;
                c_Show_WinP3(x2+m3*mx,y2+m2*my,k);
                }
            }
        i2++;

        }
        i1++;
        }



if(i1%1==0&&i1>0&&ik2<10)
    {
    ik2++;
    sprintf((char *)buf2,"/home/xychen/g2%d.bmp",ik2);
    c_Bitmap_Write3(buf2);
    c_Show_RectW(1);
    i2=0;i1=0;
    }
}

}


void c_Locate_Eye(int m1,Rect rc2,Point *pc)
{
int   xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,j,j1,j2,j3,j4,k,k1,k2,k3,dx2,dy2,ic,f1;
float t,t1,t2,t3,t4,s1;
Rect  rc3,rc4;
Point2  p0,p1,p2,p3;

dx2=0.707*(rc2.x1-rc2.x0)/2;
dy2=0.707*(rc2.y1-rc2.y0)/2;

ic=m1;f1=0;
p0.x=0.5*(rc2.x1+rc2.x0);
p0.y=0.5*(rc2.y1+rc2.y0);
p3=p0;

lp1:
        
        i2=0;p1.x=0;p1.y=0;t1=0;
	for(y=rc2.y0;y<=rc2.y1;y++)
                {
                for(x=rc2.x0;x<=rc2.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_file.pLum[ic][k2]>0)
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;i2++;t1+=t;
                        }
                    }
                }
            
            
            s1=1.0*i2/((rc2.y1-rc2.y0+1)*(rc2.x1-rc2.x0+1));
            if(ic>=2&&s1>0.25&&f1<3) 
            	{
            	ic--; f1++; goto lp1;
            	}
            if(ic>=2&&ic<7&&s1<0.05&&f1<3)
            	{ 
            	ic++; f1++; goto lp1;
            	}
            if(i2>=3)
            	{
                p0.x=p1.x/t1;p0.y=p1.y/t1;
                }

            
            rc3=rc2;

            y2=p0.y-dy2;y3=p0.y+dy2;
            x2=p0.x-dx2;x3=p0.x+dx2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;

            i2=0;p1.x=0;p1.y=0;t1=0;
            for(y=rc3.y0;y<=rc3.y1;y++)
                {
                for(x=rc3.x0;x<=rc3.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_file.pLum[ic][k2]>0)
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;
                        i2++;t1+=t;
                        }
                    }
                }
            if(i2>=3)
            	{
                p0.x=p1.x/t1;p0.y=p1.y/t1;
                }


            y2=p0.y-0.7*dy2;y3=p0.y+0.7*dy2;
            x2=p0.x-0.7*dx2;x3=p0.x+0.7*dx2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;

            i2=0;p1.x=0;p1.y=0;t1=0;
            for(y=rc3.y0;y<=rc3.y1;y++)
                {
                for(x=rc3.x0;x<=rc3.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_file.pLum[ic][k2]>0)
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;
                        i2++;t1+=t;
                        }
                    }
                }
           if(i2>=3)
            	{
                p0.x=p1.x/t1;p0.y=p1.y/t1;
                }
/*rec[0].x0=p0.x-(rc2.x1-rc2.x0)/2;
rec[0].x1=rec[0].x0+(rc2.x1-rc2.x0);
rec[0].y0=p0.y-(rc2.y1-rc2.y0)/2;
rec[0].y1=rec[0].y0+(rc2.y1-rc2.y0)/2;

if(rec[0].x0<0) rec[0].x0=0;if(rec[0].x1>c_file.ImageHeight-1) rec[0].x1=c_file.ImageHeight-1;
if(rec[0].y0<0) rec[0].y0=0;if(rec[0].y1>c_file.ImageWidth-1) rec[0].y1=c_file.ImageWidth-1;
*/
pc[0].x=p0.x-p3.x;pc[0].y=p0.y-p3.y;

}





void c_Eye_Scan(int mk,Point *pc3)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ip,k,k1,k2,k3,h,w2,h2,n1,n2,n3,np,b[20],b2[2],b3[10];
Rect  rc2,rect[100],g_rc2,rc3;
Point2  p0,p1,p2,p3,pc[30],pc2[30];

i=0;
pc[i].x=107;pc[i].y=110;pc2[i].x=35;pc2[i].y=15;i++;

pc[i].x=143;pc[i].y=110;pc2[i].x=35;pc2[i].y=15;i++;

pc[i].x=127;pc[i].y=148;pc2[i].x=25;pc2[i].y=15;i++;

pc[i].x=127;pc[i].y=165;pc2[i].x=35;pc2[i].y=25;i++;

pc[i].x=107;pc[i].y=80;pc2[i].x=35;pc2[i].y=15;i++;

pc[i].x=143;pc[i].y=80;pc2[i].x=35;pc2[i].y=15;i++;

pc[i].x=100;pc[i].y=148;pc2[i].x=35;pc2[i].y=25;i++;

pc[i].x=150;pc[i].y=148;pc2[i].x=35;pc2[i].y=25;i++;

np=i;

for(i=0;i<np;i++)
	{
	rect[i].x0=pc[i].x-pc2[i].x;rect[i].x1=pc[i].x+pc2[i].x;rect[i].y0=pc[i].y-pc2[i].y;rect[i].y1=pc[i].y+pc2[i].y;
	}





i1=0;
b[0]=1;b[1]=5;b[2]=6;
for(ip=0;ip<np;ip++)
	{
    for(i=0;i<2;i++)
		{
        c_Locate_Eye(b[i],rect[ip],&pc3[i1]);i1++;
		}
	}

}


void c_build_train(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,s1,s2,strat,n1,n2,n3,n4,b2[100],b3[1000];
float t,t1,t2,t3,t4,ax[100],min;
char path[260],path2[260];
FILE *f2;
U8 *p;
m=0;


memcpy(path,"/home/xychen/LFW/fac2.dat",260);
n1=sizeof(P_Fac);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=fread(g_hog,n1,20000,f2);
gn_face=k;
fclose(f2);

if(m1==0) memcpy(path,"/home/xychen/LFW/peopleDevTrain.dat",260);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);
n1=sizeof(M_Pair);
k=fread(g_pair,n1,5000,f2);
fclose(f2);
gn_pair=k;
gn_pair2=0;
g_pair2=&g_pair[5000];





j=0;
for(i=0;i<gn_pair;i++)
    {
    for(i1=0;i1<gn_face;i1++)
                {
                s1=g_pair[i].s1;
                t=0;
                for(k=0;k<=s1;k++)
                    {
                    t+=fabs(g_pair[i].man[k]-g_hog[i1].path[k]);
                    }

                if(t==0)
                    {
                    g_pair2[j].n1=i1;
                    g_pair2[j].n2=g_pair[i].n1;
                    g_pair2[j].Class=g_pair[i].Class;j++;                    
                    }
            }
lp1:
    t=0;
    }
gn_pair2=j;



if(m1==0) memcpy(path,"/home/xychen/LFW/peopleDevTrain_2.dat",260);

f2=fopen(path,"wb");
s1=sizeof(M_Pair);
k=fwrite(g_pair2,s1,gn_pair2,f2);
fclose(f2);

}



void c_trans_LFW2(int m1,int m2)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,m,n1,n2,n3,n4,b2[10];
float t,ax[100];
char path[260],path2[260];
FILE *f2;
m=0;
g_pn1=0;g_p5=0;
gn_man=0;gn_face=0;
g_han=9;
for(i=0;i<g_han;i++)
{
gc_EVec2[i].x=cos(PAI/g_han*i);
gc_EVec2[i].y=sin(PAI/g_han*i);
}
for(i=g_han;i<2*g_han;i++)
{
gc_EVec2[i+g_han].x=-gc_EVec2[i].x;
gc_EVec2[i+g_han].y=-gc_EVec2[i].y;
}



memcpy(path,"/home/xychen/LFW/pic/",260);
k=ftw(path,c_file_read2,300);

g_fac[0].nf=gn_man;
g_fac[0].nf2=gn_face;

memcpy(path,"/home/xychen/LFW/fac_hoc.dat",260);
f2=fopen(path,"wb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=fwrite(g_hog,n1,gn_face,f2);
fclose(f2);


}


void  c_Fac_Threshold(P_HOG *pl,Rect rc1,int mx,int my)
{
int i,j,i1,i2,j1,k,k1,k2,k3,ki,m2,m3,m1,x,y,x0,y0,x1,y1,x2,y2,n1,n2,n3,n4,b[20];
float t0,t,t1,t2,t3,t4,tx,ty,tx1[3],ty1[3],v,v1,vt,max,min,cx2[400],cx3[400],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p2,*p,buf[260];

g_mx2=rc1.x1-rc1.x0;
g_my2=rc1.y1-rc1.y0;

v1=0;n1=g_mx2*g_my2;
p2=c_file.pRGB;

n1=g_mx2*g_my2;
ax=c_file.pDis[0];



for(y0=rc1.y0;y0<rc1.y1;y0++)
{
for(x0=rc1.x0;x0<rc1.x1;x0++)
{
v1=0; max=-9999;k3=0;
k1=(y0-rc1.y0)*g_mx2+x0-rc1.x0;
for(ki=0;ki<3;ki++)
{
    k=y0*pl[0].DIBWidth+3*x0+ki;
    pl[0].v2[ki*n1+k1]=p2[k];
}

}
}
return;

for(i1=0;i1<3;i1++)
    {
    n1=i1*g_mx2*g_my2;
    max=-99999;min=99999;
    for(y0=0;y0<g_my2;y0++)
        {
        for(x0=0;x0<g_mx2;x0++)
            {
            k2=y0*g_mx2+x0;
            t=ax[n1+k2];
            if(t>max) max=t;
            if(t<min) min=t;
            }
        }
    vt=max-min;
    cx2[i1]=vt;
    if(vt>0)
        {
        for(y0=0;y0<g_my2;y0++)
            {
            for(x0=0;x0<g_mx2;x0++)
                {
                k2=y0*g_mx2+x0;
                pl[0].v2[n1+k2]=255.0*(ax[k2+n1]-min)/vt;
                }
            }
        }
    else
        {
        memset(&pl[0].v2[n1],0,g_mx2*g_my2);
        }
    }

return;

}




void c_show_mnist(int m1)
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,ik2,m,m2,m3,mx,my,x2,y2,x3,y3,s1,s2,strat,n1,n2,n3,n4,b2[100],b3[1000];
float t,t1,t2,t3,t4,ax[100],min;
char path[260],buf2[260];
FILE *f2;
U8 *p;
m=0;


memcpy(path,"/home/xychen/mnist28_r2/err28.dat",260);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);
n1=sizeof(Play);
k=fread(g_data,n1,20000,f2);
gn_data=k;
fclose(f2);





c_Show_RectW(1);
i1=0;i2=0;ik2=0;
mx=28;my=28;
for(m2=0;m2<10;m2++)
{
i2=0;
for(i=0;i<gn_data;i++)
    {
    k1=g_data[i].v1;
    if(k1==1&&g_data[i].Class==m2)//g_pair[i].f1==1&&
        {
        for(j1=0;j1<1;j1++)
        {
        n2=mx*my*j1;
        for(y2=0;y2<my;y2++)
            {
            for(x2=0;x2<mx;x2++)
                {
                k=(g_data[i].v[y2*mx+x2+n2]);

                m3=i2;
                c_Show_WinP3(x2+m3*mx,y2+m2*my,k);
                }
            }
        i2++;

        }

        }


}

}
sprintf((char *)buf2,"/home/xychen/m2%d.bmp",1);
c_Bitmap_Write3(buf2);


}


void  c_Fac_HOG(P_HOG *pl,Rect rc1,int mx,int my)
{
int i,j,i1,i2,j1,k,k1,k2,k3,ki,m2,m3,x,y,x0,y0,x1,y1,n1,n2,n3,n4,b[20];
float t0,t,t1,t2,t3,t4,tx,ty,tx1[3],ty1[3],v,v1,vt,max,min,cx2[400],cx3[400],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p;
Rect rc2;

g_mx2=rc1.x1-rc1.x0;
g_my2=rc1.y1-rc1.y0;

v1=0;n1=g_mx2*g_my2;
p=c_file.pRGB;
ax=c_file.pDis[0];
bx=&c_file.pDis[3*n1];
ax2=&c_file.pDis[0][6*n1];

gs_L2=2;

n1=g_mx2*g_my2;
for(y0=rc1.y0;y0<rc1.y1;y0++)
{
for(x0=rc1.x0;x0<rc1.x1;x0++)
{
v1=0; max=-9999;k3=0;
k1=(y0-rc1.y0)*g_mx2+x0-rc1.x0;
for(ki=0;ki<3;ki++)
{
    k=y0*pl[0].DIBWidth+3*x0+ki;
    ax[ki*n1+k1]=p[k];
}

}
}


for(i1=0;i1<3;i1++)
    {
    n1=i1*g_mx2*g_my2;
    max=-99999;min=99999;
    for(y0=0;y0<g_my2;y0++)
        {
        for(x0=0;x0<g_mx2;x0++)
            {
            k2=y0*g_mx2+x0;
            t=ax[n1+k2];
            if(t>max) max=t;
            if(t<min) min=t;
            }
        }
    vt=max-min;
    cx2[i1]=vt;
    if(vt>0)
        {
        for(y0=0;y0<g_my2;y0++)
            {
            for(x0=0;x0<g_mx2;x0++)
                {
                k2=y0*g_mx2+x0+n1;
                bx[n1+k2]=255.0*(ax[k2]-min)/vt;
                }
            }
        }
    else
        {
        memset(&bx[n1],0,g_mx2*g_my2);
        }
    }




rx=1.0*(g_mx2-1)/(mx-1);
ry=1.0*(g_my2-1)/(my-1);
for(i1=0;i1<3;i1++)
    {
    n1=i1*g_mx2*g_my2;    
        for(y=0;y<my;y++)
            {
            for(x=0;x<mx;x++)
                {
                tx=rx*x;
                ty=ry*y;
                x0=tx;y0=ty;x1=x0+1;y1=y0+1;
                if(x1>=g_mx2-1) x1=g_mx2-1;
                if(y1>=g_my2-1) y1=g_my2-1;
                t1=tx-x0;t2=ty-y0;
                k=y0*g_mx2+x0+n1; k1=y1*g_mx2+x0+n1; k2=y0*g_mx2+x1+n1; k3=y1*g_mx2+x1+n1;
                t=(1-t1)*(1-t2)*bx[k]+(1-t1)*t2*bx[k1]+t1*(1-t2)*bx[k2]+t1*t2*bx[k3];
                k3=t;                                
                k2=y*mx+x;
                pl[0].v2[n1+k2]=k3;
                }
            }

    }

return;

m2=2;m3=2;
for(ki=0;ki<3;ki++)
{
p=&pl[0].v2[ki*mx*my];
ax=&c_file.pDis[0][ki*g_mx2*g_my2*g_han];
for(y0=0;y0<my;y0++)
    {
    for(x0=0;x0<mx;x0++)
        {
tx=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    if(x<0) x=0;
    if(x>mx-1) x=mx-1;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0;
        if(y>my-1) y=my-1;
        k=y*mx+x;
        tx+=t1*p[k];
        }
    }
ty=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0;
    if(y>my-1) y=my-1;
    k=y*mx;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        if(x<0) x=0;
        if(x>mx-1) x=mx-1;
        k1=k+x;
        ty+=t1*p[k1];
        }
    }
tx=tx/(4*m2*m2);ty=ty/(4*m2*m2);


max=-10;
k=(y0*g_mx2+x0)*g_han;
for(i=0;i<g_han;i++)
    {
    t=fabs(tx*gc_EVec2[i].x+ty*gc_EVec2[i].y);
    cx2[i]=t;
    ax[k+i]=0;
    if(t>max) {max=t;k1=i;}
    }

max=-10;
for(i=0;i<g_han;i++)
    {
    t=fabs(tx*gc_EVec2[i].x+ty*gc_EVec2[i].y);
    cx2[i]=t;
    if(t>max&&i!=k1) {max=t;k2=i;};
    }
ax[k+k1]=cx2[k1];
ax[k+k2]=cx2[k2];
    }
    }
}

rc2.x0=0;rc2.x1=mx;
rc2.y0=0;rc2.y1=my;

gm_start=0;
for(ki=0;ki<1;ki++)
    {
    c_JV_HOG(pl,ki,rc2,1,1);
    c_JV_HOG(pl,ki,rc2,2,2);
    c_JV_HOG(pl,ki,rc2,3,3);
    c_JV_HOG(pl,ki,rc2,4,4);
    c_JV_HOG(pl,ki,rc2,5,5);
    }
pl[0].dim=gm_start;

}

int  c_JV_HOG2(P_HOG *pl,int m1,Rect rc2)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1,dx2,dy2;
float max,s,t,t1,t2,v1,cx[80];
float  *ax;
Point p0;
Rect  rc3;
ax=&c_file.pDis[0][m1*g_mx2*g_my2*g_han];

memset(cx,0,4*g_han);
i1=0;t1=0;max=0;

t2=0;

for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        for(j=0;j<g_han;j++)
            {
            cx[j]+=ax[i1*g_han+j];
            }
        }
    }
for(j=0;j<g_han;j++)
    {
    cx[j]=cx[j]/(g_mx2*g_my2);
    }
s=t2;
i1=0;t1=0;
max=0;t2=0;
gs_L2=1;
for(i=0;i<g_han;i++)
    {
    if(gs_L2==1) t2+=cx[i]*cx[i];
    if(gs_L2==2) t2+=cx[i];
    }
if(gs_L2==1)    t2=sqrt(t2);
i2=gm_start;

for(i=0;i<g_han;i++)
    {
    pl[0].v[i2]=0;
    if(t2>0) pl[0].v[i2]=1.0*cx[i]/(t2+0.00001);
    i2++;
    }
gm_start=i2;
return(1);
}

int  c_JV_HOG(P_HOG *p,int m1,Rect rc1,int mx,int my)
{
int i,j,k,k1,k2,i1,i2,i3,j1,j2,n1,dy2,dx2;
float t,t1,t2,max,max1,cx[100];
Rect  rc2;
Point p0;
dx2=rc1.x1-rc1.x0;dy2=rc1.y1-rc1.y0;
for(j2=0;j2<my;j2++)
{
rc2.y0=rc1.y0+(j2*dy2)/my;rc2.y1=rc1.y0+((j2+1)*dy2)/my;
for(i3=0;i3<mx;i3++)
{
rc2.x0=rc1.x0+(i3*dx2)/mx;rc2.x1=rc1.x0+((i3+1)*dx2)/mx;
c_JV_HOG2(p,m1,rc2);

i1++;
}
}

return(1);
}
int  c_JV_Ka2(P_HOG *pl,int m1,Rect rc2)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1,dx2,dy2;
float t,t1,t2,v1,cx[80],min,max;
float  *ax;
Point p0;
Rect  rc3;
ax=&c_file.pDis[0][m1*g_mx2*g_my2];

memset(cx,0,4*g_han);
i1=0;t1=0;max=0;

t2=0;
max=-99999;min=99999;
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;

        t=ax[i1];
        if(t>max) max=t;
        if(t<min) min=t;
        }
    }
v1=max-min+0.0001;
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        k=1.0*g_han*(ax[i1]-min)/v1;
        cx[k]+=ax[i1];
        }
    }


max=0;t2=0;
gs_L2=2;
for(i=0;i<g_han;i++)
    {
    if(gs_L2==1) t2+=cx[i]*cx[i];
    if(gs_L2==2) t2+=cx[i];
    }
//if(gs_L2==1)
    t2=sqrt(t2);
i2=gm_start;
for(i=0;i<g_han;i++)
    {
    pl[0].v[i2]=0;
    if(t2>0) pl[0].v[i2]=1.0*cx[i]/(t2+0.00001);
    i2++;
    }
gm_start=i2;
return(1);
}
int  c_JV_Ka(P_HOG *p,int m1,Rect rc1,int mx,int my)
{
int i,j,k,k1,k2,i1,i2,i3,j1,j2,n1,dy2,dx2;
float t,t1,t2,max,max1,cx[100];
Rect  rc2;
Point p0;
dx2=rc1.x1-rc1.x0;dy2=rc1.y1-rc1.y0;
for(j2=0;j2<my;j2++)
{
rc2.y0=rc1.y0+(j2*dy2)/my;rc2.y1=rc1.y0+((j2+1)*dy2)/my;
for(i3=0;i3<mx;i3++)
{
rc2.x0=rc1.x0+(i3*dx2)/mx;rc2.x1=rc1.x0+((i3+1)*dx2)/mx;
c_JV_Ka2(p,m1,rc2);

i1++;
}
}

return(1);
}



void  c_Fac_HOG2(P_HOG *pl,Rect rc1,int mx,int my)
{
    int i,j,i1,i2,j1,k,k1,k2,k3,ki,kj,m2,m3,x,y,x0,y0,x1,y1,x2,y2,m1,n1,n2,n3,n4,b[10];
float t0,t,t1,t2,t3,t4,tx,ty,tx1[3],ty1[3],v,v1,vt,max,min,cx2[400],cx3[400],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p;
Rect rc2;
U8 buf[260];

g_mx2=rc1.x1-rc1.x0;
g_my2=rc1.y1-rc1.y0;

v1=0;n1=g_mx2*g_my2;
p=c_file.pRGB;
ax=c_file.pDis[0];bx=c_file.pDis[2];

b[0]=2;b[1]=3;b[2]=5;b[3]=7;b[4]=9;
for(kj=0;kj<1;kj++)
{
n4=kj*g_mx2*g_my2;;
m2=b[kj];m3=m2;
for(y0=rc1.y0;y0<rc1.y1;y0++)
{
for(x0=rc1.x0;x0<rc1.x1;x0++)
{
v1=0; max=-9999;k3=0;
for(ki=0;ki<3;ki++)
{
tx=0;i2=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    if(x<0) x=0;
    if(x>pl[0].w-1) x=pl[0].w-1;
    t1=1;
    if(i<0) {t1=-1;}
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0;
        if(y>pl[0].h-1) y=pl[0].h-1;
        {
        k=y*pl[0].DIBWidth+3*x+ki;
        tx+=t1*p[k];
        }
        }

    }
tx1[ki]=tx;
ty=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0;
    if(y>pl[0].h-1) y=pl[0].h-1;
    t1=1;
    if(i<0) {t1=-1;}
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        if(x<0) x=0;
        if(x>pl[0].w-1) x=pl[0].w-1;

            k=y*pl[0].DIBWidth+3*x+ki;
            ty+=t1*p[k];

        }
    }
ty1[ki]=ty;
t=tx*tx+ty*ty;
if(t>max)
    {
    max=t;k3=ki;
    }
}
k1=(y0-rc1.y0)*g_mx2+x0-rc1.x0;
tx=tx1[k3];
ty=ty1[k3];

max=-10;
k=(k1+n4)*g_han;
for(i=0;i<g_han;i++)
    {
    t=fabs(tx*gc_EVec2[i].x+ty*gc_EVec2[i].y);
    cx2[i]=t;
    ax[k+i]=0;
    if(t>max) {max=t;k1=i;}
    }

max=-10;
for(i=0;i<g_han;i++)
    {
    t=cx2[i];

    if(t>max&&i!=k1) {max=t;k2=i;};
    }
ax[k+k1]=cx2[k1];
ax[k+k2]=cx2[k2];
    }
    }
}




rc2.x0=0;rc2.x1=g_mx2;
rc2.y0=0;rc2.y1=g_my2;

gm_start=0;
for(ki=0;ki<1;ki++)
    {
    c_JV_HOG(pl,ki,rc2,1,1);
    c_JV_HOG(pl,ki,rc2,2,2);
    c_JV_HOG(pl,ki,rc2,3,3);
    c_JV_HOG(pl,ki,rc2,4,4);
    c_JV_HOG(pl,ki,rc2,5,5);
    }
pl[0].dim=gm_start;

c_Show_RectW(1);
i2=0;
for(y2=0;y2<g_my2;y2++)
    {

    for(x2=0;x2<g_mx2;x2++)
        {
        k=(y2+rc1.y0)*pl[0].DIBWidth+3*(x2+rc1.x0);
        k1=(p[k]+p[k+1]+p[k+2])/3;

        m1=i2/16;
        m2=i2-m1*16;
        c_Show_WinP3(x2+m2*51,y2+m1*51,k1);
        }
    }

    for(i=0;i<g_han;i++)
    {

    max=-999;min=9999;
    for(y2=0;y2<g_my2;y2++)
        {

        for(x2=0;x2<g_mx2;x2++)
            {
            k3=y2*g_mx2+x2;
            n4=(k3)*g_han+i;

            t=ax[n4];
            bx[k3]=t;
            if(max<t) max=t;
            if(min>t) min=t;
            }
        }
    vt=max-min;
    i2=i+1;
    for(y2=0;y2<g_my2;y2++)
        {

        for(x2=0;x2<g_mx2;x2++)
            {
            t=255.0*(bx[y2*g_mx2+x2]-min)/vt;
            k=t;
            m1=i2/16;
            m2=i2-m1*16;
            c_Show_WinP3(x2+m2*51,y2+m1*51,k);
            }
        }

    }
    if(g_p5<100)
    {
sprintf((char *)buf,"/home/xychen/lfw_%dHOG.bmp",g_p5);
g_p5++;
c_Bitmap_Write3(buf);
    }
}



void c_Lay_Test()
{
int i,i1,i2,i3,j,j1,j2,j3,k,k1,k2,k3,g1,x,y,x0,y0,x1,y1,x2,y2,w,w1,m1,m2,m3,m4,n1,n2,n3,n4,n5,s,nw,itr,ki,ki2,kj,epoch,e2,rgb,nc,c1[500],b[10],mb2,ne;
float t,t1,t2,t3,t4,ta,ts,tx,ty,tx1,ty1,tc,tc1,tc2,max,min,min2,max2,min3,vt,*ax,*bx,f[10],g_err2[10],dx,dy,cx[6000],cx2[6000];
Point2 r1,r2,cr1,cr2;
FILE *f2;
char path[260];
int  n6,n7;
clock_t start=0,finish=0;
double totaltime=0;
rgb=0;

memcpy(path,"/home/xychen/LFW/fac_rgb.dat",260);
f2=fopen(path,"rb");
n1=sizeof(P_HOG);
k=fread(g_hog,n1,20000,f2);//
gn_data=k;
fclose(f2);

g_han=9;g_p5=0;
for(i=0;i<g_han;i++)
{
gc_EVec2[i].x=cos(PAI/g_han*i);
gc_EVec2[i].y=sin(PAI/g_han*i);
}
for(i=g_han;i<2*g_han;i++)
{
gc_EVec2[i+g_han].x=-gc_EVec2[i].x;
gc_EVec2[i+g_han].y=-gc_EVec2[i].y;
}

g_mx2=50;g_my2=50;






memcpy(path,"/home/xychen/LFW/pairsDevTest.dat",260);
f2=fopen(path,"rb");
n1=sizeof(M_Pair);
g_pair2=&g_pair[10000];
k=fread(g_pair2,n1,10000,f2);//
gn_pair2=k;
fclose(f2);


max=-9999;min=9999;

n3=g_mx2*g_my2;g_radio=4;
    for(itr=0;itr<gn_pair2;itr++)
        {
            i1=itr;
            j1=g_pair2[i1].n1;
            j2=g_pair2[i1].n2;

            /*k1=itr;
            for(y2=0;y2<g_my2;y2++)
                {

                for(x2=0;x2<g_mx2;x2++)
                    {
                    k=(g_hog[j1].v2[y2*g_mx2+x2]+g_hog[j1].v2[y2*g_mx2+x2+n3]+g_hog[j1].v2[y2*g_mx2+x2+2*n3])/3;
                    m1=0;
                    m2=k1;
                    c_Show_WinP3(x2+0+m2*52,y2+0+m1*52,k);
                    }
                }
            for(y2=0;y2<g_my2;y2++)
                {

                for(x2=0;x2<g_mx2;x2++)
                    {
                    k=(g_hog[j2].v2[y2*g_mx2+x2]+g_hog[j2].v2[y2*g_mx2+x2+n3]+g_hog[j2].v2[y2*g_mx2+x2+2*n3])/3;
                    m1=1;
                    m2=k1;
                    c_Show_WinP3(x2+0+m2*52,y2+0+m1*52,k);
                    }
                }*/

            c_Mnist_POEM(&g_hog[j1]);
            c_Mnist_POEM(&g_hog[j2]);

            //c_Mnist_LBP(3,&g_hog[j1]);
            //c_Mnist_LBP(3,&g_hog[j2]);

            //c_Mnist_Hoc(&g_hog[j1]);//c_Mnist_LBP(3,&g_hog[j1]);
            //c_Mnist_Hoc(&g_hog[j2]);//c_Mnist_LBP(3,&g_hog[j2]);
            t=0;
            t2=0;

            n1=g_hog[j1].dim;
                for(j=0;j<n1;j++)
                    {
                    t1=(g_hog[j1].v[j]-g_hog[j2].v[j]);///(ax[j]-bx[j]+0.00001);
                    t+=t1*t1;
                    t2+=fabs(t1);
                    }
                //t=sqrt(t);
                //t2=t;

                g_pair2[i1].u[0]=t;
                g_pair2[i1].u[1]=t2;

                if(max<t2) max=t2;
                if(min>t2) min=t2;
                if(max2<t) max2=t;
                if(min2>t) min2=t;
        }


vt=max-min;
min3=9999;
for(j1=0;j1<1000;j1++)
{
t2=min+1.0*j1/1000*vt;


g_err2[0]=0;
for(i1=0;i1<gn_pair2;i1++)
        {
        t1=g_pair2[i1].u[1];
        if(g_pair2[i1].Class==1&&t1>t2) {g_err2[0]+=1;}
        if(g_pair2[i1].Class==0&&t1<=t2) {g_err2[0]+=1;}
        }
cx2[j1]=g_err2[0];
if(g_err2[0]<min3) min3=g_err2[0];
}
b[0]=min3;

vt=max2-min2;
min3=9999;
for(j1=0;j1<1000;j1++)
{
t2=min2+1.0*j1/1000*vt;


g_err2[0]=0;
for(i1=0;i1<gn_pair2;i1++)
        {
        t1=g_pair2[i1].u[0];
        if(g_pair2[i1].Class==1&&t1>t2) {g_err2[0]+=1;}
        if(g_pair2[i1].Class==0&&t1<=t2) {g_err2[0]+=1;}
        }
cx2[j1]=g_err2[0];
if(g_err2[0]<min3) min3=g_err2[0];
}
b[1]=min3;b[2]=g_radio;b[3]=gn_data;b[4]=g_han;


fprint2("LFW 50x50 Ka,1_1,2","tmnist.txt",0,g_err2,5,b);
//c_Bitmap_Write3("/home/xychen/12ac.bmp");
}


void  c_Fac_LBP(P_HOG *pl,Rect rc1,int mx,int my)
{
    int i,j,i1,i2,j1,k,k1,k2,k3,ki,kj,m2,m3,m1,x,y,x0,y0,x1,y1,x2,y2,n,n1,n2,n3,n4,b[10],u[40];
float t0,t,t1,t2,t3,t4,tx,ty,tx1[3],ty1[3],v,v1,v2,vt,max,min,cx2[400],cx3[400],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p;
Rect rc2;
U8 buf[260];

g_mx2=rc1.x1-rc1.x0;
g_my2=rc1.y1-rc1.y0;


v1=0;
p=c_file.pRGB;
ax=c_file.pDis[0];bx=c_file.pDis[1];
/*for(y0=rc1.y0;y0<rc1.y1;y0++)
{
for(x0=rc1.x0;x0<rc1.x1;x0++)
{
    for(ki=0;ki<3;ki++)
            {
        n4=ki*g_mx2*g_my2;;
        v=p[y0*pl[0].DIBWidth+3*x0+ki];
    k2=(y0-rc1.y0)*g_mx2+x0-rc1.x0;
    k=k2+n4;

    pl[0].v[k]=v;
    }
}
}
pl[0].dim=3*g_mx2*g_my2;
return;*/

b[0]=4;b[1]=2;b[2]=3;b[3]=4;b[4]=5;


for(kj=0;kj<1;kj++)
{
g_han2=2;
g_radio=b[kj];
c_init_LBP();

v2=1;
for(y0=rc1.y0;y0<rc1.y1;y0++)
{
for(x0=rc1.x0;x0<rc1.x1;x0++)
{
v1=0; max=-9999;k3=0;
for(ki=0;ki<3;ki++)
        {
        n4=(kj*3+ki)*g_mx2*g_my2;;
        v=p[y0*pl[0].DIBWidth+3*x0+ki];n=0;
        for(i=0;i<gn_dlbp;i++)
        {
        v1=0;
        for(j=0;j<4;j++)
            {
            x=g_dlbp[i].p[j].x+x0;y=g_dlbp[i].p[j].y+y0;
            if(x<0) x=0; if(y<0) y=0;
            if(x>=pl[0].w-1) x=pl[0].w-1; if(y>=pl[0].h-1) y=pl[0].h-1;
            v1+=g_dlbp[i].u[j]*p[y*pl[0].DIBWidth+3*x+ki];
            }
        u[i]=0;
        if(v1>=v+v2) u[i]=1;
        n+=u[i];
        }

    u[gn_dlbp]=u[0];k=0;k1=0;
    n3=0;n2=1;
    for(i=0;i<gn_dlbp;i++)
        {
        if(u[i]!=u[i+1]) k++;
        if(u[i]==1&&k1==0) k1=i;
        n3=n3+u[i]*n2;
        n2=2*n2;
        }

    if(k>2) k3=0;
    if(k==0&&n==gn_dlbp) k3=1;
    if(k==0&&n==0) k3=2;
    if(k==2) k3=c_lbp[(n-1)*20+k1];
    k2=(y0-rc1.y0)*g_mx2+x0-rc1.x0;
    k=k2+n4;
    ax[k]=k3;
    ax[k+g_mx2*g_my2]=n3;
    }
}
}
}

rc2.x0=0;rc2.x1=g_mx2;
rc2.y0=0;rc2.y1=g_my2;

gm_start=0;
for(ki=0;ki<3;ki++)
    {
    c_JV_LBP(pl,ki,rc2,1,1);
    c_JV_LBP(pl,ki,rc2,2,2);
    c_JV_LBP(pl,ki,rc2,3,3);
    c_JV_LBP(pl,ki,rc2,4,4);
    c_JV_LBP(pl,ki,rc2,5,5);
    }
pl[0].dim=gm_start;

c_Show_RectW(1);
i2=0;
for(y2=0;y2<g_my2;y2++)
    {

    for(x2=0;x2<g_mx2;x2++)
        {
        k=(y2+rc1.y0)*pl[0].DIBWidth+3*(x2+rc1.x0);
        k1=(p[k]+p[k+1]+p[k+2])/3;

        m1=i2/16;
        m2=i2-m1*16;
        c_Show_WinP3(x2+m2*51,y2+m1*51,k1);
        }
    }

    for(i=0;i<2;i++)
    {

    max=-999;min=9999;
    for(y2=0;y2<g_my2;y2++)
        {

        for(x2=0;x2<g_mx2;x2++)
            {
            k3=y2*g_mx2+x2;
            n4=(k3)+i*g_mx2*g_my2;

            t=ax[n4];
            bx[k3]=t;
            if(max<t) max=t;
            if(min>t) min=t;
            }
        }
    vt=max-min;
    i2=i+1;
    for(y2=0;y2<g_my2;y2++)
        {

        for(x2=0;x2<g_mx2;x2++)
            {
            t=255.0*(bx[y2*g_mx2+x2]-min)/vt;
            k=t;
            m1=i2/16;
            m2=i2-m1*16;
            c_Show_WinP3(x2+m2*51,y2+m1*51,k);
            }
        }
    }

    if(g_p5<100)
    {
sprintf((char *)buf,"/home/xychen/lfw_%dLBP.bmp",g_p5);
g_p5++;
c_Bitmap_Write3(buf);
    }
}


int  c_JV_LBP2(P_HOG *pl,int m1,Rect rc2)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1,dx2,dy2;
float max,s,t,t1,t2,v1,cx[100];
float  *ax;
Point p0;
Rect  rc3;
ax=&c_file.pDis[0][m1*g_mx2*g_my2];

memset(cx,0,4*100);
i1=0;t1=0;max=0;

t2=0;
i2=0;
for(x=rc2.x0;x<rc2.x1;x++)
    {
    for(y=rc2.y0;y<rc2.y1;y++)
        {
        i1=y*g_mx2+x;
        k=ax[i1];

        cx[k]++;

        }
    }

s=t2;
i1=0;t1=0;
max=0;t2=0;
gs_L2=2;
for(i=0;i<59;i++)
    {
    if(gs_L2==1) t2+=cx[i]*cx[i];
    if(gs_L2==2) t2+=cx[i];
    }

t2=sqrt(t2);

i2=gm_start;

for(i=0;i<59;i++)
    {
    pl[0].v[i2]=0;
    if(t2>0) pl[0].v[i2]=1.0*cx[i]/(t2+0.001);    

    i2++;
    }
gm_start=i2;
return(1);
}

int  c_JV_LBP(P_HOG *p,int m1,Rect rc1,int mx,int my)
{
int i,j,k,k1,k2,i1,i2,i3,j1,j2,n1,dy2,dx2;
float t,t1,t2,max,max1,cx[100];
Rect  rc2;
Point p0;
dx2=rc1.x1-rc1.x0;dy2=rc1.y1-rc1.y0;
for(j2=0;j2<my;j2++)
{
rc2.y0=rc1.y0+(j2*dy2)/my;rc2.y1=rc1.y0+((j2+1)*dy2)/my;
for(i3=0;i3<mx;i3++)
{
rc2.x0=rc1.x0+(i3*dx2)/mx;rc2.x1=rc1.x0+((i3+1)*dx2)/mx;
c_JV_LBP2(p,m1,rc2);

i1++;
}
}

return(1);
}




void  c_Fac_Hoc(P_HOG *pl,Rect rc1,int mx,int my)
{
int i,j,i1,i2,j1,kj,k,k1,k2,k3,ki,m2,m3,x,y,x0,y0,x1,y1,x2,y2,m1,n1,n2,n3,n4;
float t0,t,t1,t2,t3,t4,tr,tx,ty,tx2,ty2,tx1[3],ty1[3],v,v1,vt,max,min,cx2[400],cx3[400],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p;
Rect rc2;
U8   buf[260];

g_mx2=rc1.x1-rc1.x0;
g_my2=rc1.y1-rc1.y0;

v1=0;n1=g_mx2*g_my2;
p=c_file.pRGB;
ax=c_file.pDis[0];
bx=&c_file.pDis[0][n1];ax2=&c_file.pDis[1][0];

m2=2;m3=m2;
for(kj=0;kj<1;kj++)
{
g_han2=2;
g_radio=2;
c_init_LBP();

for(y0=rc1.y0;y0<rc1.y1;y0++)
{
for(x0=rc1.x0;x0<rc1.x1;x0++)
{
v1=0; max=-9999;k3=0;
for(ki=0;ki<3;ki++)
{
tx=0;i2=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    if(x<0) x=0;
    if(x>pl[0].w-1) x=pl[0].w-1;
    t1=1;
    if(i<0) {t1=-1;}
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0;
        if(y>pl[0].h-1) y=pl[0].h-1;
        {
        k=y*pl[0].DIBWidth+3*x+ki;
        tx+=t1*p[k];
        }
        }
    }

tx1[ki]=tx;
ty=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0;
    if(y>pl[0].h-1) y=pl[0].h-1;
    t1=1;
    if(i<0) {t1=-1;}
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        if(x<0) x=0;
        if(x>pl[0].w-1) x=pl[0].w-1;

            k=y*pl[0].DIBWidth+3*x+ki;
            ty+=t1*p[k];

        }
    }
ty1[ki]=ty;
t=tx*tx+ty*ty;
if(t>max)
    {
    max=t;k3=ki;
    }
}
k1=(y0-rc1.y0)*g_mx2+x0-rc1.x0;
ax[k1]=tx1[k3];
bx[k1]=ty1[k3];
//ax2[k1]=sqrt(max);
}
}


for(y0=0;y0<g_my2;y0++)
    {
    for(x0=0;x0<g_mx2;x0++)
        {
        t1=ax[y0*g_mx2+x0];t2=bx[y0*g_mx2+x0];
        tr=sqrt(t1*t1+t2*t2)+0.00001;

        for(i1=0;i1<gn_dlbp;i1++)
            {
            t3=0;t4=0;
            k3=y0*g_mx2+x0;
            n4=kj*g_mx2*g_my2*gn_dlbp*g_han+(k3*gn_dlbp+i1)*g_han;
            for(j=0;j<4;j++)
                {
                x=g_dlbp[i1].p[j].x+x0;y=g_dlbp[i1].p[j].y+y0;
                if(x<0) x=0; if(y<0) y=0;
                if(x>=g_mx2-1) x=g_mx2-1; if(y>=g_my2-1) y=g_my2-1;
                t3+=g_dlbp[i1].u[j]*ax[y*g_mx2+x];
                t4+=g_dlbp[i1].u[j]*bx[y*g_mx2+x];
                }
            tx=t3-t1;ty=t4-t2;
            /*tx2=tx*t1/tr+ty*t2/tr;
            ty2=ty*t1/tr-tx*t2/tr;
            tx=tx2;ty=ty2;*/

            for(i=0;i<g_han;i++)
                    {
                    t=fabs(tx*gc_EVec2[i].x+ty*gc_EVec2[i].y);
                    cx2[i]=t;
                    ax2[n4+i]=0;
                    }
            max=-10;

            for(i=0;i<g_han;i++)
                {
                t=cx2[i];
                if(t>max) {max=t;k1=i;}
                }

            max=-10;
            for(i=0;i<g_han;i++)
                {
                t=cx2[i];
                if(t>max&&i!=k1) {max=t;k2=i;};
                }
            ax2[n4+k1]=cx2[k1];
            ax2[n4+k2]=cx2[k2];

            }
        }
    }
}
rc2.x0=0;rc2.x1=g_mx2;
rc2.y0=0;rc2.y1=g_my2;
gm_start=0;
for(ki=0;ki<1;ki++)
    {
    c_JV_HOC(pl,ki,rc2,1,1);
    c_JV_HOC(pl,ki,rc2,2,2);
    c_JV_HOC(pl,ki,rc2,3,3);
    c_JV_HOC(pl,ki,rc2,4,4);
    c_JV_HOC(pl,ki,rc2,5,5);
    }
pl[0].dim=gm_start;

c_Show_RectW(1);
i2=0;
for(y2=0;y2<g_my2;y2++)
    {

    for(x2=0;x2<g_mx2;x2++)
        {
        k=(y2+rc1.y0)*pl[0].DIBWidth+3*(x2+rc1.x0);
        k1=(p[k]+p[k+1]+p[k+2])/3;

        m1=i2/16;
        m2=i2-m1*16;
        c_Show_WinP3(x2+m2*51,y2+m1*51,k1);
        }
    }
    for(i1=0;i1<gn_dlbp;i1++)
    {
    for(i=0;i<g_han;i++)
    {

    max=-999;min=9999;
    for(y2=0;y2<g_my2;y2++)
        {

        for(x2=0;x2<g_mx2;x2++)
            {
            k3=y2*g_mx2+x2;
            n4=(k3*gn_dlbp+i1)*g_han+i;

            t=ax2[n4];
            bx[k3]=t;
            if(max<t) max=t;
            if(min>t) min=t;
            }
        }
    vt=max-min;
    i2=i1*g_han+i+1;
    for(y2=0;y2<g_my2;y2++)
        {

        for(x2=0;x2<g_mx2;x2++)
            {
            t=255.0*(bx[y2*g_mx2+x2]-min)/vt;
            k=t;
            m1=i2/15;
            m2=i2-m1*15;
            c_Show_WinP3(x2+m2*51,y2+m1*51,k);
            }
        }

    }
    }
    if(g_p5<100)
    {
sprintf((char *)buf,"/home/xychen/lfw_%dhoc.bmp",g_p5);
g_p5++;
c_Bitmap_Write3(buf);
    }

}

int  c_JV_HOC2(P_HOG *pl,int m1,Rect rc2)
{
int x,y,x0,y0,x1,y1,i,j,k,k1,k2,i1,i2,i3,j1,dx2,dy2;
float max,s,t,t1,t2,v1,cx[800];
float  *ax;
Point p0;
Rect  rc3;
ax=&c_file.pDis[1][m1*g_mx2*g_my2*g_han*gn_dlbp];

memset(cx,0,4*g_han*gn_dlbp);
i1=0;t1=0;max=0;

t2=0;
for(y=rc2.y0;y<rc2.y1;y++)
    {
    for(x=rc2.x0;x<rc2.x1;x++)
        {
        i1=y*g_mx2+x;
        for(j=0;j<g_han*gn_dlbp;j++)
            {
            cx[j]+=ax[i1*g_han*gn_dlbp+j];
            }
        }
    }
for(j=0;j<g_han*gn_dlbp;j++)
    {
    cx[j]=cx[j]/(g_mx2*g_my2);
    }
s=t2;
i1=0;t1=0;
max=0;t2=0;
gs_L2=1;
for(i=0;i<g_han*gn_dlbp;i++)
    {
    if(gs_L2==1) t2+=cx[i]*cx[i];
    if(gs_L2==2) t2+=cx[i];
    }
if(gs_L2==1) t2=sqrt(t2);
i2=gm_start;
for(i=0;i<g_han*gn_dlbp;i++)
    {
    if(t2>0) pl[0].v[i2]=1.0*cx[i]/(t2+0.0001);
    else pl[0].v[i2]=0;
    i2++;
    }
gm_start=i2;
return(1);
}
int  c_JV_HOC(P_HOG *p,int m1,Rect rc1,int mx,int my)
{
int i,j,k,k1,k2,i1,i2,i3,j1,j2,n1,dy2,dx2;
float t,t1,t2,max,max1,cx[100];
Rect  rc2;
Point p0;
dx2=rc1.x1-rc1.x0;dy2=rc1.y1-rc1.y0;
for(j2=0;j2<my;j2++)
{
rc2.y0=rc1.y0+(j2*dy2)/my;rc2.y1=rc1.y0+((j2+1)*dy2)/my;
for(i3=0;i3<mx;i3++)
{
rc2.x0=rc1.x0+(i3*dx2)/mx;rc2.x1=rc1.x0+((i3+1)*dx2)/mx;
c_JV_HOC2(p,m1,rc2);

i1++;
}
}

return(1);
}


void c_test_Mnist()
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,k3,k4,m,m2,m3,x2,y2,n1,n2,n3,n4,b[10];
float t,*ax,*bx,*cx,max,min,min2,t1,t2;
char path[260],buf2[260];
FILE *f2;
m=0;
g_pn1=0;
gn_man=0;gn_face=0;
g_han=9;g_p5=-1;
for(i=0;i<g_han;i++)
{
gc_EVec2[i].x=cos(PAI/g_han*i);
gc_EVec2[i].y=sin(PAI/g_han*i);
}
for(i=g_han;i<2*g_han;i++)
{
gc_EVec2[i+g_han].x=-gc_EVec2[i].x;
gc_EVec2[i+g_han].y=-gc_EVec2[i].y;
}

memcpy(path,"/home/xychen/mnist/trainf_28.dat",200);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(P_HOG);


k=fread(&g_hog[0],n1,70000,f2);
gn_data=k;
fclose(f2);

memcpy(path,"/home/xychen/mnist/testf_28.dat",200);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(P_HOG);

k=fread(&g_hog[gn_data],n1,20000,f2);
gn_data2=k;
fclose(f2);
g_mx2=28;g_my2=28;

g_radio=2;
for(i=0;i<gn_data+gn_data2;i++)
    {
    gm_start=0;
    c_Mnist_HOG(&g_hog[i]);
    c_Mnist_LBP(0,&g_hog[i]);
    }

fprint2("Mnist ,start","tmnist.txt",0,ax,4,b);

n1=g_hog[0].dim;
ax=c_file.pDis[0];
bx=c_file.pDis[1];cx=c_file.pDis[2];
for(j=0;j<n1;j++)
{
    ax[j]=-999;bx[j]=99999;
}
for(i=0;i<gn_data;i++)
{
    for(j=0;j<n1;j++)
    {
     t=g_hog[i].v[j];
     if(t>ax[j]) ax[j]=t;
     if(t<bx[j]) bx[j]=t;
    }

}
for(j=0;j<n1;j++)
{
    cx[j]=(ax[j]-bx[j]+0.00001);
}

n1=g_hog[0].dim;
k3=0;k4=0;
for(i=0;i<gn_data2;i++)
    {
    min=9999999;min2=99999;
    i1=i+gn_data;
    i2=g_hog[i1].Class;


    for(j=0;j<gn_data;j++)
    {

        t=0;
        t2=0;
            for(j1=0;j1<n1;j1++)
                {
                t1=(g_hog[i1].v[j1]-g_hog[j].v[j1])/cx[j1];//need cx
                t+=t1*t1;
                t2+=fabs(t1);
                }            
            //t2=t;
            if(min>t) {min=t;k1=g_hog[j].Class;}
            if(min2>t2) {min2=t2;k2=g_hog[j].Class;}
    }
    if(k1!=i2) k3++;
    if(k2!=i2) k4++;
    }

b[0]=k4;b[1]=k3;b[2]=g_radio;b[3]=g_han;b[4]=gn_data2;
fprint2("Mnist HOG+Lbp=3_____1,2","tmnist.txt",0,ax,5,b);

}



void c_RP_Mnist()
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,k3,k4,m,m2,m3,x2,y2,n1,n2,n3,n4,b[10];
float t,*ax,*bx,*cx,max,min,min2,t1,t2;
char path[260],buf2[260];
float ax2[500];

FILE *f2;
m=0;
g_pn1=0;
gn_man=0;gn_face=0;
g_han=3;g_p5=-1;
for(i=0;i<g_han;i++)
{
gc_EVec2[i].x=cos(PAI/g_han*i);
gc_EVec2[i].y=sin(PAI/g_han*i);
}
for(i=g_han;i<2*g_han;i++)
{
gc_EVec2[i+g_han].x=-gc_EVec2[i].x;
gc_EVec2[i+g_han].y=-gc_EVec2[i].y;
}

memcpy(path,"/home/xychen/mnist/trainf_28.dat",200);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(P_HOG);


k=fread(&g_hog[0],n1,70000,f2);
gn_data=k;
fclose(f2);

memcpy(path,"/home/xychen/mnist/testf_28.dat",200);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(P_HOG);

k=fread(&g_hog[gn_data],n1,20000,f2);
gn_data2=k;
fclose(f2);

for(i=0;i<gn_data+gn_data2;i++)
    {
    gm_start=0;
    c_Mnist_LBP(0,&g_hog[i]);
    }

b[0]=g_han;b[1]=g_radio;b[2]=gn_data;b[3]=gn_data2;
fprint2("Mnist LBP,start,g_han,radio","tmnist.txt",0,ax,4,b);

n1=g_hog[0].dim;
ax=c_file.pDis[0];
for(i1=0;i1<495;i1++)
{
    t1=0;
    for(j=0;j<n1;j++)
        {
        ax[i1*n1+j]=1.0*rand()/RAND_MAX;
        t1+=ax[i1*n1+j]*ax[i1*n1+j];
        }
    t1=sqrt(t1);
    for(j=0;j<n1;j++)
        {
        ax[i1*n1+j]=ax[i1*n1+j]/t1;
        }
}

for(i=0;i<gn_data+gn_data2;i++)
    {
    for(i1=0;i1<495;i1++)
    {
        t1=0;
        for(j=0;j<n1;j++)
            {
            t1+=ax[i1*n1+j]*g_hog[i].v[j];
            }
        ax2[i1]=t1;
    }
    memcpy(g_hog[i].v,ax2,4*495);
    g_hog[i].dim=495;
    }



n1=g_hog[0].dim;
ax=c_file.pDis[0];
bx=c_file.pDis[1];cx=c_file.pDis[2];
for(j=0;j<n1;j++)
{
    ax[j]=-999;bx[j]=99999;
}
for(i=0;i<gn_data;i++)
{
    for(j=0;j<n1;j++)
    {
     t=g_hog[i].v[j];
     if(t>ax[j]) ax[j]=t;
     if(t<bx[j]) bx[j]=t;
    }

}
for(j=0;j<n1;j++)
{
    cx[j]=(ax[j]-bx[j]+0.00001);
}

n1=g_hog[0].dim;
k3=0;k4=0;
for(i=0;i<gn_data2;i++)
    {
    min=9999999;min2=99999;
    i1=i+gn_data;
    i2=g_hog[i1].Class;
    for(j=0;j<gn_data;j++)
    {

        t=0;
        t2=0;
            for(j1=0;j1<n1;j1++)
                {
                t1=(g_hog[i1].v[j1]-g_hog[j].v[j1])/cx[j1];
                t+=t1*t1;
                t2+=fabs(t1);
                }
            //t2=t;
            if(min>t) {min=t;k1=g_hog[j].Class;}
            if(min2>t2) {min2=t2;k2=g_hog[j].Class;}
    }
    if(k1!=i2) k3++;
    if(k2!=i2) k4++;
    }

b[0]=k4;b[1]=k3;b[2]=gn_data;b[3]=gn_data2;
fprint2("Mnist Rdom, LBP,r=1_____1,2","tmnist.txt",0,ax,4,b);

}



void c_MP_Mnist()
{
int   i,i1,i2,i3,i4,j,j1,j2,j3,k,k1,k2,k3,k4,m,m2,m3,x2,y2,n1,n2,n3,n4,b[10],epoch;
float t,*ax,*bx,*cx,max,min,min2,t1,t2,rate;
char path[260],buf2[260];
float ax2[500];

FILE *f2;
m=0;
g_pn1=0;
gn_man=0;gn_face=0;
g_han=3;g_p5=-1;
for(i=0;i<g_han;i++)
{
gc_EVec2[i].x=cos(PAI/g_han*i);
gc_EVec2[i].y=sin(PAI/g_han*i);
}
for(i=g_han;i<2*g_han;i++)
{
gc_EVec2[i+g_han].x=-gc_EVec2[i].x;
gc_EVec2[i+g_han].y=-gc_EVec2[i].y;
}

memcpy(path,"/home/xychen/mnist/trainf_28.dat",200);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(P_HOG);
k=fread(&g_hog[0],n1,70000,f2);
gn_data=k;
fclose(f2);

memcpy(path,"/home/xychen/mnist/testf_28.dat",200);
f2=fopen(path,"rb");
fseek(f2,0,SEEK_SET);

n1=sizeof(P_HOG);

k=fread(&g_hog[gn_data],n1,20000,f2);
gn_data2=k;
fclose(f2);

for(i=0;i<gn_data+gn_data2;i++)
    {
    gm_start=0;
    c_Mnist_LBP(0,&g_hog[i]);
    }

memcpy(path,"/home/xychen/mnist/trainf_28.dat",200);
f2=fopen(path,"wb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=fwrite(&g_hog[0],n1,gn_data,f2);
fclose(f2);


b[0]=g_han;b[1]=g_radio;b[2]=gn_data;b[3]=gn_data2;
fprint2("Mnist LBP,start,g_han,radio","tmnist.txt",0,ax,4,b);

n1=g_hog[0].dim;

for(i1=0;i1<495;i1++)
{
    t1=0;
    ax=&c_file.pDis[0][i1*n1];
    for(j=0;j<n1;j++)
        {
        ax[j]=0.05*(1.0*rand()/RAND_MAX-0.5);
        }
    if(i1>0)
        {
        for(k=0;k<=i1-1;k++)
        {
        t1=0;
        bx=&c_file.pDis[0][k*n1];
        for(j=0;j<n1;j++)
            {
            t1+=bx[j]*ax[j];
            }
        for(j=0;j<n1;j++)
            {
            ax[j]=ax[j]-t1*bx[j];
            }
        }
        }


    rate=0.001;
    for(epoch=0;epoch<1;epoch++)
        {


        for(i=0;i<gn_data;i++)
            {
            t1=0;
            for(j=0;j<n1;j++)
                {
                t1+=ax[j]*ax[j];
                }
            t1=sqrt(t1);
            for(j=0;j<n1;j++)
                {
                ax[j]=ax[j]/(t1+0.00001);
                }
            t1=0;
            for(j=0;j<n1;j++)
                {
                t1+=ax[j]*g_hog[i].v[j];
                }

                for(j=0;j<n1;j++)
                {
                    ax[j]-=rate*(g_hog[i].v[j]-ax[j]*t1)*t1;
                }

             }
         }
    if(i1>0)
        {
        for(k=0;k<=i1-1;k++)
        {
        t1=0;
        bx=&c_file.pDis[0][k*n1];
        for(j=0;j<n1;j++)
            {
            t1+=bx[j]*ax[j];
            }
        for(j=0;j<n1;j++)
            {
            ax[j]=ax[j]-t1*bx[j];
            }
        }
        }

    t1=0;
    for(j=0;j<n1;j++)
        {
        t1+=ax[j]*ax[j];
        }
    t1=sqrt(t1);
    for(j=0;j<n1;j++)
        {
        ax[j]=ax[j]/(t1+0.00001);
        }

    for(i=0;i<gn_data;i++)
        {
        t=0;
        for(j=0;j<n1;j++)
            {
            t1+=ax[j]*g_hog[i].v[j];
            }
        for(j=0;j<n1;j++)
            {
            g_hog[i].v[j]=g_hog[i].v[j]-t1*ax[j];
            }

        }

}

    memcpy(path,"/home/xychen/mnist/trainf_28.dat",200);
    f2=fopen(path,"rb");
    fseek(f2,0,SEEK_SET);

    n1=sizeof(P_HOG);
    k=fread(&g_hog[0],n1,70000,f2);
    gn_data=k;
    fclose(f2);

for(i=0;i<gn_data+gn_data2;i++)
    {
    for(i1=0;i1<495;i1++)
    {
        t1=0;
        ax=&c_file.pDis[0][i1*n1];
        for(j=0;j<n1;j++)
            {
            t1+=ax[j]*g_hog[i].v[j];
            }
        ax2[i1]=t1;
    }
    memcpy(g_hog[i].v,ax2,4*495);
    g_hog[i].dim=495;
    }


fprint2("Mnist LBP,start22,g_han,radio","tmnist.txt",0,ax,4,b);
n1=g_hog[0].dim;
ax=c_file.pDis[0];
bx=c_file.pDis[1];cx=c_file.pDis[2];
for(j=0;j<n1;j++)
{
    ax[j]=-999;bx[j]=99999;
}
for(i=0;i<gn_data;i++)
{
    for(j=0;j<n1;j++)
    {
     t=g_hog[i].v[j];
     if(t>ax[j]) ax[j]=t;
     if(t<bx[j]) bx[j]=t;
    }

}
for(j=0;j<n1;j++)
{
    cx[j]=(ax[j]-bx[j]+0.00001);
}

n1=g_hog[0].dim;
k3=0;k4=0;
for(i=0;i<gn_data2;i++)
    {
    min=9999999;min2=99999;
    i1=i+gn_data;
    i2=g_hog[i1].Class;
    for(j=0;j<gn_data;j++)
    {

        t=0;
        t2=0;
            for(j1=0;j1<n1;j1++)
                {
                t1=(g_hog[i1].v[j1]-g_hog[j].v[j1])/cx[j1];
                t+=t1*t1;
                t2+=fabs(t1);
                }
            //t2=t;
            if(min>t) {min=t;k1=g_hog[j].Class;}
            if(min2>t2) {min2=t2;k2=g_hog[j].Class;}
    }
    if(k1!=i2) k3++;
    if(k2!=i2) k4++;
    }

b[0]=k4;b[1]=k3;b[2]=gn_data;b[3]=gn_data2;
fprint2("Mnist MP, LBP,r=1_____1,2","tmnist.txt",0,ax,4,b);

}


void  c_Mnist_HOG(P_HOG *pl)
{
int i,j,i1,i2,j1,k,k1,k2,k3,ki,ki1,m2,m3,x,y,x0,y0,x1,y1,n1,n2,n3,n4,b[20],mx,my;
float t0,t,t1,t2,t3,t4,tx,ty,tx1,ty1,v,v1,vt,max,min,cx2[400],cx3[400],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p;
Rect rc2;


mx=g_mx2;my=g_my2;
v1=0;n1=g_mx2*g_my2;
p=pl[0].v2;
ax=c_file.pDis[0];
bx=&c_file.pDis[3*n1];
ax2=&c_file.pDis[0][6*n1];

gs_L2=1;

n1=g_mx2*g_my2;

m2=2;m3=m2;



for(y0=0;y0<my;y0++)
    {
    for(x0=0;x0<mx;x0++)
        {

    max=-9999;
        for(ki1=0;ki1<1;ki1++)
        {
tx=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    if(x<0) x=0;
    if(x>mx-1) x=mx-1;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0;
        if(y>my-1) y=my-1;
        k=y*mx+x;
        tx+=t1*p[k+ki1*n1];
        }
    }
ty=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0;
    if(y>my-1) y=my-1;
    k=y*mx;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        if(x<0) x=0;
        if(x>mx-1) x=mx-1;
        k1=k+x;
        ty+=t1*p[k1+ki1*n1];
        }
    }
tx=tx/(4*m2*m2);ty=ty/(4*m2*m2);
t1=tx*tx+ty*ty;
if(t1>max)
{
 tx1=tx;ty1=ty;   max=t1;
}
       }


max=-10;
k=(y0*g_mx2+x0)*g_han;
for(i=0;i<g_han;i++)
    {
    t=fabs(tx1*gc_EVec2[i].x+ty1*gc_EVec2[i].y);
    cx2[i]=t;
    ax[k+i]=0;
    if(t>max) {max=t;k1=i;}
    }

max=-10;
for(i=0;i<g_han;i++)
    {
    t=fabs(tx1*gc_EVec2[i].x+ty1*gc_EVec2[i].y);
    cx2[i]=t;
    if(t>max&&i!=k1) {max=t;k2=i;};
    }
ax[k+k1]=cx2[k1];
ax[k+k2]=cx2[k2];
    }
    }


rc2.x0=0;rc2.x1=mx;
rc2.y0=0;rc2.y1=my;

gm_start=0;
for(ki=0;ki<1;ki++)
    {
    c_JV_HOG(pl,ki,rc2,1,1);
    c_JV_HOG(pl,ki,rc2,2,2);
    c_JV_HOG(pl,ki,rc2,3,3);
    c_JV_HOG(pl,ki,rc2,4,4);
    c_JV_HOG(pl,ki,rc2,5,5);
    }
pl[0].dim=gm_start;

}



void  c_Mnist_LBP(int m1,P_HOG *pl)
{
int i,j,i1,i2,j1,k,k1,k2,k3,ki,kj,m2,m3,mx,my,x,y,x0,y0,x1,y1,x2,y2,n,n1,n2,n3,n4,b[10],u[40];
float t0,t,t1,t2,t3,t4,tx,ty,tx1[3],ty1[3],v,v1,v2,vt,max,min,cx2[400],cx3[400],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p,buf[260];
Rect rc2;


mx=g_mx2;my=g_mx2;
pl[0].w=g_mx2;pl[0].h=g_my2;
v1=0;n1=mx*my;
p=pl[0].v2;




if(m1>0) p=&c_file.pLum[5][m1*g_my2*g_my2];
ax=c_file.pDis[0];



for(kj=0;kj<1;kj++)
{
g_han2=2;

c_init_LBP();

v2=2;
for(y0=0;y0<g_my2;y0++)
{
for(x0=0;x0<g_mx2;x0++)
{
v1=0; max=-9999;k3=0;

        n4=kj*g_mx2*g_my2;
        v=p[y0*g_mx2+x0];n=0;
        for(i=0;i<gn_dlbp;i++)
        {
        v1=0;
        for(j=0;j<4;j++)
            {
            x=g_dlbp[i].p[j].x+x0;y=g_dlbp[i].p[j].y+y0;
            if(x<0) x=0; if(y<0) y=0;
            if(x>=g_mx2-1) x=g_mx2-1; if(y>=g_my2-1) y=g_my2-1;
            v1+=g_dlbp[i].u[j]*p[y*g_mx2+x];
            }
        u[i]=0;
        if(v1>=v+v2) u[i]=1;
        n+=u[i];
        }
    u[gn_dlbp]=u[0];k=0;k1=0;
    for(i=0;i<gn_dlbp;i++)
        {
        if(u[i]!=u[i+1]) k++;
        if(u[i]==1&&k1==0) k1=i;
        }

    if(k>2) k3=0;
    if(k==0&&n==gn_dlbp) k3=1;
    if(k==0&&n==0) k3=2;
    if(k==2) k3=c_lbp[(n-1)*20+k1];
    k2=y0*g_mx2+x0;
    k=k2+n4;
    ax[k]=k3;
}
}
}





rc2.x0=0;rc2.x1=g_mx2;
rc2.y0=0;rc2.y1=g_my2;
//gm_start=0;

for(ki=0;ki<1;ki++)
    {
    c_JV_LBP(pl,ki,rc2,1,1);
    c_JV_LBP(pl,ki,rc2,2,2);
    c_JV_LBP(pl,ki,rc2,3,3);
    c_JV_LBP(pl,ki,rc2,4,4);
    c_JV_LBP(pl,ki,rc2,5,5);
    }
pl[0].dim=gm_start;


}



void  c_Mnist_POEM(P_HOG *pl)
{
int i,j,i1,i2,j1,k,k1,k2,k3,ki,m2,m3,x,y,x0,y0,x1,y1,n1,n2,n3,n4,b[20],mx,my;
float t0,t,t1,t2,t3,t4,tx,ty,tx1,ty1,v,v1,vt,max,min,cx2[400],cx3[400],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p;
Rect rc2;


mx=g_mx2;my=g_my2;
v1=0;n1=g_mx2*g_my2;
p=pl[0].v2;
ax=c_file.pDis[0];
bx=&c_file.pDis[0][3*n1];
ax2=&c_file.pDis[0][6*n1];


gs_L2=1;

n1=g_mx2*g_my2;

m2=2;m3=m2;

for(y0=0;y0<my;y0++)
    {
    for(x0=0;x0<mx;x0++)
        {
        max=-9999;
        for(ki=0;ki<1;ki++)
        {
tx=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    if(x<0) x=0;
    if(x>mx-1) x=mx-1;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0;
        if(y>my-1) y=my-1;
        k=y*mx+x;
        tx+=t1*p[k+ki*n1];
        }
    }
ty=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0;
    if(y>my-1) y=my-1;
    k=y*mx;
    i1=i+1;t1=1;
    if(i<0) {t1=-1;i1=-i;}
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        if(x<0) x=0;
        if(x>mx-1) x=mx-1;
        k1=k+x;
        ty+=t1*p[k1+ki*n1];
        }
    }
tx=tx/(4*m2*m2);ty=ty/(4*m2*m2);
t1=tx*tx+ty*ty;
if(max<t1)
{
tx1=tx;ty1=ty;max=t1;
}
  }


max=-10;
k=(y0*g_mx2+x0)*g_han;
for(i=0;i<g_han;i++)
    {
    t=fabs(tx1*gc_EVec2[i].x+ty1*gc_EVec2[i].y);
    cx2[i]=t;
    ax[k+i]=0;
    if(t>max) {max=t;k1=i;}
    }

max=-10;
for(i=0;i<g_han;i++)
    {
    t=fabs(tx1*gc_EVec2[i].x+ty1*gc_EVec2[i].y);
    cx2[i]=t;
    if(t>max&&i!=k1) {max=t;k2=i;};
    }
ax[k+k1]=cx2[k1];
ax[k+k2]=cx2[k2];
    }
    }


m2=0;
for(i1=0;i1<g_han;i1++)
{

for(y0=0;y0<my;y0++)
    {
    for(x0=0;x0<mx;x0++)
        {
        tx=0;
        for(i=-m2;i<=m2;i++)
            {
            x=i+x0;
            if(x<0) x=0;
            if(x>mx-1) x=mx-1;

            for(j=-m2;j<=m2;j++)
                {
                y=j+y0;
                if(y<0) y=0;
                if(y>my-1) y=my-1;
                k=y*mx+x;
                tx+=ax[k*g_han+i1];
                }
            }
        k=(y0*g_mx2+x0)*g_han+i1;
        bx[k]=tx;
        }
    }
}
rc2.x0=0;rc2.x1=mx;
rc2.y0=0;rc2.y1=my;

for(i1=0;i1<g_han;i1++)
{

max=0;min=99999;
for(y0=0;y0<my;y0++)
    {
    for(x0=0;x0<mx;x0++)
        {
    k=(y0*g_mx2+x0)*g_han;
    if(bx[k+i1]>max) max=bx[k+i1];
    if(bx[k+i1]<min) min=bx[k+i1];
        }
    }
v1=max-min+0.0001;
for(y0=0;y0<my;y0++)
    {
    for(x0=0;x0<mx;x0++)
        {
        k=(y0*g_mx2+x0)*g_han+i1;
        k1=i1*g_mx2*g_my2+y0*g_mx2+x0;
        c_file.pLum[5][k1+g_mx2*g_my2]=255.0*(bx[k]-min)/v1;
        }
    }
}

gm_start=0;

c_Mnist_LBP(1,pl);
c_Mnist_LBP(2,pl);
c_Mnist_LBP(3,pl);
c_Mnist_LBP(5,pl);
c_Mnist_LBP(6,pl);
c_Mnist_LBP(7,pl);
c_Mnist_LBP(8,pl);
c_Mnist_LBP(9,pl);
for(y0=0;y0<g_my2;y0++)
{
for(x0=0;x0<g_mx2;x0++)
{
    k=y0*g_mx2+x0;
    t=1.0*(pl[0].v2[k]+pl[0].v2[k+n1]+pl[0].v2[k+2*n1])/3;
    c_file.pLum[5][10*g_my2*g_my2+k]=t;
}
}
c_Mnist_LBP(10,pl);


pl[0].dim=gm_start;

}




void  c_Mnist_Ka(P_HOG *pl)
{
int i,j,i1,i2,j1,k,k1,k2,k3,ki,m2,m3,x,y,x0,y0,x1,y1,n1,n2,n3,n4,b[20],b1[20],c1[20],mx,my;
float t0,t,t1,t2,t3,t4,tx,ty,tx1,ty1,v,v1,vt,max,min,cx2[400],cx3[400],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry,Ix[2],Ixx[2],Ixy[2];
U8 *p;
Rect rc2;


mx=g_mx2;my=g_my2;
v1=0;n1=g_mx2*g_my2;
p=pl[0].v2;
ax=c_file.pDis[0];


i=0;
c1[i+0]=-1;c1[i+1]=-1;c1[i+2]=1;c1[i+3]=1;
b1[i+0]=1;b1[i+1]=1;b1[i+2]=1;b1[i+3]=1;

i=4;
c1[i+0]=-1;c1[i+1]=1;c1[i+2]=1;c1[i+3]=-1;
b1[i+0]=1;b1[i+1]=1;b1[i+2]=1;b1[i+3]=1;



i=8;
c1[i+0]=-1;c1[i+1]=-1;c1[i+2]=1;c1[i+3]=1;
b1[i+0]=-1;b1[i+1]=-1;b1[i+2]=1;b1[i+3]=1;



gs_L2=1;

n1=g_mx2*g_my2;

m2=2;m3=m2;

for(y0=0;y0<my;y0++)
    {
    for(x0=0;x0<mx;x0++)
        {
        max=-9999;
        for(ki=0;ki<1;ki++)
        {
tx=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    if(x<0) x=0;
    if(x>mx-1) x=mx-1;

    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0;
        if(y>my-1) y=my-1;
        k=y*mx+x;
        tx+=1.000*c1[i+2]*b1[j+2]*p[k+ki*n1];
        }
    }
ty=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0;
    if(y>my-1) y=my-1;
    k=y*mx;
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        if(x<0) x=0;
        if(x>mx-1) x=mx-1;
        k1=k+x;
        ty+=1.000*c1[i+2]*b1[j+2]*p[k1+ki*n1];
        }
    }
Ix[0]=tx/16;Ix[1]=ty/16;
tx=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    if(x<0) x=0;
    if(x>mx-1) x=mx-1;

    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0;
        if(y>my-1) y=my-1;
        k=y*mx+x;
        tx+=1.000*c1[i+6]*b1[j+6]*p[k+ki*n1];
        }
    }
ty=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0;
    if(y>my-1) y=my-1;
    k=y*mx;
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        if(x<0) x=0;
        if(x>mx-1) x=mx-1;
        k1=k+x;
        ty+=1.000*c1[i+6]*b1[j+6]*p[k1+ki*n1];
        }
    }
Ixx[0]=tx/16;Ixx[1]=ty/16;

tx=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    if(x<0) x=0;
    if(x>mx-1) x=mx-1;

    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0;
        if(y>my-1) y=my-1;
        k=y*mx+x;
        tx+=1.000*c1[i+10]*b1[j+10]*p[k+ki*n1];
        }
    }
ty=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0;
    if(y>my-1) y=my-1;
    k=y*mx;
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        if(x<0) x=0;
        if(x>mx-1) x=mx-1;
        k1=k+x;
        ty+=1.000*c1[i+10]*b1[j+10]*p[k1+ki*n1];
        }
    }
Ixy[0]=tx/16;Ixy[1]=ty/16;

t=Ix[0]*Ix[0]+Ix[1]*Ix[1];
t2=sqrt(t);
t2=t*t2;

t1=(Ix[1]*Ix[1]*Ixx[0]-2.0*Ix[0]*Ixy[0]*Ix[1]+Ix[0]*Ix[0]*Ixx[1])/(t2+0.1);
v1=fabs(t1);
if(max<v1) max=v1;
/*if(Ix[0]!=0&&x0>2&&y0>2)
{
t=0;
}
if(v1>0)
{
t=0;
}*/
 }


k=(y0*g_mx2+x0);
ax[k]=max;

    }
    }




gm_start=0;



rc2.x0=0;rc2.x1=g_mx2;
rc2.y0=0;rc2.y1=g_my2;
//gm_start=0;

for(ki=0;ki<1;ki++)
    {
    c_JV_Ka(pl,ki,rc2,1,1);
    c_JV_Ka(pl,ki,rc2,2,2);
    c_JV_Ka(pl,ki,rc2,3,3);
    c_JV_Ka(pl,ki,rc2,4,4);
    c_JV_Ka(pl,ki,rc2,5,5);
    }
pl[0].dim=gm_start;



}


void  c_Mnist_Hoc(P_HOG *pl)
{
int i,j,i1,i2,j1,kj,k,k1,k2,k3,ki,m1,m2,m3,x,y,x0,y0,x1,y1,x2,y2,n1,n2,n3,n4,mx,my;
float t0,t,t1,t2,t3,t4,tr,tx,ty,tx2,ty2,tx1[3],ty1[3],v,v1,vt,max,min,cx2[400],cx3[400],vx,vy,dx,dy,*h,*ax,*ax2,*bx,*bx2,rx,ry;
U8 *p;
Rect rc2;
U8 buf[260];


mx=g_mx2;my=g_mx2;
pl[0].w=g_mx2;pl[0].h=g_my2;
v1=0;n1=g_mx2*g_my2;
p=pl[0].v2;
ax=c_file.pDis[0];
bx=&c_file.pDis[0][n1];ax2=&c_file.pDis[1][0];



g_p5=k;
m2=2;m3=m2;
for(kj=0;kj<1;kj++)
{
g_han2=2;

c_init_LBP();

for(y0=0;y0<g_my2;y0++)
{
for(x0=0;x0<g_mx2;x0++)
{
v1=0; max=-9999;

for(ki=0;ki<1;ki++)
{
tx=0;i2=0;
for(i=-m2;i<m2;i++)
    {
    x=i+x0;
    if(x<0) x=0;
    if(x>pl[0].w-1) x=pl[0].w-1;
    t1=1;
    if(i<0) {t1=-1;}
    for(j=-m3;j<m3;j++)
        {
        y=j+y0;
        if(y<0) y=0;
        if(y>pl[0].h-1) y=pl[0].h-1;
        {
        k=y*pl[0].w+x;
        tx+=t1*p[k+ki*n1];
        }
        }

    }

ty=0;
for(i=-m2;i<m2;i++)
    {
    y=i+y0;
    if(y<0) y=0;
    if(y>pl[0].h-1) y=pl[0].h-1;
    t1=1;
    if(i<0) {t1=-1;}
    for(j=-m3;j<m3;j++)
        {
        x=j+x0;
        if(x<0) x=0;
        if(x>pl[0].w-1) x=pl[0].w-1;

            k=y*pl[0].w+x;
            ty+=t1*p[k+ki*n1];

        }
    }
t=tx*tx+ty*ty;

if(t>max)
    {
    max=t;tx2=tx;ty2=ty;
    }
}

k1=y0*g_mx2+x0;
ax[k1]=tx2;
bx[k1]=ty2;
//ax2[k1]=sqrt(max);
}
}


for(y0=0;y0<g_my2;y0++)
    {
    for(x0=0;x0<g_mx2;x0++)
        {
        t1=ax[y0*g_mx2+x0];t2=bx[y0*g_mx2+x0];
        for(i1=0;i1<gn_dlbp;i1++)
            {
            t3=0;t4=0;
            k3=y0*g_mx2+x0;
            n4=kj*g_mx2*g_my2*gn_dlbp*g_han+(k3*gn_dlbp+i1)*g_han;
            for(j=0;j<4;j++)
                {
                x=g_dlbp[i1].p[j].x+x0;y=g_dlbp[i1].p[j].y+y0;
                if(x<0) x=0; if(y<0) y=0;
                if(x>=g_mx2-1) x=g_mx2-1; if(y>=g_my2-1) y=g_my2-1;
                t3+=g_dlbp[i1].u[j]*ax[y*g_mx2+x];
                t4+=g_dlbp[i1].u[j]*bx[y*g_mx2+x];
                }
            tx=t3-t1;ty=t4-t2;
            for(i=0;i<g_han;i++)
                    {
                    t=fabs(tx*gc_EVec2[i].x+ty*gc_EVec2[i].y);
                    cx2[i]=t;
                    ax2[n4+i]=0;
                    }
            max=-10;

            for(i=0;i<g_han;i++)
                {
                t=cx2[i];
                if(t>max) {max=t;k1=i;}
                }

            max=-10;
            for(i=0;i<g_han;i++)
                {
                t=cx2[i];
                if(t>max&&i!=k1) {max=t;k2=i;};
                }
            ax2[n4+k1]=cx2[k1];
            ax2[n4+k2]=cx2[k2];

            }
        }
    }
}


rc2.x0=0;rc2.x1=g_mx2;
rc2.y0=0;rc2.y1=g_my2;
gm_start=0;
for(ki=0;ki<1;ki++)
    {
    c_JV_HOC(pl,ki,rc2,1,1);
    c_JV_HOC(pl,ki,rc2,2,2);
    c_JV_HOC(pl,ki,rc2,3,3);
    c_JV_HOC(pl,ki,rc2,4,4);
    c_JV_HOC(pl,ki,rc2,5,5);
    }
pl[0].dim=gm_start;







}



void c_Object_Scan3(int mk,int white)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,k3,h,w2,h2,n1,n2,n3,nw,nc,w,w3,m3,b[2],b2[2],b3[10],m,md,m1,f1,ic2,gn_k;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;
int   g_ix,g_iy,gn_w,gn_h,c1,c2,ic,iw,ws[5];
Point2  p0,p1,p2,p3,pc[15];
Point  plum[10];
P_HOG   *pl;
TWIST  tw[20];

g_C1[gs_database].x=gn_C1;
g_C3[gs_database].x=gn_C3;

if(white==1)
{ws[0]=17;ws[1]=23;ws[2]=30;ws[3]=30;nw=3;b3[0]=2;b3[1]=6;}
if(white==0)
{ws[0]=17;ws[1]=25;nw=2;b3[0]=1;b3[1]=2;}
ma=0.3;ma2=1.0;m=0;
c_Mode_Zdot(3);md=1;
rec.x0=0;rec.x1=c_image.Width;rec.y0=0;rec.y1=c_image.Height;
gn_srec=0;gp_data=0;
gn_play=0;gn_play2=0;gn_play3=0;

n1=0;gn_play=0;gn_pz=0;

for(iw=0;iw<nw;iw++)
{
w=ws[iw];
h=w;
gc_w2=w*0.707;
n2=w*w;h2=h/2;w2=w/2;
gn_w=1.0*(rec.x1-rec.x0-1)/w2+0.35;gn_h=1.0*(rec.y1-rec.y0-1)/h2+0.35;
gn_srec2=0;
gn_k=gn_pz;
for(ic2=b3[0];ic2<b3[1];ic2++)
{
ic=ic2;
{ma=0.05;ma2=0.35;}
g_iy=0;g_ix=0;i3=0;i4=0;
    for(g_iy=0;g_iy<gn_h;g_iy++)
        {
        rc2.y0=g_iy*h2;rc2.y1=rc2.y0+h;if(rc2.y1>rec.y1-1) rc2.y1=rec.y1-1;

        for(g_ix=0;g_ix<gn_w;g_ix++)
            {
            rc2.x0=g_ix*w2;rc2.x1=rc2.x0+w;if(rc2.x1>rec.x1-1) rc2.x1=rec.x1-1;
            p0.x=0.5*(rc2.x0+rc2.x1);p0.y=0.5*(rc2.y0+rc2.y1);
            i2=0;
            p1.x=0;p1.y=0;t1=0;t2=0;

            b2[0]=100;
            for(y=rc2.y0;y<=rc2.y1;y++)
                {
                for(x=rc2.x0;x<=rc2.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;i2++;t1+=t;
                        }
                    }
                }
            p0.x=p1.x/t1;p0.y=p1.y/t1;
            s1=1.0*i2/((rc2.y1-rc2.y0+1)*(rc2.x1-rc2.x0+1));
            if(s1>ma2) goto lp3;
            if(s1<ma) goto lp3;


            y2=p0.y-gc_w2;y3=p0.y+gc_w2;
            x2=p0.x-gc_w2;x3=p0.x+gc_w2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;

            i2=0;b2[0]=1;p1.x=0;p1.y=0;t1=0;
            for(y=rc3.y0;y<=rc3.y1;y++)
                {
                for(x=rc3.x0;x<=rc3.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_file.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;
                        i2++;t1+=t;
                        }
                    }
                }
            p0.x=p1.x/t1;p0.y=p1.y/t1;
            y2=p0.y-gc_w2;y3=p0.y+gc_w2;
            x2=p0.x-gc_w2;x3=p0.x+gc_w2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;

            i2=0;p1.x=0;p1.y=0;t1=0;
            for(y=rc3.y0;y<=rc3.y1;y++)
                {
                for(x=rc3.x0;x<=rc3.x1;x++)
                    {
                    k2=c_image.Y_Base[y]+x;
                    if(c_file.pLum[ic][k2]>=b2[0])
                        {
                        i2++;
                        }
                    }
                }
             g_pz[gn_pz].x=p0.x;g_pz[gn_pz].y=p0.y;
             g_pz[gn_pz].r=rc3;
             g_pz[gn_pz].y=p0.y;g_pz[gn_pz].s=1.0*i2/((rc3.y1-rc3.y0+1)*(rc3.x1-rc3.x0+1));
             g_pz[gn_pz].p0=p0;
             g_pz[gn_pz].ic=ic;
             g_pz[gn_pz].w=w;
             gn_pz++;

            n1++;
lp3:
            t=0;
            }
        }
}


m3=10;

        for(i=gn_k;i<gn_pz;i++)
            {
            if(g_pz[i].s>0)
                {
                for(j=i+1;j<gn_pz;j++)
                    {
                    if(g_pz[j].s>0)
                        {
                        t=c_Get_Dist3(g_pz[i],g_pz[j]);
                        if(t<m3)
                            {
                            if(g_pz[i].s>=g_pz[j].s)
                                {
                                g_pz[j].s=0;
                                }
                           else if(g_pz[i].s<g_pz[j].s)
                                {
                                g_pz[i].s=0; goto lp4;
                                }
                            }
                        }
                    }
                }
        lp4:
            t=0;
            }

}
        i2=0;g_len2[0]=gc_w2;g_len2[1]=gc_w2;
        g_len3[0]=2.0*gc_w2;g_len3[1]=2.0*gc_w2;
        g_len4[0]=1.35*gc_w2;g_len4[1]=1.35*gc_w2;




        for(i=0;i<gn_pz;i++)
            {

            if(g_pz[i].s>0)
                {
                k=c_JS_Dir(g_pz[i].ic,g_pz[i].w,g_pz[i].r,&g_pz[i]);
                c_JPoint3(g_pz[i].w,0.5,&g_pz[i]);

                pl=&g_hog[gn_play];pl->pc[0]=g_pz[i].p0;pl->pc[1]=g_pz[i].p1;pl->Clas[0]=g_pz[i].i;pl->Clas[1]=gs_database; pl->ds=g_pz[i].ds;
                pl->dir[0]=g_pz[i].mi;pl->w=g_pz[i].w;

                if(g_pz[i].ds>0.5&&g_pz[i].ds<1.0) goto lps;
                gn_C3++;

                               if(mk==1)
                               {
                                if(g_pz[i].ds<=0.5)
                                        {
                                        pl->Class=1;
                                        gn_C1++;
                                        }
                                 else
                                        {
                                        pl->Class=-1;
                                        gn_C2++;
                                        }
                               }
                               if(mk==3)
                               {
                                if(g_pz[i].ds<=0.5)
                                        {
                                        pl->Class=1;
                                        gn_C1++;
                                        }
                                 else
                                        {
                                        pl->Class=-1;
                                        gn_C2++;
                                        }
                               }



                memcpy(pl->path,gm_file->input_filename,260);
                j1=0;

                g_len3[0]=g_pz[i].w*0.707;
                g_len3[1]=g_pz[i].w*0.707;
                //if(g_pz[i].ic==1)  g_len3[1]=g_pz[i].w*0.707;
                if(g_pz[i].ic>=2) c_Get_Image1(0,0,g_pz[i].p0,g_pz[i].mi,g_len3,pl);j1++;
                if(g_pz[i].ic==1) c_Get_Image1(9,0,g_pz[i].p0,g_pz[i].mi,g_len3,pl);j1++;

                if(g_pz[i].ic>=2)
                    {
                    c_Get_Image1(4,1,g_pz[i].p0,g_pz[i].mi,g_len3,pl);j1++;
                    c_Get_Image1(3,2,g_pz[i].p0,g_pz[i].mi,g_len3,pl);j1++;
                    c_Get_Image1(2,3,g_pz[i].p0,g_pz[i].mi,g_len3,pl);j1++;
                    }
                if(g_pz[i].ic==1)
                    {
                    c_Get_Image1(6,1,g_pz[i].p0,g_pz[i].mi,g_len3,pl);j1++;
                    c_Get_Image1(7,2,g_pz[i].p0,g_pz[i].mi,g_len3,pl);j1++;
                    c_Get_Image1(8,3,g_pz[i].p0,g_pz[i].mi,g_len3,pl);j1++;
                    }

                //c_Get_Image1(1,2,g_pz[i].p0,g_pz[i].mi,g_len3,pl);j1++;

                gn_play++;

lps:

                t=0;i2++;
                }

            }

    gn_Lk=i2;


    g_C1[gs_database].y=gn_C1;
    g_C3[gs_database].y=gn_C3;



}




void c_Object_Scan4(int mk,int white)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,k3,h,w2,h2,n1,n2,n3,nw,nc,w,w3,m3,b[2],b2[2],b3[10],m,md,m1,f1,ic2,gn_k;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;
int   g_ix,g_iy,gn_w,gn_h,c1,c2,ic,iw,ws[5];
Point2  p0,p1,p2,p3,pc[15];
Point  plum[10];
P_HOG   *pl;
TWIST  tw[20];
FILE *f2;
U8 buf[260];

g_C1[gs_database].x=gn_C1;
g_C3[gs_database].x=gn_C3;

if(white==1)
{ws[0]=17;ws[1]=23;ws[2]=30;ws[3]=30;nw=3;b3[0]=2;b3[1]=6;}
if(white==0)
{ws[0]=17;ws[1]=25;nw=2;b3[0]=1;b3[1]=2;}
ma=0.3;ma2=1.0;m=0;
c_Mode_Zdot(3);md=1;
rec.x0=0;rec.x1=c_image.Width;rec.y0=0;rec.y1=c_image.Height;
gn_srec=0;gp_data=0;
gn_play=0;gn_play2=0;gn_play3=0;

n1=0;gn_play=0;gn_pz=0;

//for(iw=0;iw<nw;iw++)
{
w=20;
h=w;
gc_w2=w*0.707;
n2=w*w;h2=2;w2=2;
gn_w=1.0*(rec.x1-rec.x0-10)/w2+0.35;gn_h=1.0*(rec.y1-rec.y0-10)/h2+0.35;
gn_srec2=0;
gn_k=gn_pz;
//for(ic2=b3[0];ic2<b3[1];ic2++)
{
ic=4;
{ma=0.05;ma2=0.35;}
g_iy=0;g_ix=0;i3=0;i4=0;
    for(g_iy=0;g_iy<gn_h;g_iy++)
        {
        rc2.y0=g_iy*h2;rc2.y1=rc2.y0+h;if(rc2.y1>rec.y1-1) rc2.y1=rec.y1-1;

        for(g_ix=0;g_ix<gn_w;g_ix++)
            {
            rc2.x0=g_ix*w2;rc2.x1=rc2.x0+w;if(rc2.x1>rec.x1-1) rc2.x1=rec.x1-1;
            p0.x=0.5*(rc2.x0+rc2.x1);p0.y=0.5*(rc2.y0+rc2.y1);
            y2=p0.y-gc_w2;y3=p0.y+gc_w2;
            x2=p0.x-gc_w2;x3=p0.x+gc_w2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;

                k=c_JS_Dir(3,20,rc3,&g_pz[0]);
                //c_JPoint3(g_pz[i].w,0.5,&g_pz[i]);

                pl=&g_hog[gn_play];pl->pc[0]=p0;
                pl->dir[0]=g_pz[0].mi;pl->w=w;





                memcpy(pl->path,gm_file->input_filename,260);
                j1=0;

                g_len3[0]=w*0.707;
                g_len3[1]=w*0.707;
                //if(g_pz[i].ic==1)  g_len3[1]=g_pz[i].w*0.707;
                c_Get_Image1(0,0,p0,g_pz[0].mi,g_len3,pl);j1++;



                gn_play++;



                t=0;i2++;
                }

            }


}
}


f2=fopen("Aircraft_Test48_5.dat","wb");
fseek(f2,0,SEEK_SET);
n1=sizeof(P_HOG);
k=fwrite(&g_hog[0],n1,gn_play,f2);
fclose(f2);


}



void c_Mitosis_Scan(int mk)
{
int   nk,ki,ki2,xc,yc,x,y,x2,y2,x3,y3,i,i1,i2,i3,i4,ia,ib,j,j1,j2,j3,k,k1,k2,h,w2,h2,n1,n2,n3,w,m3,b[2],b2[2],b3[10],m,md,f1,ic2,gn_k;
float s1,s2,s3,l,l2,t,t1,t2,t3,t4,tx,ty,tx2,max,max1,max2,ma,ma2,ms[6],v[10],v2[10],cx[100];
Rect  rc2,rec,g_rc2,rc3;
int   g_ix,g_iy,gn_w,gn_h,c1,c2,ic,iw,ws[5];
Point2  p0,p1,p2,p3,pc[5];
Point  plum[10];
Play   *pl;
ARect  ar[10];

g_C1[gs_database].x=gn_C1;
g_C3[gs_database].x=gn_C3;

ws[0]=20.0;
ma=0.05;ma2=1.0;m=0;
md=1;
rec.x0=0;rec.x1=c_image.Width;rec.y0=0;rec.y1=c_image.Height;
gn_srec=0;gp_data=0;
gn_play=0;gn_play2=0;gn_play3=0;

n1=0;gn_play=0;gn_pz=0;
n1=0;gn_play=0;gn_pz=0;
b3[0]=1;b3[1]=7;b3[2]=8;
for(iw=0;iw<1;iw++)
//iw=0;
{
//w=gm_sf.w[iw];
w=ws[iw];
h=w;
gc_w2=w*1.5;
n2=w*w;
h2=h/2.0;w2=w/2.0;
gn_w=1.0*(rec.x1-rec.x0-1)/w2+0.35;gn_h=1.0*(rec.y1-rec.y0-1)/h2+0.35;
gn_srec2=0;
gn_k=gn_pz;
ki=0;
for(ic2=2;ic2<=4;ic2++)
{
ic=ic2;
//ic=gm_sf.clum[0];
//{ma=gm_sf.r[0];ma2=gm_sf.r[1];}
{ma=0.05;ma2=1.8;}
g_iy=0;g_ix=0;i3=0;i4=0;
    for(g_iy=0;g_iy<gn_h;g_iy++)
      //for(ki==0;ki<2;ki++)
        {
        rc2.y0=g_iy*h2;
        //if(ki==0) rc2.y0=500-h2;
        //if(ki==1) rc2.y0=610-h2;
        //if(ki==2) rc2.y0=380-h2;
        rc2.y1=rc2.y0+h;if(rc2.y1>rec.y1-1) rc2.y1=rec.y1-1;

        for(g_ix=0;g_ix<gn_w;g_ix++)
            {
            rc2.x0=g_ix*w2;
            //if(ki==0) rc2.x0=730-w2;
            //if(ki==1) rc2.x0=740-w2;
            //if(ki==2) rc2.x0=909-w2;
            rc2.x1=rc2.x0+w;if(rc2.x1>rec.x1-1) rc2.x1=rec.x1-1;
            //rc2.x0=0;rc2.x1=100;rc2.y0=0;rc2.y1=100;
            //c_Show_Rect(rc2);
            p0.x=0.5*(rc2.x0+rc2.x1);p0.y=0.5*(rc2.y0+rc2.y1);
            i2=0;
            p1.x=0;p1.y=0;t1=0;t2=0;

            b2[0]=1;

            for(y=rc2.y0;y<=rc2.y1;y++)
                {
                for(x=rc2.x0;x<=rc2.x1;x++)
                    {
                    k2=Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;i2++;t1+=t;
                        }
                    }
                }

            p0.x=p1.x/(t1+0.0001);p0.y=p1.y/(t1+0.0001);
            s1=1.0*i2/((rc2.y1-rc2.y0+1)*(rc2.x1-rc2.x0+1));

            if(s1>ma2||s1<ma)
                {
                goto lp3;
                }



            y2=p0.y-w/2;y3=p0.y+w/2;
            x2=p0.x-w/2;x3=p0.x+w/2;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;
            //c_Show_Rect(rc3);
            y2=p0.y-w/2;y3=p0.y+w/2;
            x2=p0.x-w/2;x3=p0.x+w/2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;
            //c_Show_Rect(rc3);

            i2=0;p1.x=0;p1.y=0;t1=0;
            for(y=rc3.y0;y<=rc3.y1;y++)
                {
                for(x=rc3.x0;x<=rc3.x1;x++)
                    {
                    k2=Y_Base[y]+x;
                    if(c_mode.pLum[ic][k2]>=b2[0])
                        {
                        t=c_file.pLum[ic][k2];
                        p1.x+=t*x;p1.y+=t*y;
                        i2++;t1+=t;
                        }
                    }
                }
            p0.x=p1.x/(t1+0.0001);;p0.y=p1.y/(t1+0.0001);
            y2=p0.y-gc_w2;y3=p0.y+gc_w2;
            x2=p0.x-gc_w2;x3=p0.x+gc_w2;
            if(y2<0) y2=0;if(y3>c_file.ImageHeight-1) y3=c_file.ImageHeight-1;
            if(x2<0) x2=0;if(x3>c_file.ImageWidth-1) x3=c_file.ImageWidth-1;
            rc3.x0=x2;rc3.x1=x3;rc3.y0=y2;rc3.y1=y3;
            //c_Show_Rect(rc3);


             g_pz[gn_pz].x=p0.x;g_pz[gn_pz].y=p0.y;
             g_pz[gn_pz].r=rc3;
             g_pz[gn_pz].y=p0.y;g_pz[gn_pz].s=1.0*i2/((rc3.y1-rc3.y0+1)*(rc3.x1-rc3.x0+1));
             g_pz[gn_pz].p0=p0;
             g_pz[gn_pz].ic=ic;
             g_pz[gn_pz].w=w;
             gn_pz++;
             //c_Show_Rect(rc3);
             //ki++;
            //n1++;
lp3:
            t=0;
            }
        }
}

m3=20;
for(i=gn_k;i<gn_pz;i++)
            {
            if(g_pz[i].s>0)
                {
                for(j=i+1;j<gn_pz;j++)
                    {
                    if(g_pz[j].s>0)
                        {
                        t=c_Get_Dist3(g_pz[i],g_pz[j]);
                        if(t<m3)
                            {
                            if(g_pz[i].s>=g_pz[j].s)
                                {
                                g_pz[j].s=0;
                                }
                           else if(g_pz[i].s<g_pz[j].s)
                                {
                                g_pz[i].s=0; goto lp4;
                                }
                            }
                        }
                    }
                }
        lp4:
            t=0;
            }

}
m3=15;




        i2=0;g_len2[0]=gc_w2;g_len2[1]=gc_w2;
        g_len3[0]=2.0*gc_w2;g_len3[1]=2.0*gc_w2;

        //g_len2[0]=24;g_len2[1]=24;
        for(i=0;i<gn_pz;i++)
            {
            if(g_pz[i].s>0)
                {
                c_Show_Rect(g_pz[i].r);

                //k=c_JS_Dir(g_pz[i].ic,w,g_pz[i].r,&g_pz[i]);
                //c_JPoint3(g_pz[i].w,0.666,&g_pz[i]);
                if(g_pz[i].ds<0.5)
                {
                //c_Show_RectF(2,255,g_pz[i].p0,g_pz[i].mi,g_len2);

                }
lps:
                t=0;i2++;
                }
            }

    gn_Lk=i2;


    g_C1[gs_database].y=gn_C1;
    g_C3[gs_database].y=i2;
}


