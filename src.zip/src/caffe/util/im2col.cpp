#include <vector>

#include "caffe/util/im2col.hpp"
#include "caffe/util/math_functions.hpp"

namespace caffe {
inline bool is_a_ge_zero_and_a_lt_b(int a, int b) {
  return static_cast<unsigned>(a) < static_cast<unsigned>(b);
}

template <typename Dtype>
void im2col_cpu(const Dtype* data_im, const int channels,
    const int height, const int width, const int kernel_h, const int kernel_w,
    const int pad_h, const int pad_w,
    const float stride_h, const float stride_w,
    const int dilation_h, const int dilation_w,
    Dtype* data_col) {
  float v[4],c[4],t,tx,ty;
  int   x0,x1,x2,y0,y1,y2;


  const int output_h = 1.0*(height + 2 * pad_h -
    (dilation_h * (kernel_h - 1) + 1)) / stride_h + 1.333333;
  float stride_h1=stride_h;
  if(output_h >1) stride_h1=1.0*(height + 2 * pad_h - (dilation_h * (kernel_h - 1) + 1)) /(output_h-1.000) ;

  const int output_w = 1.0*(width + 2 * pad_w -
    (dilation_w * (kernel_w - 1) + 1)) / stride_w + 1.333333;
  float stride_w1=stride_w;
   if(output_w >1)  stride_w1=1.0*(width + 2 * pad_w -(dilation_w * (kernel_w - 1) + 1)) /(output_w-1.000);

  const int channel_size = height * width;

  for (int channel = channels; channel--; data_im += channel_size) {
    for (int kernel_row = 0; kernel_row < kernel_h; kernel_row++) {
      for (int kernel_col = 0; kernel_col < kernel_w; kernel_col++) {
        float input_row = -pad_h + kernel_row * dilation_h;
        for (int output_rows =output_h; output_rows; output_rows--) {
          int input_row2=input_row;
		  if (!is_a_ge_zero_and_a_lt_b(input_row2, height)) {
            for (int output_cols = output_w; output_cols; output_cols--) {
              *(data_col++) = 0;
            }
          } else {
            y0=input_row;
			ty=input_row-y0;
            y1=y0+1;
            if(y1>=height) y1=2*height-y1-1;
            float input_col = -pad_w + kernel_col * dilation_w;
            for (int output_cols = output_w; output_cols; output_cols--) {
              int input_col2=input_col;
              if (is_a_ge_zero_and_a_lt_b(input_col2, width)) {                
				x0=input_col;
				tx=input_col-x0;
                x1=x0+1;
                if(x1>=width) x1=2*width-x1-1;
                v[0]=data_im[y0*width + x0];
				v[1]=data_im[y0*width + x1];
				v[2]=data_im[y1*width + x1];
                v[3]=data_im[y1*width + x0];
                c[0]=(1.0-tx)*(1.0-ty);
		c[1]=tx*(1.0-ty);
		c[2]=tx*ty;
		c[3]=(1.0-tx)*ty;
                *(data_col++) =(Dtype)(c[0]*v[0]+c[1]*v[1]+c[2]*v[2]+c[3]*v[3]);   
              } 
	      else {
                *(data_col++) = 0;
              }
              input_col += stride_w1;
            }
          }
          input_row += stride_h1;
        }
      }
    }
  }   


}

// Explicit instantiation
template void im2col_cpu<float>(const float* data_im,  const int channels,
    const int height, const int width, const int kernel_h, const int kernel_w,
    const int pad_h, const int pad_w, const float stride_h,
    const float stride_w, const int dilation_h, const int dilation_w,
    float* data_col);
template void im2col_cpu<double>(const double* data_im,  const int channels,
    const int height, const int width, const int kernel_h, const int kernel_w,
    const int pad_h, const int pad_w, const float stride_h,
    const float stride_w, const int dilation_h, const int dilation_w,
    double* data_col);

template <typename Dtype>
inline void im2col_nd_core_cpu(const Dtype* data_input, const bool im2col,
    const int num_spatial_axes, const int* im_shape, const int* col_shape,
    const int* kernel_shape, const int* pad, const float* stride,
    const int* dilation, Dtype* data_output) {
  if (!im2col) {
    int im_size = im_shape[0];
    for (int i = 0; i < num_spatial_axes; ++i) {
      im_size *= im_shape[1 + i];
    }
    caffe_set(im_size, Dtype(0), data_output);
  }
  int kernel_size = 1;
  for (int i = 0; i < num_spatial_axes; ++i) {
    kernel_size *= kernel_shape[i];
  }
  const int channels_col = col_shape[0];
  vector<int> d_offset(num_spatial_axes, 0);
  vector<int> d_iter(num_spatial_axes, 0);
  for (int c_col = 0; c_col < channels_col; ++c_col) {
    // Loop over spatial axes in reverse order to compute a per-axis offset.
    int offset = c_col;
    for (int d_i = num_spatial_axes - 1; d_i >= 0; --d_i) {
      if (d_i < num_spatial_axes - 1) {
        offset /= kernel_shape[d_i + 1];
      }
      d_offset[d_i] = offset % kernel_shape[d_i];
    }
    for (bool incremented = true; incremented; ) {
      // Loop over spatial axes in forward order to compute the indices in the
      // image and column, and whether the index lies in the padding.
      int index_col = c_col;
      int index_im = c_col / kernel_size;
      bool is_padding = false;
      for (int d_i = 0; d_i < num_spatial_axes; ++d_i) {
        const int d = d_iter[d_i];
        const int d_im = d * stride[d_i] - pad[d_i] +
            d_offset[d_i] * dilation[d_i];
        is_padding |= d_im < 0 || d_im >= im_shape[d_i + 1];
        index_col *= col_shape[d_i + 1];
        index_col += d;
        index_im *= im_shape[d_i + 1];
        index_im += d_im;
      }
      if (im2col) {
        if (is_padding) {
          data_output[index_col] = 0;
        } else {
          data_output[index_col] = data_input[index_im];
        }
      } else if (!is_padding) {  // col2im
        data_output[index_im] += data_input[index_col];
      }
      // Loop over spatial axes in reverse order to choose an index,
      // like counting.
      incremented = false;
      for (int d_i = num_spatial_axes - 1; d_i >= 0; --d_i) {
        const int d_max = col_shape[d_i + 1];
        DCHECK_LT(d_iter[d_i], d_max);
        if (d_iter[d_i] == d_max - 1) {
          d_iter[d_i] = 0;
        } else {  // d_iter[d_i] < d_max - 1
          ++d_iter[d_i];
          incremented = true;
          break;
        }
      }
    }  // while(incremented) {
  }  // for (int c = 0; c < channels_col; ++c) {
}

template <typename Dtype>
void im2col_nd_cpu(const Dtype* data_im,  const int num_spatial_axes,
    const int* im_shape, const int* col_shape,
    const int* kernel_shape, const int* pad, const float* stride,
    const int* dilation, Dtype* data_col) {
  const bool kIm2Col = true;
  im2col_nd_core_cpu(data_im, kIm2Col,  num_spatial_axes, im_shape, col_shape,
                  kernel_shape, pad, stride, dilation, data_col);
}

// Explicit instantiation
template void im2col_nd_cpu<float>(const float* data_im,
    const int num_spatial_axes,
    const int* im_shape, const int* col_shape,
    const int* kernel_shape, const int* pad, const float* stride,
    const int* dilation, float* data_col);
template void im2col_nd_cpu<double>(const double* data_im,
    const int num_spatial_axes,
    const int* im_shape, const int* col_shape,
    const int* kernel_shape, const int* pad, const float* stride,
    const int* dilation, double* data_col);

template <typename Dtype>
void col2im_cpu(const Dtype* data_col,  const int channels,
    const int height, const int width, const int kernel_h, const int kernel_w,
    const int pad_h, const int pad_w,
    const float stride_h, const float stride_w,
    const int dilation_h, const int dilation_w,
    Dtype* data_im) {
float v[4],c[4],tx,ty;
  Dtype t1;
  int   x0,x1,x2,y0,y1,y2;

  caffe_set( height * width * channels, Dtype(0), data_im);
  const int output_h = 1.0*(height + 2 * pad_h -
    (dilation_h * (kernel_h - 1) + 1)) / stride_h + 1.333333;
  float stride_h1=stride_h;
  if(output_h >1) stride_h1=1.0*(height + 2 * pad_h - (dilation_h * (kernel_h - 1) + 1)) /(output_h-1.000) ;

  const int output_w = 1.0*(width + 2 * pad_w -
    (dilation_w * (kernel_w - 1) + 1)) / stride_w + 1.333333;
  float stride_w1=stride_w;
   if(output_w >1)  stride_w1=1.0*(width + 2 * pad_w -(dilation_w * (kernel_w - 1) + 1)) /(output_w-1.000);

  const int channel_size = height * width;
  //LOG(INFO)<<"output_h,output_w=:"<<output_h<<","<<output_w;


  for (int channel = channels; channel--; data_im += channel_size) {
    for (int kernel_row = 0; kernel_row < kernel_h; kernel_row++) {
      for (int kernel_col = 0; kernel_col < kernel_w; kernel_col++) {
        float input_row = -pad_h + kernel_row * dilation_h;
        for (int output_rows = output_h; output_rows; output_rows--) {
          int input_row2=input_row;
          if (!is_a_ge_zero_and_a_lt_b(input_row, height)) {
            data_col += output_w;
          } else {
            y0=input_row;
			ty=input_row-y0;
			y1=y0+1; 
            if(y1>=height) y1=2*height-y1-1;
            float input_col = -pad_w + kernel_col * dilation_w;
            for (int output_col = output_w; output_col; output_col--) {
			  int input_col2=input_col;
              if (is_a_ge_zero_and_a_lt_b(input_col2, width)) {              
				x0=input_col;
				tx=input_col-x0;
                x1=x0+1;
                if(x1>=width) x1=2*width-x1-1;
                v[0]=data_im[y0*width + x0];
				v[1]=data_im[y0*width + x1];
				v[2]=data_im[y1*width + x1];
                v[3]=data_im[y1*width + x0];
                c[0]=(1-tx)*(1-ty);
				c[1]=tx*(1-ty);
				c[2]=tx*ty;
				c[3]=(1-tx)*ty;                
                t1=(Dtype)(*data_col);
                data_im[y0*width + x0] += c[0]*t1;
                data_im[y0*width + x1] += c[1]*t1;
                data_im[y1*width + x1] += c[2]*t1;
                data_im[y1*width + x0] += c[3]*t1;
              }
              data_col++;
              input_col += stride_w1;
            }
          }
          input_row += stride_h1;
        }
      }
    }
  }

}

// Explicit instantiation
template void col2im_cpu<float>(const float* data_col,  const int channels,
    const int height, const int width, const int kernel_h, const int kernel_w,
    const int pad_h, const int pad_w, const float stride_h,
    const float stride_w, const int dilation_h, const int dilation_w,
    float* data_im);
template void col2im_cpu<double>(const double* data_col,  const int channels,
    const int height, const int width, const int kernel_h, const int kernel_w,
    const int pad_h, const int pad_w, const float stride_h,
    const float stride_w, const int dilation_h, const int dilation_w,
    double* data_im);

template <typename Dtype>
void col2im_nd_cpu(const Dtype* data_col,  const int num_spatial_axes,
    const int* im_shape, const int* col_shape,
    const int* kernel_shape, const int* pad, const float* stride,
    const int* dilation, Dtype* data_im) {
  const bool kIm2Col = false;
  im2col_nd_core_cpu(data_col, kIm2Col,  num_spatial_axes, im_shape, col_shape,
                     kernel_shape, pad, stride, dilation, data_im);
}
// Explicit instantiation
template void col2im_nd_cpu<float>(const float* data_col,
    const int num_spatial_axes,
    const int* im_shape, const int* col_shape,
    const int* kernel_shape, const int* pad, const float* stride,
    const int* dilation, float* data_im);
template void col2im_nd_cpu<double>(const double* data_col,
    const int num_spatial_axes,
    const int* im_shape, const int* col_shape,
    const int* kernel_shape, const int* pad, const float* stride,
    const int* dilation, double* data_im);
}  // namespace caffe
