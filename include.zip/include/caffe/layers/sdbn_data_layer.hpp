#ifndef CAFFE_SDBN_Data_LAYER_HPP_
#define CAFFE_SDBN_Data_LAYER_HPP_

#include <vector>
#include <fstream>  // NOLINT(readability/streams)
#include <iostream>  // NOLINT(readability/streams)
#include "caffe/basic_sdbn_data.h"
#include "caffe/blob.hpp"
#include "caffe/data_transformer.hpp"
#include "caffe/internal_thread.hpp"
#include "caffe/layer.hpp"
#include "caffe/layers/base_data_layer.hpp"
#include "caffe/proto/caffe.pb.h"
#include "caffe/util/db.hpp"

#include <stdio.h>
#include <opencv2/opencv.hpp>
#include <iostream>
using namespace cv;
using namespace std;


namespace caffe {

typedef struct
{
int    n;
int    p[1000];
int    pic,cur;
float  s[1000];
}Object_S;


template <typename Dtype>
class SDBN_DataLayer : public BasePrefetchingDataLayer<Dtype> {
 public:
  explicit SDBN_DataLayer(const LayerParameter& param, UDL_Data<Dtype>* udl=NULL);
  virtual ~SDBN_DataLayer();
  virtual void DataLayerSetUp(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top);
  // SDBN_DataLayer uses DataReader instead for sharing for parallelism
  virtual inline bool ShareInParallel() const { return false; }
  virtual inline const char* type() const { return "Data"; }
  virtual inline int ExactNumBottomBlobs() const { return 0; }
  virtual inline int MinTopBlobs() const { return 1; }
  virtual inline int MaxTopBlobs() const { return 3; }



 protected:
  virtual void  load_batch(Batch<Dtype>* batch);
  virtual void  load_sample(Batch<Dtype>* batch,int item_id);



  uint64_t offset_;
  Phase phase_;
  vector<int> top_shape_,top_shape2_;

  float  dist_min_, scale_factor, dist_max_,Tdist[10];
  Point_CXY      sImg_,pa,pa2;
  FILE       *f1_,*f2_;
  int        object_cur_, object_full_, pic_cur_, pic_full_, pic_begin_, pic_test_begin_, pic_test_full_,  cn_scan, gn_scan,gn_scan2,gn_pic,dim_feature;
  int        dx,dx2,dy,dy2,channels_,smp_full_,smp_cur_;
  int        pre_pic_cur_;
  int        pic_obj_full_;
  int        pic_obj_cur_;
  int        threshold, nsm_,page, page2,w_full,h_full, smp_label_points_;
  int        mx_,my_,cx_,cy_,m1_,m2_;
  Rect_CXY       rec_;
  bool       obj_scale_;
  bool       obj_rot_;
  bool       obj_pos_;

  int        obj_scale_full_,topsize;
  Dtype      obj_scale_val_[10],imgbuf[10000],buf2[10000];

  int        obj_rot_full_;
  float      obj_rot_val_[20];
  int        obj_scale_pattern_,obj_pos_pattern_,obj_rot_pattern_;

  int        obj_pos_full_;
  Point2     obj_pos_val_[20];

  int        obj_full_,obj_smp_full_,obj_end_,imgwidth_;
  int        imgheight_,imgbytesPerline_;
  int        obj_cur_,obj_smp_cur_;
  int        illumination, task_, main_task_, obj_label_points_,pic_train_end_;

  Point3     fp[50];

  float      scale_48, scale_min_,scale_max_, scale_, avg_, dev_, scale_1, scale_2;

  float      angle_diff_,rot_min_,rot_max_, avg_min_, avg_max_, dev_max_, dev_min_;

  Point2     pos_min_,pos_max_;

  Rect_CXY       negtive_range_;
  float      negtive_dist_;

  Object_S    sobj_;
  Scan_Pos   *scan_;
  float  *image_anchor_;
  float  *feature_anchor_;
  float  *image_label_;
  float  *image_target_;

  Point3      fobj_[300];
  ObjectType_NEW  *fpic;
  ObjectType_NEW  fpic_cur_;
  Mat      Img_, Img2_;
 // Feature<Dtype>     fte_;

};

}  // namespace caffe

#endif  // CAFFE_SDBN_Data_LAYER_HPP_
