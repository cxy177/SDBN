﻿#ifndef BASIC_SDBN_DATA_H
#define BASIC_SDBN_DATA_H

#define U8                        unsigned char
#define PAI                      3.1415926535
#define PAI2                    1.57079632675
#define PAI_1_5               4.71238898025
#define PAI_2                   6.2831853070
#define PAI4                    6.2831853070
#define PAI3                    4.71238898025

#define Default_pow               0.5
#define Default_angle             0.0
#define Default_gamma          1.0
#define Default_height            1.0
#define Default_spacial_x         30.0
#define Default_spacial_y         10.0
#define Default_model_x          30.0
#define Default_model_y          10.0
#define Default_Tri_angle         45.0
#define Default_Tri_dist          10.0
#define Default_ImageWidth        1270
#define Default_ImageHeight       680

#define KernelType_ReLu    0x00
#define KernelType_PReLu   0x01
#define KernelType_Tanh    0x02
#define KernelType_Sigmoid 0x03
#define KernelType_Linear  0x04
#define KernelType_RBF     0x05
#define KernelType_EXP_L1  0x06

#define INPUT_Float        0x00
#define INPUT_U8            0x01


#define Net_Type_SDBN_1             0
#define Net_Type_SDBN_2             1

#define Task_Type_Train             0
#define Task_Type_Test               1


#define Database_OAD             1
#define Database_OVDS            2
#define Database_OIRDS          3
#define Database_MUNICH          5
#define MAX_Feature_Dim      20000;


//2-D Point with integer coordinates.
typedef struct
{
short  x,y;
}Point_CXY;

// 2-Dimension Points with real coordinates.
typedef struct
{
float x,y;
}Point2;

// 2-Dimension Points with real coordinates and tangents.
typedef struct
{
float x,y,tx,ty;
}Point2_;

// 3-Dimension Points with real coordinates.
typedef struct
{
float x,y,z;
}Point3;

// 3-Dimension Points with real coordinates, tanget and normal directions.
typedef struct
{
float x,y,z;
float tx,ty,tz;
float nx,ny,nz;
}Point3_CXY;



typedef struct
{
short x0,x1,y0,y1;
}Rect_CXY;


typedef struct
{
int      pic,ja,label;
float    v[3],x[3],y[3];
float    scale,s1,angle,a1;
float    mv[3],sv[3],fv[3];
float    dist[3];
}Scan_Pos;

typedef struct
{
int      pic,grid;
float    xc[3],yc[3];
float    v[3],x[3],y[3];
}Smp_Pos;


typedef struct
{
int    i;
int    x,y;
float  xp,yp;
float  a,a2,v;
float  v2[5];
}SPoint;


typedef struct
{
int    x,y,z,w,h;
float  v;
}Point3_A;

typedef struct
{
int    type,in;
float dx,dy,dis;
}Point4;


typedef struct
{
int   single;
int   step, net_id;
int   point_num;//标记点个数
int   object_num;//目标个数
char  filename[260];//文件名
char  test_filename[260];//文件名
char  test_filename2[260];//文件名
int     Class,Sub;
Point2 p[4000];//标记点组
Point2  cp[2000];
float   angle[2000];
float   length[2000];
float   width[2000];
float   subclass[2000];
float   direction[2000];
}ObjectType_NEW;//标记图像文件结构



#endif // BASIC_SDBN_DATA_H
