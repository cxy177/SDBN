﻿#ifndef CAFFE_UDL_DATA_H_
#define CAFFE_UDL_DATA_H_

#include <algorithm>
#include <string>
#include <vector>
#include <fstream>
#include<iostream>

#include "caffe/basic_sdbn_data.h"
#include "caffe/blob.hpp"


#include <stdio.h>
#include <opencv2/opencv.hpp>
#include <iostream>
using namespace cv;
using namespace std;

namespace caffe {
template <typename Dtype>
class UDL_Data {
 public:

    int       cx_,cy_,cx2_,cy2_,off_, channels_,batch_size;
    int       Net_Type, Database_File, scan_cur_,n_scan_,pic_cur_, pic_full_;
    float    kernel_size,side_factor, enlarge_scale, max_[5],avg[5], object_len;



    Smp_Pos   scan_[40000];
    Scan_Pos  scan[20000];
    Scan_Pos  scan2[2000];

    int       imgwidth_;
    int       imgheight_;
    int       imgsize,imgsize2;

    float  sample_data_[6*1000*1000];
    float  sample_label_[1000*1000];
    float  sample_target_[1000*1000];

    float  image_data_[3*12000*8000];
    float  image_label_[8000*8000];
    float  image_target_[12000*8000];
    float  image_target2_[12000*8000];

    ObjectType_NEW fnew[200];

    Point_CXY  train,test,sImg_,pos;
    Rect_CXY   rec[4000], rec_;
    int               m1_,m2_;

    Mat      Img_,Img2_,Img3_,TestImg_;

    float    scan_threshold,  connect_threshold, area_threshold;


    U8       *pImg_,*pImg2_,*pTestImg_;
    int      hImg,wImg1,wImg2,hImg_2,wImg1_2,wImg2_2;
    int      hTestImg,wTestImg1,wTestImg2;


  explicit UDL_Data()
    {

    }
  virtual ~UDL_Data() { }

    //Translate the database (defined by "database" ) of aircraft into the labeling text file (defined by "pf").
   void  Database_2_Aircraft_TextFile(const char *database, const char *pf);

   //Translate the database (defined by "database" ) of vehicle into the labeling text file (defined by "pf").
   void  Database_2_Vehicle_TextFile(const char *database, const char *pf);

    //Read the labeling information of vehicles from the text file, store them into the database structure (ObjectType_NEW) "fnew".
    int    Vehicle_TextFile_2_Database(int m1,const char *path,const char *pf);

    //Read the labeling information of aircrafts from the text file, store them into the database structure (ObjectType_NEW) "fnew".
    int    Aircraft_TextFile_2_Database(int m1, const char *path, const char *pf);

    int  Change_Pic(int pic_cur);

    int  Change_Test_Pic(int pic_cur);

    //Generate all clustering positions over the image after threshoulding by minium distance
    void  Scan_Pos_1();

  //Test whether between  the two points  exist pixels with grayscale below the connect_threshold;
    int    Test_Connection(Point p0, Point p1);


    //Filter scan poses with samll area or obscure intensity.
    float   Smp_Area(int ns);

    int  fprint2(const char *buf, const char *pf,int na,float *ax,int nb,int *bx);

 protected:

  vector<Dtype> loss_;
  vector<bool>    param_propagate_down_;

 private:
};  // class Layer


template <typename Dtype>
int  UDL_Data<Dtype>::fprint2(const char *buf, const char *pf,int na,float *ax,int nb,int *bx)
{
char len1[2];
int  n1,i;
char szTxt[10000];
FILE *pfile2;

for(i=0;i<na;i++)
    {
    if(i==0) sprintf((char *)&szTxt[10*i],"%3.6f        ",ax[i]);
    if(i>0) sprintf((char *)&szTxt[10*i],", %3.6f       ",ax[i]);
    }


for(i=0;i<nb;i++)
    {
    sprintf((char *)&szTxt[6*i+10*na],", %d           ",bx[i]);
    }
len1[0]=0x0d;len1[1]=0x0a;
i=0;
while(buf[i]!=0&&i<1000)
    {
    i++;
    }
n1=i;
pfile2=fopen(pf,"a+");
fwrite(&buf[0],1,n1,pfile2);
fwrite(&szTxt[0],1,10*na+6*nb,pfile2);
fwrite(&len1[0],1,2,pfile2);
fclose(pfile2);
}



template <typename Dtype>
int  UDL_Data<Dtype>::Change_Pic(int pic_cur) {
Img_=imread((const char *)fnew[pic_cur].filename,IMREAD_COLOR );
imgwidth_=Img_.cols;
imgheight_=Img_.rows;
imgsize=imgwidth_*imgheight_;

pic_cur_=pic_cur;

LOG(INFO)<<"train pic_cur_=" <<pic_cur<< fnew[pic_cur].filename<<", w1="<<imgwidth_;//i1=0;
if(imgwidth_==0) {
  LOG(INFO)<<"Can not open pic !!!! pic_cur_=" <<pic_cur_<< fnew[pic_cur_].filename;
  return(-1);
}

Img2_.create(imgheight_,imgwidth_, CV_8UC1);
U8* p=Img2_.data;
memset(p,0,imgwidth_*imgheight_);
memset(image_label_,0,4*imgwidth_*imgheight_);

for(int i=0;i<fnew[pic_cur_].object_num;i++)
   {
   float tx=fnew[pic_cur_].p[2*i].x-fnew[pic_cur_].p[2*i+1].x;
   float ty=fnew[pic_cur_].p[2*i].y-fnew[pic_cur_].p[2*i+1].y;
   float len=sqrt(tx*tx+ty*ty);
   float tx1=tx/len;
   float ty1=ty/len;

   float cx=0.5*(fnew[pic_cur_].p[2*i].x+fnew[pic_cur_].p[2*i+1].x);
   float cy=0.5*(fnew[pic_cur_].p[2*i].y+fnew[pic_cur_].p[2*i+1].y);

   int x0=cx-80; int x1=cx+80;
   if(x0<0) x0=0;
   if(x1>=imgwidth_) x1=imgwidth_;

   int y0=cy-80; int y1=cy+80;
   if(y0<0) y0=0;
   if(y1>=imgheight_) y1=imgheight_;
   for(int y=y0;y<y1;y++)
        {
        for(int x=x0;x<x1;x++)
                {
                float t1=tx1*(x-cx)+ty1*(y-cy);
                t1=t1/len;
                float t2=ty1*(x-cx)-tx1*(y-cy);
                t2=t2/len;
                float t3=t1*t1+side_factor*t2*t2;
                float t=exp(-5.0/kernel_size*t3);
                int k=y*imgwidth_+x;
                if(t>image_label_[k]) image_label_[k]=t;
                int c1=255.0*t;
                if(c1>p[k]) p[k]=c1;                
                }
        }
   }
char buf2[300];

    sprintf(buf2,"./train_pic/label_%1d.jpg", pic_cur);
    imwrite((const char *)buf2,Img2_);
  return(0);
}


template <typename Dtype>
int  UDL_Data<Dtype>::Change_Test_Pic(int pic_cur) {

Change_Pic(pic_cur);
pic_cur_=pic_cur;

int    mx_= 1.0*imgwidth_/(cx_-20)+0.35;
int    my_=1.0*imgheight_/(cy_-20)+0.35;

    if(mx_<1) mx_=1;
    if(my_<1) my_=1;

int i1=0;
for(int j=0;j<my_;j++)
{
for(int i=0;i<mx_;i++)
   {
    rec[i1].y0=1.0*j*(cy_-20);
    rec[i1].y1=rec[i1].y0+cy_;
    if(j==my_-1) rec[i1].y1=imgheight_;
    rec[i1].x0=1.0*i*(cx_-20);
    rec[i1].x1=rec[i1].x0+cx_;
    if(i==mx_-1)  rec[i1].x1=imgwidth_;



    i1++;
   }
}

m2_=i1;
m1_=0;
rec_=rec[m1_];

return(1);
}


//Translate the database (defined by "database" ) of aircraft into the labeling text file (defined by "pf").
template <typename Dtype>
void  UDL_Data<Dtype>::Database_2_Aircraft_TextFile(const char *database, const char *pf) {
    int k,i,j,k1,k2,k3,k4,i1,i2,i3,i4,h1,h2,h3,j1,j2,j3;

     FILE *f1=fopen((const char *)database,"rb");
     if(f1==0) return;
     fseek(f1,0,SEEK_SET);
     pic_full_=fread(fnew,sizeof(ObjectType_NEW),200,f1);
     fclose(f1);

      FILE *f2=fopen((const char *)pf,"wb");
     fseek(f2,0,SEEK_SET);
     fclose(f2);

     float  ax[10];
     int bx[10];
     char buf[300];
     for(int i=0;i<pic_full_;i++)
     {
     int n1=fnew[i].object_num;
     sprintf(buf,"filename=: %1d.jpg,  aircraft number=: %d ",i+1,n1);
     fprint2(buf, pf,0,0,0,0);
     fprint2("x-pos         , y-pos         , x-pos         , y-pos         , direction", pf,0,0,0,0);

    for(int j=0;j<n1;j++)
    {
    ax[0]=fnew[i].p[2*j].x;
    ax[1]=fnew[i].p[2*j].y;
    ax[2]=fnew[i].p[2*j+1].x;
    ax[3]=fnew[i].p[2*j+1].y;
    bx[0]=fnew[i].direction[j];
    fprint2("", pf,4,ax,1,bx);
    }


      fprint2("\n", pf,0,0,0,0);
     }




}

//Translate the database (defined by "database" ) of vehicle into the labeling text file (defined by "pf").
template <typename Dtype>
void  UDL_Data<Dtype>::Database_2_Vehicle_TextFile(const char *database, const char *pf)
{

     FILE *f1=fopen((const char *)database,"rb");
     if(f1==0) return;
     fseek(f1,0,SEEK_SET);
     pic_full_=fread(fnew,sizeof(ObjectType_NEW),200,f1);
     fclose(f1);

      FILE *f2=fopen((const char *)pf,"wb");
     fseek(f2,0,SEEK_SET);
     fclose(f2);

     float  ax[10];
     int bx[10];
     char buf[300];
     for(int i=0;i<pic_full_;i++)
     {
     int n1=fnew[i].object_num;
     sprintf(buf,"filename=: %1d.JPG, vehicle number=: %d ",i+1,n1);
      fprint2(buf, pf,0,0,0,0);
      fprint2("x-pos          , y-pos          , x-pos          , y-pos", pf,0,0,0,0);
     for(int j=0;j<n1;j++)
     {
     ax[0]=fnew[i].p[2*j].x;
     ax[1]=fnew[i].p[2*j].y;
     ax[2]=fnew[i].p[2*j+1].x;
     ax[3]=fnew[i].p[2*j+1].y;
     fprint2("", pf,4,ax,0,bx);
     }
      fprint2("\n", pf,0,0,0,0);
     }

}

//Read the labeling information of vehicles from the text file, store them into the database structure (ObjectType_NEW) "fnew".
template <typename Dtype>
int  UDL_Data<Dtype>::Vehicle_TextFile_2_Database(int m1, const char *path, const char *pf) {
    int k,i,j,k1,k2,k3,k4,i1,i2,i3,i4,h1,h2,h3,j1,j2,j3;
    ssize_t size;
    string      line; //保存读入的每一行
    string      filepath, filename,data;
     LOG(INFO) <<"begin!!!";
     fstream   f((const char *)pf, ios::in|ios::binary|ios::ate);
     size = f.tellg();
     f.seekg(0,ios::beg);

 //LOG(INFO) <<"start f=!!!"<<f;
    i1=m1;
    getline(f,line);

    k1=line.find( "filename=:", 0);

    k1=k1+10;
    k2=line.find( ",", k1);
    filename=line.substr(k1, k2-k1);
    k=0;
    while(filename.at(k)==' '&&k<10)
    {
    k++;
    }
    k1=k1+k;
     filename=line.substr(k1, k2-k1);
   // LOG(INFO) <<"filename="<< filename;

    filepath=(const char *)path+filename;
    LOG(INFO) <<"filepath="<< filepath;
    memcpy(fnew[i1].filename,filepath.c_str(),260);
    getline(f,line);
  //LOG(INFO) <<"line="<< line;
 // return(0);
    i2=0;
    while(getline(f,line))
    {
      //LOG(INFO) <<"line="<< line;
    k1=line.find( ",", 0);
    if(k1>=0)
    {

    data=line.substr(0,k1);
    fnew[i1].p[i2].x=atof(data.c_str());
     //LOG(INFO) <<"i2,fnew[i1].p[i2].x="<<i2<<"      ,"<<fnew[i1].p[i2].x;
    k2=line.find( ",", k1+1);
    data=line.substr(k1+1,k2-k1-1);
    fnew[i1].p[i2].y=atof(data.c_str());
     //LOG(INFO) <<"fnew[i1].p[i2].y="<<fnew[i1].p[i2].y;
    k1=k2;i2++;
    k2=line.find( ",", k1+1);
    data=line.substr(k1+1,k2-k1-1);
    fnew[i1].p[i2].x=atof(data.c_str());
      //LOG(INFO) <<"i2,fnew[i1].p[i2].x="<<i2<<"      ,"<<fnew[i1].p[i2].x;
    k1=k2;
    data=line.substr(k1+1);
    fnew[i1].p[i2].y=atof(data.c_str());
    //LOG(INFO) <<"i2,fnew[i1].p[i2].y="<<i2<<"     ,"<<fnew[i1].p[i2].y;
    i2++;

    }
    else {
     fnew[i1].point_num=i2;
     fnew[i1].object_num=i2/2;
     i2=0;
     //LOG(INFO) <<"i1,fnew[i1].point_num="<<i1<<","<<fnew[i1].point_num;

     k1=line.find( "filename=:", 0);
    // LOG(INFO) <<"k1=:"<<k1;
    while(k1<0&&k1!=-111)
    {
    //LOG(INFO) <<"k1=:"<<k1;
     if(getline(f,line))
     {k1=line.find( "filename=:", 0);}
     else {k1=-111; }
    }

    if(k1>=0) {
                k1=k1+10;
                 i1++;
                k2=line.find( ",", k1);
                filename=line.substr(k1, k2-k1);
                k=0;
                while(filename.at(k)==' '&&k<10)
                {
                k++;
                }
                k1=k1+k;
                 filename=line.substr(k1, k2-k1);
                 filepath=(const char *)path+filename;
                  LOG(INFO) <<"filepath="<< filepath;
                memcpy(fnew[i1].filename,filepath.c_str(),260);
                getline(f,line);
                //getline(f,line);
    }

    }
    //getline(f,line);
    }
 i1++;
return(i1-m1);

}




//Read the labeling information of aircrafts from the text file, store them into the database structure (ObjectType_NEW) "fnew".
template <typename Dtype>
int  UDL_Data<Dtype>::Aircraft_TextFile_2_Database(int m1, const char *path, const char *pf) {
    int k,i,j,k1,k2,k3,k4,i1,i2,i3,i4,h1,h2,h3,j1,j2,j3;
    ssize_t size;
    string      line; //保存读入的每一行
    string      filepath, filename,data;


     fstream   f((const char *)pf, ios::in|ios::binary|ios::ate);
     size = f.tellg();
     f.seekg(0,ios::beg);

    i1=m1;
    getline(f,line);

    k1=line.find( "filename=:", 0);

    k1=k1+10;
    k2=line.find( ",", k1);
    filename=line.substr(k1, k2-k1);
    k=0;
    while(filename.at(k)==' '&&k<10)
    {
    k++;
    }
    k1=k1+k;
     filename=line.substr(k1, k2-k1);
   // LOG(INFO) <<"filename="<< filename;

    filepath=(const char *)path+filename;
    LOG(INFO) <<"filepath="<< filepath;
    memcpy(fnew[i1].filename,filepath.c_str(),260);
    getline(f,line);
  LOG(INFO) <<"line="<< line;
 // return(0);
    i2=0;
    while(getline(f,line))
    {
      LOG(INFO) <<"line="<< line;
    k1=line.find( ",", 0);
    if(k1>=0)
    {
    data=line.substr(0,k1);
    fnew[i1].p[i2].x=atof(data.c_str());
    // LOG(INFO) <<"i2,fnew[i1].p[i2].x="<<i2<<"      ,"<<fnew[i1].p[i2].x;
    k2=line.find( ",", k1+1);
    data=line.substr(k1+1,k2-k1-1);
    fnew[i1].p[i2].y=atof(data.c_str());
     //LOG(INFO) <<"fnew[i1].p[i2].y="<<fnew[i1].p[i2].y;
    k1=k2;i2++;
    k2=line.find( ",", k1+1);
    data=line.substr(k1+1,k2-k1-1);
    fnew[i1].p[i2].x=atof(data.c_str());
     // LOG(INFO) <<"i2,fnew[i1].p[i2].x="<<i2<<"      ,"<<fnew[i1].p[i2].x;
    k1=k2;
    k2=line.find( ",", k1+1);
    data=line.substr(k1+1,k2-k1-1);
    fnew[i1].p[i2].y=atof(data.c_str());
     // LOG(INFO) <<"i2,fnew[i1].p[i2].y="<<i2<<"     ,"<<fnew[i1].p[i2].y;
    k1=k2;
    data=line.substr(k1+1);
    i3=i2/2;
    fnew[i1].direction[i3]=atoi(data.c_str());
    //  LOG(INFO) <<"i3,fnew[i1].direction[i3]="<<i3<<"    ,"<<fnew[i1].direction[i3];
    i2++;
    }
    else {
     fnew[i1].point_num=i2;
     fnew[i1].object_num=i2/2;
     i2=0;
     //LOG(INFO) <<"i1,fnew[i1].point_num="<<i1<<","<<fnew[i1].point_num;

     k1=line.find( "filename=:", 0);
     //LOG(INFO) <<"k1=:"<<k1;
    while(k1<0&&k1!=-111)
    {
    LOG(INFO) <<"k1=:"<<k1;
     if(getline(f,line))
     {k1=line.find( "filename=:", 0);}
     else {k1=-111; }
    }
    if(k1>=0) {
                 k1=k1+10;
                 i1++;
                k2=line.find( ",", k1);
                filename=line.substr(k1, k2-k1);
                k=0;
                while(filename.at(k)==' '&&k<10)
                {
                k++;
                }
                k1=k1+k;
                 filename=line.substr(k1, k2-k1);
                filepath=(const char *)path+filename;
                 LOG(INFO) <<"filepath="<< filepath;
                memcpy(fnew[i1].filename,filepath.c_str(),260);
                getline(f,line);
                //getline(f,line);
    }
    }
    //getline(f,line);
    }
 i1++;
return(i1-m1);
}













template <typename Dtype>
void UDL_Data<Dtype>::Scan_Pos_1() {

float v=0;
Point2 v1;
int dx,dy,mx,my,n1,n2,n3,n4;
Rect_CXY rec,rec2;
float th,th2, s_threshold;
Point p0,p1;

int h1=imgheight_;
int w1=imgwidth_;

int imgsize=h1*w1;

float *p=&image_target_[0];
float *p2=&image_target2_[0];

int i1=0;
float v2;

scan_threshold=connect_threshold;
max_[0]=1.0;

s_threshold=scan_threshold*max_[0];

v2=max_[0]-s_threshold;


int i3=0;
for(int y=0;y<h1;y++) {
    for(int x=0;x<w1;x++) {
        int k=y*w1+x;
        float v=0;
        if(p[k]>s_threshold) {
        v=1.0*(p[k]-s_threshold)/v2;}
        p2[i1]=v;
        if(p2[i1]>0) i3++;
        i1++;
        }}

float t=1.0*i3/(h1*w1);

int i2=0;
dx=5;
dy=dx;
mx=10;
my=mx;
th=1;th2=3;


n1=1.0*(h1-my)/dy+0.9;
n2=1.0*(w1-mx)/dx+0.9;
LOG(INFO) << "n1,n2= " << n1<<","<<n2;

for(int j=0;j<n1;j++) {
    for(int i=0;i<n2;i++) {
        rec.y0=j*dy;rec.y1=rec.y0+my;
        rec.x0=i*dx;rec.x1=rec.x0+mx;
        if(j==n1-1) rec.y1=h1;
        if(i==n2-1) rec.x1=w1;


        v=0;v1.x=0;v1.y=0;n3=0;

        for(int y=rec.y0;y<rec.y1;y++) {
            for(int x=rec.x0;x<rec.x1;x++) {
                int k=y*w1+x;
                v+=p2[k];
                v1.x+=p2[k]*x;
                v1.y+=p2[k]*y;
                if(p2[k]>0) n3++;
            }}

        if(n3>=th) {v1.x=v1.x/v;v1.y=v1.y/v;
        rec2.x0=v1.x-1.0*mx/2;rec2.y0=v1.y-1.0*my/2;
        rec2.x1=v1.x+1.0*mx/2;rec2.y1=v1.y+1.0*my/2;
        if(rec2.x0<0) rec2.x0=0;
        if(rec2.y0<0) rec2.y0=0;
        if(rec2.x1>w1) rec2.x1=w1;
        if(rec2.y1>h1) rec2.y1=h1;

        v=0;v1.x=0;v1.y=0;n4=0;
        for(int y=rec2.y0;y<rec2.y1;y++) {
            for(int x=rec2.x0;x<rec2.x1;x++) {
                int k=y*w1+x;
                v+=p2[k];
                v1.x+=p2[k]*x;
                v1.y+=p2[k]*y;
                if(p2[k]>0) n4++; }}
        if(n4>=th2) {v1.x=v1.x/v;v1.y=v1.y/v;}

        rec2.x0=v1.x-1.0*mx/2;rec2.y0=v1.y-1.0*my/2;
        rec2.x1=v1.x+1.0*mx/2;rec2.y1=v1.y+1.0*my/2;
        if(rec2.x0<0) rec2.x0=0;
        if(rec2.y0<0) rec2.y0=0;
        if(rec2.x1>w1) rec2.x1=w1;
        if(rec2.y1>h1) rec2.y1=h1;

        v=0;v1.x=0;v1.y=0;n4=0;
        for(int y=rec2.y0;y<rec2.y1;y++) {
            for(int x=rec2.x0;x<rec2.x1;x++) {
                int k=y*w1+x;
                v+=p2[k];
                v1.x+=p2[k]*x;
                v1.y+=p2[k]*y;
                if(p2[k]>0) n4++; }}
        if(n4>=th2) {v1.x=v1.x/v;v1.y=v1.y/v;}

        scan_[i2].pic=pic_cur_;
        scan_[i2].x[0]=v1.x;
        scan_[i2].y[0]=v1.y;
        scan_[i2].v[0]=n4;
        scan_[i2].v[1]=v;
        i2++;
}}}

        int n5=i2;
LOG(INFO) << "n5= " << n5;

        for(int i=0;i<n5-1;i++){
            if(scan_[i].pic>=0) {
            for(int j=i+1;j<n5;j++)
            {
             if(scan_[j].pic>=0) {
                 float tx=(scan_[i].x[0]-scan_[j].x[0]);
                 float ty=(scan_[i].y[0]-scan_[j].y[0]);
                 float dist=sqrt(tx*tx+ty*ty);
                 if(dist<5)
                    {
                     if(scan_[i].v[1]>scan_[j].v[1]) scan_[j].pic=-1;
                     else scan_[i].pic=-1;
                 }}}}}

        for(int i=0;i<n5-1;i++){
            if(scan_[i].pic>=0) {
            for(int j=i+1;j<n5;j++)
            {
             if(scan_[j].pic>=0) {
                 float tx=(scan_[i].x[0]-scan_[j].x[0]);
                 float ty=(scan_[i].y[0]-scan_[j].y[0]);
                 float dist=sqrt(tx*tx+ty*ty);
                 p0.x=scan_[i].x[0];
                 p0.y=scan_[i].y[0];
                 p1.x=scan_[j].x[0];
                 p1.y=scan_[j].y[0];
                 int k1=Test_Connection(p0,p1);
                 if(dist<100&&k1==0)
                    {
                     if(scan_[i].v[1]>scan_[j].v[1]) scan_[j].pic=-1;
                     else scan_[i].pic=-1;
                 }}}}}

     i2=n_scan_;
     for(int i=0;i<n5;i++){
         if(scan_[i].pic>=0) {
         //memcpy(&scan[i2],  &scan_[i], sizeof(Scan_Pos));

          float t=Smp_Area(i);
          if(t>area_threshold) {
         scan[i2].pic=pic_cur_;
         scan[i2].label=1;
         scan[i2].x[0]=scan_[i].x[0];
         scan[i2].y[0]=scan_[i].y[0];
         scan[i2].v[0]=scan_[i].v[1];
         i2++;}
         }
     }

     n_scan_=i2;
LOG(INFO) << "n_scan_= " << n_scan_;
}








template <typename Dtype>
int UDL_Data<Dtype>::Test_Connection(Point p0, Point p1)
{

float t4,v0,v1,tx,ty,dx,dy,c_threshold;
tx=p1.x-p0.x;
ty=p1.y-p0.y;
dx=tx/100;
dy=ty/100;

int h1=imgheight_;
int w1=imgwidth_;
int imgsize=h1*w1;


c_threshold=connect_threshold;

float *p=&image_target_[0];

v0=p[p0.y*w1+p0.x];
v1=p[p1.y*w1+p1.x];

float min=1.0;
for(int i=1;i<100;i++)
        {
        float x=p0.x+dx*i;
        float y=p0.y+dy*i;

        int x0=x;
        int y0=y;
        int x2=x0+1;
        int y2=y0+1;

        if(x2<0) x2=0;
        if(x2>w1-1) x2=w1-1;
        if(y2<0) y2=0;
        if(y2>h1-1) y2=h1-1;

        float t1=x-x0;float t2=y-y0;
        int k=y0*w1+x0; int k1=y2*w1+x0; int k2=y0*w1+x2; int k3=y2*w1+x2;
        float t4=(1-t1)*(1-t2)*p[k]+(1-t1)*t2*p[k1]+t1*(1-t2)*p[k2]+t1*t2*p[k3];
        if(t4<c_threshold) return(1);
}

return(0);
}








template <typename Dtype>
float UDL_Data<Dtype>::Smp_Area(int ns)
{
float v,v1,t,t1,t2,t3,t4,max2,min2;
int h1=imgheight_;
int w1=imgwidth_;

int imgsize=h1*w1;

float *p=&image_target_[0];

//memset(p,0,4*imgsize);
object_len=10;

int i=ns;

   float tx=1.0;
   float ty=0.0;
   float len=object_len;
   float tx1=tx/len;
   float ty1=ty/len;

   float cx=scan_[i].x[0];
   float cy=scan_[i].y[0];

   int x0=cx-10; int x1=cx+10;
   if(x0<0) x0=0;
   if(x1>=w1) x1=w1;

   int y0=cy-10; int y1=cy+10;
   if(y0<0) y0=0;
   if(y1>=h1) y1=h1;

t4=0;
   for(int y=y0;y<y1;y++)
        {
        for(int x=x0;x<x1;x++)
                {
                float t1=tx1*(x-cx)+ty1*(y-cy);
                t1=t1/len;
                float t2=ty1*(x-cx)-tx1*(y-cy);
                t2=t2/len;
                float t3=t1*t1+t2*t2;
                float t=1.0*exp(-20.0*t3);
                int k=y*w1+x;
                t4+=t*p[k];
                }
        }

   t4=t4/400;

   return(t4);

}




}  // namespace caffe






#endif  // CAFFE_UDL_DATA_H_
