#!/usr/bin/env sh
set -e

./build_release/tools/caffe train --solver=models/sdbn/sdbn_solver.prototxt --gpu 1
